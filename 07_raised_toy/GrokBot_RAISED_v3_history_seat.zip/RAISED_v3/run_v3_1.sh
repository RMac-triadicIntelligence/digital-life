#!/bin/bash
# RAISED v3.1 arms (F6 main, F7 side) plus the v3.1 equivalence runs. Usage: ./run_v3_1.sh <runs-folder>
cd "$(dirname "$0")"
OUTD=${1:-runs}
python3 make_v3_1.py
jobs() {
  echo "0 29200 $OUTD/eq31_off HSFW"; echo "0 29200 $OUTD/eq31_F4 HSFW4"
  for s in 0 1 2 3 4 5 6 7 8 9 10; do echo "$s 29200 $OUTD/F6 HSFW6"; echo "$s 29200 $OUTD/F7 HSFW7"; echo "$s 29200 $OUTD/F6GAD HSFW6GAD"; done
}
one() { mkdir -p $3; f=$(printf %02d $1); python3 commons_raised_v3_1.py $1 $2 $3/seed_$f.json $4 > $3/log_$f.txt 2>&1; }
export -f one
jobs | xargs -P 8 -L 1 bash -c 'one "$@"' _
echo RUN_V3_1_DONE $OUTD
