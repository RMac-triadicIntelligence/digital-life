#!/bin/bash
# Compares every file in rerun/ with the same file in runs/ (packed, .arm, .v2, .v3, .diag and logs). Usage: ./check_rerun.sh [arm ...]
cd "$(dirname "$0")"; n=0; bad=0; miss=0
arms=${@:-$(ls rerun)}
for a in $arms; do for f in runs/$a/*; do g=rerun/$a/$(basename $f)
  if [ ! -f $g ]; then miss=$((miss+1)); echo "MISSING $g"; elif cmp -s $f $g; then n=$((n+1)); else bad=$((bad+1)); echo "DIFF $g"; fi
done; done
echo "identical $n, different $bad, missing $miss"
