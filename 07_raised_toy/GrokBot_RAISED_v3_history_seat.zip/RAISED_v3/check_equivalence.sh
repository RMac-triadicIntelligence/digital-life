#!/bin/bash
# Arg 1: Claude's unpacked RAISED toy folder. Arg 2: my unpacked v2 folder. Compares the v3 fixes-off runs.
C="$1"; V="$2"; n=0; bad=0
cmpf() { if cmp -s "$1" "$2"; then n=$((n+1)); else bad=$((bad+1)); echo "DIFF $1"; fi; }
for f in $C/off/seed_??.json; do b=$(basename $f); cmpf runs/E_off/$b $f; cmpf runs/E_off/$b.arm.json $f.arm.json; done
for f in $C/full/seed_??.json; do b=$(basename $f); cmpf runs/off/$b $f; cmpf runs/off/$b.arm.json $f.arm.json; done
for f in $V/runs/E_full/seed_??.json; do b=$(basename $f); cmpf runs/off/$b.v2.json $f.v2.json; done
for f in $V/runs/x_O/seed_??.json; do b=$(basename $f); for e in "" .arm.json .v2.json; do cmpf runs/O/$b$e $f$e; done; done
echo "identical $n, different $bad"
