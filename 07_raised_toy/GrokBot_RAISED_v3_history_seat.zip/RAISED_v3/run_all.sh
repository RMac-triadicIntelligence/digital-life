#!/bin/bash
# RAISED v3: every run, 8 at a time. Each line: seed ticks dir switches. Usage: ./run_all.sh <runs-folder>  (runs or rerun)
cd "$(dirname "$0")"
OUTD=${1:-runs}
python3 make_v3.py
jobs() {
  echo "0 8000 $OUTD/E_off -"
  for s in 0 1 2 3 4 5 6 7 8 9 10; do echo "$s 29200 $OUTD/off HSFW"; done
  for s in 0 1 2 3 4 5 6 7 8 9 10; do
    echo "$s 29200 $OUTD/O HSFWO"
    for f in 1 2 3 4 5; do echo "$s 29200 $OUTD/F$f HSFW$f"; done
    echo "$s 29200 $OUTD/OGAD HSFWOGAD"
    echo "$s 29200 $OUTD/F1GAD HSFW1GAD"
    echo "$s 29200 $OUTD/F2GAD HSFW2GAD"
  done
}
one() { mkdir -p $3; f=$(printf %02d $1); python3 commons_raised_v3.py $1 $2 $3/seed_$f.json $4 > $3/log_$f.txt 2>&1; }
export -f one
jobs | xargs -P 8 -L 1 bash -c 'one "$@"' _
echo RUN_ALL_DONE $OUTD
