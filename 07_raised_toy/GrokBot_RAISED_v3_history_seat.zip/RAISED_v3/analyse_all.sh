#!/bin/bash
# Rebuilds the tables from runs/ (needs the .diag.json files run_all.sh makes).
cd "$(dirname "$0")"
ARMS="off=runs/off O=runs/O F1=runs/F1 F2=runs/F2 F3=runs/F3 F4=runs/F4 F5=runs/F5 OGAD=runs/OGAD F1GAD=runs/F1GAD F2GAD=runs/F2GAD F6=runs/F6 F7=runs/F7 F6GAD=runs/F6GAD"
python3 analyse_raised.py 29200 $ARMS > summary_v3.json
python3 analyse_v3.py summary_v3.json $ARMS > v3_tables.json
