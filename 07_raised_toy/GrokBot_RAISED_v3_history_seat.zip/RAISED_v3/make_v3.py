"""RAISED v3 (history seat, 16 Nov 2026). Makes commons_raised_v3.py from my v2 runner by asserted text swaps.

Neither Claude's commons_raised.py nor my commons_raised_v2.py is edited. commons_raised_v2_base.py is a byte copy of v2
(sha256 checked below). The keel, 16 Nov 12:28 CT: "The extra falls on the ground doesn't go to any individual. It can be
used to either manipulate the terrain because of the addition. Or can be picked up and used as food from anyone who needs it."

New: the FALLEN EXCESS switches F1..F5 (one at a time; on the command line the digits 1..5, because the letter F is
already Claude's "keepers feed the young"). Each needs H (a hand has a size) and excludes O (v2's open hand).
What a member holds above a hand falls on the ground at its own cell. It goes to no individual. It becomes either
  terrain : a permanent addition KB to the cell's carrying capacity (regrowth runs toward max(K, KFLOOR) + KB), or
  pickup  : a ground store G, which any member below NEED standing on or next to the cell may pick up, up to its hand.
  F1  all of it to the ground store; unclaimed store soaks into terrain at SOAK1 of the store per tick.
  F2  TF2 (half) to terrain at once, the rest to the ground store, which stays until picked up.
  F3  all of it to terrain at once (terrain only; a control).
  F4  all of it to the ground store, which never soaks (pickup only; a control).
  F5  as F2 but a unit of food adds only 0.1 to terrain (a low-conversion check on the 1:1 assumption).
With every v3 switch off, the code path is v2's exactly; the equivalence runs check that byte for byte.
Usage: python3 commons_raised_v3.py <seed> <ticks> <out.json> <switches, e.g. HSFW1 or HSFW2GAD or - >
"""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "commons_raised_v2_base.py"
OUT = HERE / "commons_raised_v3.py"
V2_SHA = "71b8be5c86fe2c4e06639a09ca44f6b4576eca29b873a6df827784c0d895a1ed"
assert hashlib.sha256(SRC.read_bytes()).hexdigest() == V2_SHA, "not my commons_raised_v2.py"
src = SRC.read_text()


def swap(old, new, count=1):
    global src
    assert src.count(old) == count, (src.count(old), old[:70])
    src = src.replace(old, new)


# 1. switches
swap('"G": False, "O": False, "A": False, "D": False, "K": False, "Y": False}   # v2 switches, all off by default',
     '"G": False, "O": False, "A": False, "D": False, "K": False, "Y": False,   # v2 switches, all off by default\n'
     '       "1": False, "2": False, "3": False, "4": False, "5": False}   # v3 fallen-excess arms F1..F5, all off by default')

V3_CODE = '''

# ---------------- RAISED v3 (history seat): fallen excess, on the ground, for terrain or for whoever needs it ----------------
V3 = {"mode": 0}
NEED = LOW          # a member "needs food" below half a hand (0.5, the toy's own low line)          [assumption A3]
TF2 = 0.5           # F2, F5: share of each fall that goes into the terrain at once                    [A5]
SOAK1 = 0.01        # F1: share of each cell's unclaimed ground store that soaks into terrain per tick  [A6]
TCAP = 1.0          # the most terrain one cell can gain (one patch peak, K's own maximum)              [A8]
CONV = {1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 0.1}   # terrain gained per unit of food that goes in       [A7]
NB = [(0, 0)] + [(dx, dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1) if (dx, dy) != (0, 0)]
_V3F = ("fallen", "falls", "to_terrain_at_fall", "soaked", "terrain_food_in", "terrain_gain", "cap_back_to_store",
        "picked", "picks", "picked_k", "picked_s", "picked_young", "picked_young_k", "picked_young_s", "picked_self",
        "picked_off_cell", "rescued_off_zero", "needy_found_nothing", "tick_pick")


def _v3_reset():
    mode = next((int(k) for k in "12345" if ARM[k]), 0)
    V3.clear()
    V3.update(mode=mode, G=np.zeros((N, N)), KB=np.zeros((N, N)), OWN=-np.ones((N, N), dtype=np.int64), yearly=[])
    for k in _V3F: V3[k] = 0 if k in ("falls", "picks", "rescued_off_zero", "needy_found_nothing") else 0.0


def _v3_terrain(x, y, f):
    """Food f goes into the cell's terrain. Returns the food the terrain had no room for (it stays as ground store)."""
    c = CONV[V3["mode"]]; room = TCAP - V3["KB"][x, y]
    gain = min(c * f, room) if room > 0 else 0.0
    used = gain / c
    V3["KB"][x, y] += gain; V3["terrain_food_in"] += used; V3["terrain_gain"] += gain
    left = f - used
    if left > 1e-12: V3["cap_back_to_store"] += left
    return left if left > 1e-12 else 0.0


def _v3_drop(m, back):
    """The excess falls at the member's own cell. It goes to no individual."""
    mode = V3["mode"]; x, y = m.x, m.y
    V3["fallen"] += back; V3["falls"] += 1; V3["OWN"][x, y] = m.id
    now = back * TF2 if mode in (2, 5) else (back if mode == 3 else 0.0)
    store = back - now
    if now > 0:
        V3["to_terrain_at_fall"] += now
        store += _v3_terrain(x, y, now)
    V3["G"][x, y] += store


def _v3_pickup(pool, fams, t):
    """Any member below NEED, on or next to a cell with ground store, picks up to its hand. Neediest first (by holding, then id);
    own cell first, then the eight neighbours by most store (ties in fixed offset order). Draws no random numbers."""
    V3["tick_pick"] = 0.0
    G = V3["G"]
    if not (G > 0).any(): return
    for a in sorted((a for a in pool if a.e < NEED), key=lambda z: (z.e, z.id)):
        cells = [((a.x + dx) % N, (a.y + dy) % N) for dx, dy in NB]
        order = [cells[0]] + sorted(cells[1:], key=lambda c: -G[c])
        room = HAND - a.e; was = a.e; got = 0.0
        for c in order:
            if room <= 1e-12: break
            g = min(room, G[c])
            if g <= 1e-12: continue
            G[c] -= g
            if G[c] < 1e-12: G[c] = 0.0
            a.e += g; room -= g; got += g
            V3["picks"] += 1
            if c != cells[0]: V3["picked_off_cell"] += g
            if V3["OWN"][c] == a.id: V3["picked_self"] += g
        if got <= 0:
            V3["needy_found_nothing"] += 1; continue
        fams[a.fam].period_harvest += got; V3["tick_pick"] += got; V3["picked"] += got
        sc = _is_scout(a); V3["picked_s" if sc else "picked_k"] += got
        if _young(a, t):
            V3["picked_young"] += got; V3["picked_young_s" if sc else "picked_young_k"] += got
        if was <= 0 < a.e: V3["rescued_off_zero"] += 1
        _note(a.id, "picked", got)


def _v3_tick(Keff, live, t, R):
    """Once a tick, just before regrowth. F1 soaks; then the terrain addition joins the carrying capacity."""
    G, KB = V3["G"], V3["KB"]
    if V3["mode"] == 1 and (G > 0).any():
        c = CONV[1]; s = SOAK1 * G
        gain = np.minimum(c * s, np.maximum(TCAP - KB, 0.0)); used = gain / c
        G -= used; G[G < 1e-12] = 0.0; KB += gain
        V3["soaked"] += float(used.sum()); V3["terrain_food_in"] += float(used.sum()); V3["terrain_gain"] += float(gain.sum())
    if (t + 1) % (TICKS_PER_DAY * DAYS_PER_YEAR) == 0:
        near = np.zeros((N, N), dtype=bool)
        for a in live:
            if a.alive and not _is_scout(a) and not _young(a, t):
                for dx in range(-2, 3):
                    for dy in range(-2, 3):
                        near[(a.x + dx) % N, (a.y + dy) % N] = True
        kb = float(KB.sum()); gs = float(G.sum())
        V3["yearly"].append(dict(
            year=(t + 1) // (TICKS_PER_DAY * DAYS_PER_YEAR), terrain_sum=round(kb, 4), terrain_max=round(float(KB.max()), 4),
            terrain_cells_01=int((KB > 0.1).sum()), terrain_cells_full=int((KB >= TCAP - 1e-9).sum()),
            terrain_near_keepers=round(float(KB[near].sum()), 4), near_keeper_cells=int(near.sum()),
            terrain_near_keepers_share=round(float(KB[near].sum()) / kb, 4) if kb > 0 else None,
            capacity_base_sum=round(float(Keff.sum()), 4),
            store_sum=round(gs, 4), store_max=round(float(G.max()), 4), store_cells=int((G > 1e-9).sum()),
            hoard_cells_over_hand=int((G > HAND).sum()), stock_R=round(float(R.sum()), 4)))
    return Keff + KB


def _v3_out():
    o = {k: (round(V3[k], 6) if isinstance(V3[k], float) else V3[k]) for k in _V3F if k != "tick_pick"}
    o.update(mode=V3["mode"], arm=("F%d" % V3["mode"]) if V3["mode"] else "-", yearly=V3["yearly"],
             store_final=round(float(V3["G"].sum()), 6), store_max_final=round(float(V3["G"].max()), 6),
             terrain_final=round(float(V3["KB"].sum()), 6), terrain_max_final=round(float(V3["KB"].max()), 6),
             constants=dict(NEED=NEED, TF2=TF2, SOAK1=SOAK1, TCAP=TCAP, CONV=CONV[V3["mode"]] if V3["mode"] else None,
                            HAND=HAND, neighbourhood="own cell plus the 8 next to it (Chebyshev 1, torus)"))
    return o
'''
swap('\n\nclass Member:\n', V3_CODE + '\n\nclass Member:\n')

# 2. H: under F1..F5 the excess falls on the ground store / terrain instead of into R (v2's O and Claude's H unchanged when off)
swap("                    R[m.x, m.y] += back; fam.period_harvest -= back; _v2_ret(m, back)\n",
     "                    if V3['mode']:\n"
     "                        _v3_drop(m, back); fam.period_harvest -= back\n"
     "                    else:\n"
     "                        R[m.x, m.y] += back; fam.period_harvest -= back; _v2_ret(m, back)\n")

# 3. pickup, after every household has shared and dropped this tick, on the same pool (D respected), before the rescue count
swap("    _arm_after_eat(pool, fams, R, t)\n",
     "    _arm_after_eat(pool, fams, R, t)\n"
     "    if V3['mode']: _v3_pickup(pool, fams, t)\n")

# 4. reset
swap("global DG; DG = Diag(); _ar_reset(); _v2_reset()", "global DG; DG = Diag(); _ar_reset(); _v2_reset(); _v3_reset()")

# 5. pickup counts in the October-style harvest like any bite of returned food (left out under A)
swap("        if ARM['H'] or ARM['S'] or ARM['F']: _v2_after_eat(live, fams, R, t)\n",
     "        if ARM['H'] or ARM['S'] or ARM['F']: _v2_after_eat(live, fams, R, t)\n"
     "        if V3['mode'] and not ARM['A']: ht += V3['tick_pick']\n")

# 6. terrain joins the carrying capacity for regrowth
swap("        Keff = np.maximum(K, KFLOOR)\n",
     "        Keff = np.maximum(K, KFLOOR)\n"
     "        if V3['mode']: Keff = _v3_tick(Keff, live, t, R)\n")

# 7. guards and the v3 sidecar
swap('    assert not (ARM["O"] and not ARM["H"]), "O (open hand) needs H (a hand has a size)"\n',
     '    assert not (ARM["O"] and not ARM["H"]), "O (open hand) needs H (a hand has a size)"\n'
     '    _nf = sum(ARM[k] for k in "12345")\n'
     '    assert _nf <= 1, "one fallen-excess arm at a time"\n'
     '    assert not (_nf and not ARM["H"]), "F1..F5 need H (a hand has a size)"\n'
     '    assert not (_nf and ARM["O"]), "F1..F5 replace O; not both"\n')
swap('    Path(str(outp) + ".v2.json").write_text(json.dumps(v2, sort_keys=True))\n',
     '    Path(str(outp) + ".v2.json").write_text(json.dumps(v2, sort_keys=True))\n'
     '    if V3["mode"]:\n'
     '        v3 = dict(switches="".join(k for k in "HSFWGOADKY12345" if ARM[k]), grace=packed["totals"]["grace"], **_v3_out())\n'
     '        Path(str(outp) + ".v3.json").write_text(json.dumps(v3, sort_keys=True))\n')

OUT.write_text(src)
print("wrote", OUT.name, len(src.encode()), hashlib.sha256(src.encode()).hexdigest())
