"""RAISED v3 (history seat): v3 table per arm from analyse_raised.py's summary plus the .v2.json and .v3.json sidecars.
Usage: python3 analyse_v3.py <summary.json> <label=dir> ... > v3_tables.json"""
import json, sys, glob, statistics as st
from pathlib import Path
S = json.load(open(sys.argv[1]))["arms"]
out = {}
for spec in sys.argv[2:]:
    label, d = spec.split("=", 1)
    A = S[label]; sd = A["seeds"]; P = A["pooled"]; ks = sorted(sd, key=int)
    v2 = {str(int(Path(f).name[5:7])): json.load(open(f)) for f in sorted(glob.glob(str(Path(d) / "seed_??.json.v2.json")))}
    v3 = {str(int(Path(f).name[5:7])): json.load(open(f)) for f in sorted(glob.glob(str(Path(d) / "seed_??.json.v3.json")))}
    sv = lambda g, age: P[g]["survive"][age]
    r = dict(seeds=ks, keepers_30d=sv("KN", "240"), keepers_100d=sv("KN", "800"), scouts_30d=sv("SN", "240"), scouts_100d=sv("SN", "800"),
             keepers_alive_10y=[sd[s]["keepers_alive"] for s in ks], pop_10y=[sd[s]["pop"] for s in ks],
             lineages_10y=[sd[s]["lineages_alive"] for s in ks], births_after_y1=[sd[s]["births_after_y1"] for s in ks],
             stock_yearly_mean=[sd[s]["stock_yearly_mean"] for s in ks], cap_hit=[sd[s]["cap_hit"] for s in ks],
             keepers_min_any_year=[min(sd[s]["keepers_by_year"]) for s in ks],
             grace=[v2[s]["grace"] for s in ks] if v2 else None)
    if v3:
        g = lambda k: [v3[s][k] for s in ks]
        last = lambda k: [v3[s]["yearly"][-1][k] if v3[s]["yearly"] else None for s in ks]
        r.update({k: g(k) for k in ("fallen", "picked", "picked_young", "picked_young_k", "picked_young_s", "picked_k", "picked_s",
                                     "picked_self", "picked_off_cell", "rescued_off_zero", "needy_found_nothing", "terrain_food_in",
                                     "terrain_gain", "soaked", "cap_back_to_store", "store_final", "store_max_final", "terrain_final")})
        r["picked_share_of_fallen"] = [round(v3[s]["picked"] / v3[s]["fallen"], 4) if v3[s]["fallen"] else None for s in ks]
        r["picked_young_share"] = [round(v3[s]["picked_young"] / v3[s]["picked"], 4) if v3[s]["picked"] else None for s in ks]
        r["picked_self_share"] = [round(v3[s]["picked_self"] / v3[s]["picked"], 4) if v3[s]["picked"] else None for s in ks]
        r["y10_hoard_cells_over_hand"] = last("hoard_cells_over_hand"); r["y10_store_max"] = last("store_max")
        r["y10_terrain_sum"] = last("terrain_sum"); r["y10_terrain_cells_full"] = last("terrain_cells_full")
        dens = []
        for s in ks:
            y = v3[s]["yearly"][-1]; nc = y["near_keeper_cells"]; tn = y["terrain_near_keepers"]; ts = y["terrain_sum"]
            a = tn / nc if nc else None; b = (ts - tn) / (1024 - nc) if nc < 1024 else None
            dens.append(round(a / b, 2) if a is not None and b else (None if a is None else "inf"))
        r["y10_terrain_density_near_keepers_ratio"] = dens
        r["terrain_sum_by_year_seed0"] = [y["terrain_sum"] for y in v3[ks[0]]["yearly"]]
        r["store_sum_by_year_seed0"] = [y["store_sum"] for y in v3[ks[0]]["yearly"]]
    out[label] = r
print(json.dumps(out, indent=1, sort_keys=True))
