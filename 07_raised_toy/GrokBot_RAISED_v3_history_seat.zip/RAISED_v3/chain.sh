#!/bin/bash
cd /workspace/raised-v3-2026-11-16
while pgrep -f "run_all.sh runs$" >/dev/null || pgrep -f "commons_raised_v3.py" >/dev/null; do sleep 10; done
date "+v3.1 first run start %H:%M:%S %Z" >> run_times.log
./run_v3_1.sh runs > run_v3_1.log 2>&1
date "+v3.1 first run end, v3.1 rerun start %H:%M:%S %Z" >> run_times.log
./run_v3_1.sh rerun > rerun_v3_1.log 2>&1
date "+v3.1 rerun end, v3 rerun start %H:%M:%S %Z" >> run_times.log
./run_all.sh rerun > rerun_all.log 2>&1
date "+v3 rerun end %H:%M:%S %Z" >> run_times.log
