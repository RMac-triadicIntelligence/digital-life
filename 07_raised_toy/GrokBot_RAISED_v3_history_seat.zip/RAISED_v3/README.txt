FOR THE KEEL (Rusty). RAISED toy v3, built by the history seat (Grok bot) beside Claude's RAISED toy and my v2. Keel decides
any release. Not published. Nothing here is a ruling. Start with RESULTS.txt.

Built 16 Nov 2026 (CST) on the keel's words: 12:28 CT "The extra falls on the ground doesn't go to any individual. It can be
used to either manipulate the terrain because of the addition. Or can be picked up and used as food from anyone who needs it."
and 12:56 CT "Remainder on ground is used by whoever needs it. What's left over is what is left on the terrain. So it's up
to each organism's need on what's left. Others cannot pick up what they cannot carry."

FILES
PREDICTIONS.txt / .hash                 hashed 12:33:38 CST, before any v3 run (F1..F5)
PREDICTIONS_ADDENDUM.txt / .hash        hashed 12:58:04 CST, before any F6/F7 run (after the keel's 12:56 message)
commons_raised_v2_base.py               byte copy of my v2 runner (71b8be5c...a1ed); v2 is itself made from Claude's file
make_v3.py -> commons_raised_v3.py      F1..F5 (digits 1-5 on the command line), by asserted text swaps from v2
make_v3_1.py -> commons_raised_v3_1.py  F6 (MAIN, the keel's 12:56 rule) and F7, by asserted text swaps from v3
V3_vs_v2.diff, V3_1_vs_V3.diff          every changed line
run_all.sh, run_v3_1.sh                 all runs, 8 at a time (folder argument: runs or rerun)
check_equivalence.sh                    off arms against Claude's stored files and v2's stored files
check_rerun.sh                          rerun/ against runs/ byte for byte
analyse_raised.py (Claude's, unchanged), analyse_v2.py, analyse_v3.py, analyse_all.sh   tables
summary_v3.json, v3_tables.json         results; run_times.log, *.log, check_*.txt   run records
runs/<arm>/seed_XX.json, .arm.json, .v2.json, .v3.json, log_XX.txt   outputs (.diag.json left out for size; remade by runs)
vendor/commons                          October's sources, as in v2

USAGE  python3 commons_raised_v3_1.py <seed> <ticks> <out.json> <switches>   e.g. HSFW6 (F6 on Claude's full toy)
Switches: Claude's H S F W; v2's G O A D K Y; v3's 1..5 (F1..F5) and 6, 7 (F6, F7). One fallen-excess arm at a time; needs H;
not with O. With all new switches off the outputs equal Claude's and v2's byte for byte (checked).

Never opened for this build: the ledger (Claude's ledger/ folder included), any hold, round 5, KABOOM, sealed or
CONDUCTOR_PREDICTIONS file, workbench 12_/13_. Claude's toy README marks it keel-only; so is this.
