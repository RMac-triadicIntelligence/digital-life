"""RAISED v3.1 (history seat, 16 Nov 2026, after the keel's 12:56 CT clarification). Makes commons_raised_v3_1.py from
commons_raised_v3.py by asserted text swaps. commons_raised_v3.py is not edited (hash checked).

The keel, 16 Nov 12:56 CT: "Remainder on ground is used by whoever needs it. What's left over is what is left on the terrain.
So it's up to each organism's need on what's left. Others cannot pick up what they cannot carry."
New arms (digits on the command line; one fallen-excess arm at a time; need H; replace O):
  F6 (MAIN)  the excess falls on the ground at the member's cell. Any member short of a full hand, on or next to the cell,
             picks up its own shortfall (its need), which is also all its hand can carry. Neediest first, own cell first.
             Whatever nobody takes that tick stays on the ground as terrain: it joins the cell's carrying capacity at once
             (1:1, cap 1.0 per cell). No fixed split, no terrain share before pickup. Food the terrain has no room for stays
             on the ground and is offered again the next tick, then goes to terrain if room has come.
  F7 (side)  as F6, but only members below half a hand (0.5) count as needing, and each picks up only to 0.5.
"""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "commons_raised_v3.py"
OUT = HERE / "commons_raised_v3_1.py"
V3_SHA = "68475cbae998bae87138dfa344f31fc0c01179ff7d3d7dca16eb8c36c38c8094"
assert hashlib.sha256(SRC.read_bytes()).hexdigest() == V3_SHA, "not commons_raised_v3.py"
src = SRC.read_text()


def swap(old, new, count=1):
    global src
    assert src.count(old) == count, (src.count(old), old[:70])
    src = src.replace(old, new)


swap('"1": False, "2": False, "3": False, "4": False, "5": False}',
     '"1": False, "2": False, "3": False, "4": False, "5": False, "6": False, "7": False}')
swap('CONV = {1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 0.1}', 'CONV = {1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 0.1, 6: 1.0, 7: 1.0}')
swap('    mode = next((int(k) for k in "12345" if ARM[k]), 0)', '    mode = next((int(k) for k in "1234567" if ARM[k]), 0)')
# pickup: who needs, and how much each takes
swap("    for a in sorted((a for a in pool if a.e < NEED), key=lambda z: (z.e, z.id)):\n",
     "    line = HAND if V3['mode'] == 6 else NEED\n"
     "    top = NEED if V3['mode'] == 7 else HAND\n"
     "    for a in sorted((a for a in pool if a.e < line), key=lambda z: (z.e, z.id)):\n")
swap("        room = HAND - a.e; was = a.e; got = 0.0\n", "        room = top - a.e; was = a.e; got = 0.0\n")
# what is left after pickup becomes terrain (F6, F7). Called at the end of the pickup step.
swap("        _note(a.id, \"picked\", got)\n",
     "        _note(a.id, \"picked\", got)\n"
     "    if V3['mode'] in (6, 7): _v3_left_to_terrain()\n")
swap("\n\ndef _v3_tick(Keff, live, t, R):\n",
     "\n\ndef _v3_left_to_terrain():\n"
     "    G, KB = V3['G'], V3['KB']\n"
     "    if not (G > 0).any(): return\n"
     "    gain = np.minimum(G, np.maximum(TCAP - KB, 0.0))\n"
     "    G -= gain; G[G < 1e-12] = 0.0; KB += gain\n"
     "    V3['terrain_food_in'] += float(gain.sum()); V3['terrain_gain'] += float(gain.sum())\n"
     "\n\ndef _v3_tick(Keff, live, t, R):\n")
swap('    _nf = sum(ARM[k] for k in "12345")', '    _nf = sum(ARM[k] for k in "1234567")')
swap('switches="".join(k for k in "HSFWGOADKY12345" if ARM[k])', 'switches="".join(k for k in "HSFWGOADKY1234567" if ARM[k])')
OUT.write_text(src)
print("wrote", OUT.name, len(src.encode()), hashlib.sha256(src.encode()).hexdigest())
