#!/bin/bash
# Rebuilds every table from runs/ (needs the .diag.json files, which run_all.sh remakes; they are left out of the zip for size).
cd "$(dirname "$0")"
mkdir -p sub/E_full3 sub/base3
for s in 00 01 02; do
  for e in json json.diag.json json.arm.json json.v2.json; do [ -f runs/E_full/seed_$s.$e ] && ln -sf ../../runs/E_full/seed_$s.$e sub/E_full3/; done
  for e in json json.diag.json; do ln -sf ../../runs/baseline/seed_$s.$e sub/base3/; done
done
python3 analyse_raised.py 29200 baseline=runs/baseline E_full=runs/E_full v2full=runs/v2full v2H=runs/v2H v2HS=runs/v2HS v2HSF=runs/v2HSF > summary_main.json
python3 analyse_raised.py 29200 baseline=sub/base3 E_H=runs/E_H E_HS=runs/E_HS E_HSF=runs/E_HSF E_full=sub/E_full3 x_G=runs/x_G x_O=runs/x_O x_A=runs/x_A x_D=runs/x_D x_K=runs/x_K x_Y=runs/x_Y > summary_ablation_seeds_0_2.json
python3 analyse_v2.py summary_main.json baseline=runs/baseline E_full=runs/E_full v2full=runs/v2full v2H=runs/v2H v2HS=runs/v2HS v2HSF=runs/v2HSF > v2_tables_main.json
python3 analyse_v2.py summary_ablation_seeds_0_2.json baseline=sub/base3 E_H=runs/E_H E_HS=runs/E_HS E_HSF=runs/E_HSF E_full=sub/E_full3 x_G=runs/x_G x_O=runs/x_O x_A=runs/x_A x_D=runs/x_D x_K=runs/x_K x_Y=runs/x_Y > v2_tables_ablation_seeds_0_2.json
