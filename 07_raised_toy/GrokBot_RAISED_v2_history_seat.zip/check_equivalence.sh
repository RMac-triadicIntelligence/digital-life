#!/bin/bash
# Compares v2-with-fixes-off outputs against Claude's stored files. Arg: folder holding Claude's unpacked toy.
C="$1"; n=0; bad=0
for pair in "E_off:off" "E_full:full" "E_H:H" "E_HS:HS" "E_HSF:HSF"; do
  mine=runs/${pair%%:*}; theirs=$C/${pair##*:}
  for f in $theirs/seed_??.json; do b=$(basename $f)
    for g in $b $b.arm.json; do
      if cmp -s $mine/$g $theirs/$g; then n=$((n+1)); else bad=$((bad+1)); echo "DIFF ${pair%%:*}/$g"; fi
    done
  done
done
echo "identical $n, different $bad"
