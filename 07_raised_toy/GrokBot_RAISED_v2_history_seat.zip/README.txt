FOR THE KEEL (Rusty). RAISED toy v2, rebuilt by the history seat (Grok bot) beside Claude's original. Keel decides any release.

Built 16 Nov 2026 (CST) on the keel's go: "I'd like for you to give a shot at rewriting this toy fixing the problem you found".
Claude's RAISED toy is not edited. commons_raised_original.py is a byte copy of his commons_raised.py
(7463824921f606bb51f6ca527d9a3e5c88a5a60062219040b5ab0d311e92b01e). Nothing here is a ruling. Not published.
Start with RESULTS.txt. Then DESIGN_and_PREDICTIONS_v2.txt (hashed before any v2 run; see PREDICTIONS_v2.hash).

FILES
make_v2.py                 makes commons_raised_v2.py from commons_raised_original.py by asserted text swaps (checks the input hash)
commons_raised_v2.py       the v2 runner: python3 commons_raised_v2.py <seed> <ticks> <out.json> <switches>
V2_vs_original.diff        every line that differs from Claude's file
run_all.sh                 all 83 runs, 8 at a time (about 15 minutes on 8 cores)
check_equivalence.sh       compares the fixes-off runs with Claude's stored files: ./check_equivalence.sh <Claude's unpacked toy folder>
analyse_raised.py          Claude's analyser, unchanged (f4004313169a5fb21058fb70d95dd5946633950b44f84b113efb060d39538c9b)
analyse_v2.py, analyse_all.sh   v2 tables; analyse_all.sh rebuilds every table (needs the .diag.json files that run_all.sh remakes)
summary_*.json, v2_tables_*.json, tables_print.txt   results
runs/<arm>/seed_XX.json, .arm.json, .v2.json, log_XX.txt   outputs. The per-member .diag.json files (about 226 MB) are left out
                           and remade by run_all.sh. runs/baseline holds my all-off ten-year runs (no .arm/.v2 files).
vendor/commons             October's commons_sim and commons_v2 sources, byte-identical to the public
                           the-terrain-remembers/00_commons_swarm (sim_v2.py b5cbf3b5b6194a7f2930645e7c02742009abf8f7c1de2926248bd98af5ca2e73)
SHA256SUMS                 every file in this zip

SWITCHES. Claude's: H hand has a size, S sent feed keepers, F keepers feed the young, W with then sent.
New, all OFF by default: G grace removed, O open hand (needs H), A net harvest, D death check first, K keepers feed young
keepers only, Y young for one season (150 ticks).
Arms: E_* = Claude's arms with fixes off (equivalence); x_<fix> = HSFW plus one fix (seeds 0-2); v2H = HGOA, v2HS = HSGOAD,
v2HSF = HSFGOADK, v2full = HSFWGOADKY (seeds 0-10).

EVERY BEHAVIOURAL DIFFERENCE FROM CLAUDE'S commons_raised.py (V2_vs_original.diff shows the text)
0  Path only: the vendored October sources are found beside the file (Claude's runner pointed at his own home folder).
1  G on: the grace step is skipped (no member is picked, no target set). Off: unchanged.
2  Y on: "young" means under 150 ticks instead of 100. That changes who W holds and who F feeds.
3  K on: F gives only to young keepers. Off: any young member, as Claude's.
4  O on (needs H): inside the H step, a member's excess runs on to the two nearest others in the sharing pool (whole
   commons, Chebyshev distance on the torus, ties by id), half each, each capped at its free room (hand minus holding);
   refused food runs on to the next two; the rest goes on the ground at the giver's cell, as H did. Passes change no
   household's harvest count; ground returns come off the giver's household as in H. Because sharing runs household by
   household, a member in a later household can be filled by O before its own household's S and F run.
5  D on: members at or below zero after eating are left out of the sharing pool (S, F, H, O as givers and receivers).
   They die at the tick's death check as in October. Off: the pool is every live member, as Claude's.
6  A on: October-style harvest_total, harvest_late, post_shift and per_capita count each bite minus the returned food in it.
   The swarm itself is unchanged (checked: every member and yearly row identical).
7  Read-only instruments, always on (no random numbers drawn; nothing the swarm reads is written): a returned-food grid,
   eaten and re-eaten food, rescues off zero, open-hand passes, F food by role. They are written to <out>.v2.json.
   Proven inert: with the six switches off, all 42 packed and .arm.json files equal Claude's byte for byte.
8  New guard: O without H stops with an error.
Nothing else differs.

Never opened for this build: the ledger, any hold, round 5, KABOOM, sealed or CONDUCTOR_PREDICTIONS file.
