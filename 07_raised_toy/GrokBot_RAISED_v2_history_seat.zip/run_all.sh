#!/bin/bash
# RAISED v2: every run of the build, 8 at a time. Each line: seed ticks dir switches.
# Order: equivalence (Claude's 21 runs, fixes off), v2full on 11 seeds, single-fix ablations, then the v2 ladder.
cd "$(dirname "$0")"
python3 make_v2.py
jobs() {
  echo "0 8000 runs/E_off -"
  for s in 0 1 2 3 4 5 6 7 8 9 10; do echo "$s 29200 runs/E_full HSFW"; done
  for a in H HS HSF; do for s in 0 1 2; do echo "$s 29200 runs/E_$a $a"; done; done
  for s in 0 1 2 3 4 5 6 7 8 9 10; do echo "$s 29200 runs/v2full HSFWGOADKY"; done
  for f in G O A D K Y; do for s in 0 1 2; do echo "$s 29200 runs/x_$f HSFW$f"; done; done
  for s in 0 1 2 3 4; do echo "$s 29200 runs/v2H HGOA"; echo "$s 29200 runs/v2HS HSGOAD"; echo "$s 29200 runs/v2HSF HSFGOADK"; done
  for s in 5 6 7 8 9 10; do echo "$s 29200 runs/v2H HGOA"; echo "$s 29200 runs/v2HS HSGOAD"; echo "$s 29200 runs/v2HSF HSFGOADK"; done
}
one() { mkdir -p $3; f=$(printf %02d $1); python3 commons_raised_v2.py $1 $2 $3/seed_$f.json $4 > $3/log_$f.txt 2>&1; }
export -f one
jobs | xargs -P 8 -L 1 bash -c 'one "$@"' _
echo RUN_ALL_DONE
