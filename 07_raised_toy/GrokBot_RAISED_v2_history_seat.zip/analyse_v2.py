"""RAISED v2 (history seat): one table per arm from Claude's analyse_raised.py output plus the v2.json sidecars.
Usage: python3 analyse_v2.py <summary_from_analyse_raised.json> <label=dir> ... > v2_tables.json"""
import json, sys, glob, statistics as st
from pathlib import Path
S = json.load(open(sys.argv[1]))["arms"]
out = {}
for spec in sys.argv[2:]:
    label, d = spec.split("=", 1)
    A = S[label]; sd = A["seeds"]; P = A["pooled"]; ks = sorted(sd, key=int)
    side = {}
    for f in sorted(glob.glob(str(Path(d) / "seed_??.json.v2.json"))):
        side[str(int(Path(f).name[5:7]))] = json.load(open(f))
    def surv(g, age): return P[g]["survive"][age]
    kn, sn = surv("KN", "240"), surv("SN", "240")
    r = dict(seeds=ks,
             keepers_alive_10y=[sd[s]["keepers_alive"] for s in ks], scouts_alive_10y=[sd[s]["scouts_alive"] for s in ks],
             pop_10y=[sd[s]["pop"] for s in ks], lineages_10y=[sd[s]["lineages_alive"] for s in ks],
             births_after_y1=[sd[s]["births_after_y1"] for s in ks], stock_yearly_mean=[sd[s]["stock_yearly_mean"] for s in ks],
             keepers_min_any_year=[min(sd[s]["keepers_by_year"]) for s in ks], cap_hit=any(sd[s]["cap_hit"] for s in ks),
             newborn_keepers_30d=kn, newborn_keepers_100d=surv("KN", "800"), newborn_scouts_30d=sn, newborn_scouts_100d=surv("SN", "800"),
             newborn_both_30d=round((kn[0] + sn[0]) / max(kn[1] + sn[1], 1), 4),
             keeper_share_10y=[round(sd[s]["keepers_alive"] / sd[s]["pop"], 3) if sd[s]["pop"] else None for s in ks],
             scout_founders_dead=[P["SF"]["dead"], P["SF"]["n"]], keeper_newborn_life_median_ticks=P["KN"]["life_median_of_dead"])
    if side:
        g = lambda k: [side[s].get(k) for s in ks if s in side]
        r.update(switches=sorted({v["switches"] for v in side.values()}), grace=g("grace"),
                 eaten_gross=g("eaten_gross"), reeaten=g("reeaten"), reeaten_share=[round(v["reeaten"] / v["eaten_gross"], 4) if v["eaten_gross"] else None for v in (side[s] for s in ks if s in side)],
                 reeaten_self=g("reeaten_self"), harvest_net=g("harvest_net"), harvest_total_reported=g("harvest_total_reported"),
                 returned_ground=g("returned_ground"), lifted_old_order=g("lifted"), lifted_keepers=g("lifted_keepers"),
                 low_before_share=g("low_before_share"), excluded_by_D=g("excluded_by_D"),
                 o_passed=g("o_passed"), o_to_keepers=g("o_to_keepers"), o_to_scouts=g("o_to_scouts"), o_to_ground=g("o_to_ground"),
                 o_mean_dist=[round(v["o_dist_sum"] / v["o_passed"], 2) if v.get("o_passed") else None for v in (side[s] for s in ks if s in side)],
                 f_to_keepers=g("f_to_keepers"), f_to_scouts=g("f_to_scouts"), young_ticks=g("young_ticks"))
    out[label] = r
print(json.dumps(out, indent=1, sort_keys=True))
