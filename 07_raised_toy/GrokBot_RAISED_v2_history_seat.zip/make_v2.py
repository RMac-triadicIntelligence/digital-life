"""RAISED v2 (history seat, 16 Nov 2026). Makes commons_raised_v2.py from Claude's commons_raised.py by asserted text swaps.

Claude's file is not edited (commons_raised_original.py here is a byte copy, sha256 checked below).
Six new switches, all OFF by default. With all six off, every packed output and .arm.json must equal Claude's byte for byte.
  G  grace removed: October's grace step is skipped (PREREG T7: "Grace is not in this toy"). Off = Claude's code (grace live).
  O  open hand (needs H): what a member holds above a hand runs on to others, two nearest at a time, each taking at most
     its own free room (HAND minus holding). What nobody in the commons has room for goes on the ground (T6).
  A  net harvest: the October-style harvest totals leave out food that was returned to the ground and eaten again.
  D  death check first: members at or below zero after eating are left out of the sharing step (S, F, H/O); they die
     at the tick's death check as in October.
  K  keepers feed the young keepers: F gives only to young keepers (young scouts are not fed by F).
  Y  young for one season: young means the first SEASON (150) ticks instead of WEAN_TAU (100).
Always on, read-only (draws no random numbers, writes nothing the swarm reads): grace count, re-eaten returned food,
net harvest, rescues off zero under the old order, open-hand passes, F food by role. Written to <out>.v2.json.
Usage of the product: python3 commons_raised_v2.py <seed> <ticks> <out.json> <switches, e.g. HSFW or HSFWGOADKY or - >
"""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "commons_raised_original.py"
OUT = HERE / "commons_raised_v2.py"
ORIG_SHA = "7463824921f606bb51f6ca527d9a3e5c88a5a60062219040b5ab0d311e92b01e"
assert hashlib.sha256(SRC.read_bytes()).hexdigest() == ORIG_SHA, "not Claude's commons_raised.py"
src = SRC.read_text()


def swap(old, new, count=1):
    global src
    assert src.count(old) == count, (src.count(old), old[:70])
    src = src.replace(old, new)


# 0. path only: find the vendored October sources beside this file (Claude's path was his own home folder)
swap('HERE = Path("/home/claude/piccolo_v1")', 'HERE = Path(__file__).resolve().parent')

# 1. switches
swap('ARM = {"H": False, "S": False, "F": False, "W": False}',
     'ARM = {"H": False, "S": False, "F": False, "W": False,\n'
     '       "G": False, "O": False, "A": False, "D": False, "K": False, "Y": False}   # v2 switches, all off by default')

V2_CODE = '''

# ---------------- RAISED v2 (history seat): read-only instruments and the open hand ----------------
V2 = {}


def _v2_reset():
    V2.clear()
    V2.update(RET=np.zeros((N, N)), OWN=-np.ones((N, N), dtype=np.int64), last_re=0.0,
              eaten_gross=0.0, reeaten=0.0, reeaten_self=0.0, reeaten_k=0.0, reeaten_s=0.0, returned_ground=0.0,
              low_before_share=0, lifted=0, lifted_keepers=0, lifted_scouts=0, excluded_by_D=0,
              o_passed=0.0, o_gifts=0, o_to_keepers=0.0, o_to_scouts=0.0, o_dist_sum=0.0, o_to_ground=0.0,
              o_nobody=0, f_to_keepers=0.0, f_to_scouts=0.0, pool=[])


def _v2_eat(a, e, R):
    """Called right after a member takes e from its cell. Returned food is taken in proportion to its share of the cell."""
    V2["last_re"] = 0.0
    e = float(e); V2["eaten_gross"] += e
    r = V2["RET"][a.x, a.y]
    if r <= 0 or e <= 0: return
    before = float(R[a.x, a.y]) + e
    re = min(r, e * min(1.0, r / before)) if before > 0 else 0.0
    V2["RET"][a.x, a.y] = r - re; V2["last_re"] = re; V2["reeaten"] += re
    V2["reeaten_s" if _is_scout(a) else "reeaten_k"] += re
    if V2["OWN"][a.x, a.y] == a.id: V2["reeaten_self"] += re


def _v2_ret(m, back):
    V2["RET"][m.x, m.y] += back; V2["OWN"][m.x, m.y] = m.id; V2["returned_ground"] += back


def _v2_regrow(R_old, R_new):
    f = np.where(R_old > 0, np.minimum(1.0, R_new / np.where(R_old > 0, R_old, 1.0)), 0.0)
    V2["RET"] *= f


def _v2_open_pass(m, back):
    """Open hand (10 Nov): the excess runs on to the two nearest others, half each; each takes at most its free room;
    what is refused runs on to the next two. Returns what nobody had room for."""
    cand = [a for a in V2["pool"] if a is not m and a.e < HAND - 1e-12]
    if not cand:
        V2["o_nobody"] += 1
        return back
    cand.sort(key=lambda a: (_cheb(m.x, m.y, a.x, a.y), a.id))
    i = 0
    while back > 1e-12 and i < len(cand):
        pair = cand[i:i + 2]; offer = back / len(pair)
        for a in pair:
            g = min(offer, HAND - a.e)
            if g <= 0: continue
            a.e += g; back -= g
            V2["o_passed"] += g; V2["o_gifts"] += 1; V2["o_dist_sum"] += g * _cheb(m.x, m.y, a.x, a.y)
            V2["o_to_scouts" if _is_scout(a) else "o_to_keepers"] += g
        i += 2
    if back <= 1e-12: back = 0.0
    return back


def _v2_after_eat(live, fams, R, t):
    low = [a for a in live if a.e <= 0]
    V2["low_before_share"] += len(low)
    if ARM["D"]:
        pool = [a for a in live if a.e > 0]; V2["excluded_by_D"] += len(live) - len(pool)
    else:
        pool = live
    V2["pool"] = pool
    _arm_after_eat(pool, fams, R, t)
    V2["pool"] = []
    for a in low:
        if a.e > 0:
            V2["lifted"] += 1; V2["lifted_scouts" if _is_scout(a) else "lifted_keepers"] += 1


def _v2_out():
    return {k: (round(v, 6) if isinstance(v, float) else v) for k, v in V2.items() if k not in ("RET", "OWN", "pool", "last_re")}


'''
swap("class Member:", V2_CODE + "class Member:")

# 2. G: grace step skipped when G is on
swap("        if t % GRACE_EVERY == 0:\n", "        if t % GRACE_EVERY == 0 and not ARM['G']:\n")

# 3. Y: young for one season
swap("def _young(a, t): return a.born > 0 and (t - a.born) < YOUNG_TICKS",
     "def _young(a, t): return a.born > 0 and (t - a.born) < (SEASON if ARM['Y'] else YOUNG_TICKS)")

# 4. K: F feeds young keepers only; plus read-only F-by-role count
swap("            young = [y for y in ms if _young(y, t)]\n",
     "            young = [y for y in ms if _young(y, t) and not (ARM['K'] and _is_scout(y))]\n")
swap('                    AR["f_gifts"] += 1; AR["f_given"] += g; _note(y.id, "got_f", g); _note(k.id, "gave_f", g)\n',
     '                    AR["f_gifts"] += 1; AR["f_given"] += g; _note(y.id, "got_f", g); _note(k.id, "gave_f", g)\n'
     '                    V2["f_to_scouts" if _is_scout(y) else "f_to_keepers"] += g\n')

# 5. O: open hand inside the H step; ground returns tracked for re-eating
swap("                    back = m.e - HAND; m.e = HAND\n"
     "                    R[m.x, m.y] += back; fam.period_harvest -= back\n",
     "                    back = m.e - HAND; m.e = HAND\n"
     "                    if ARM['O']:\n"
     "                        back = _v2_open_pass(m, back); V2['o_to_ground'] += back\n"
     "                    R[m.x, m.y] += back; fam.period_harvest -= back; _v2_ret(m, back)\n")

# 6. D and the rescue counter: the sharing step goes through the v2 wrapper
swap("        if ARM['H'] or ARM['S'] or ARM['F']: _arm_after_eat(live, fams, R, t)\n",
     "        if ARM['H'] or ARM['S'] or ARM['F']: _v2_after_eat(live, fams, R, t)\n")

# 7. reset, eating, regrowth instruments; A: net harvest in the October-style totals
swap("    global DG; DG = Diag(); _ar_reset()\n", "    global DG; DG = Diag(); _ar_reset(); _v2_reset()\n")
swap("            a.e += e - METAB; ht += e; fam.period_harvest += e; DG.eat(a, e, t)\n",
     "            _v2_eat(a, e, R)\n"
     "            a.e += e - METAB; ht += (e - V2['last_re']) if ARM['A'] else e; fam.period_harvest += e; DG.eat(a, e, t)\n")
swap("        R = np.clip(R + REGROW * R * (1 - R / Keff) + SEED_FOOD, 0, None)\n",
     "        _R_old = R\n"
     "        R = np.clip(R + REGROW * R * (1 - R / Keff) + SEED_FOOD, 0, None)\n"
     "        _v2_regrow(_R_old, R)\n")

# 8. output: the v2 sidecar (Claude's packed output and .arm.json are written exactly as before)
swap('        if ch in ARM: ARM[ch] = True\n',
     '        if ch in ARM: ARM[ch] = True\n'
     '    assert not (ARM["O"] and not ARM["H"]), "O (open hand) needs H (a hand has a size)"\n')
swap('    Path(str(outp) + ".arm.json").write_text(json.dumps(dict(arm="".join(k for k in "HSFW" if ARM[k]) or "-", **AR), sort_keys=True))\n',
     '    Path(str(outp) + ".arm.json").write_text(json.dumps(dict(arm="".join(k for k in "HSFW" if ARM[k]) or "-", **AR), sort_keys=True))\n'
     '    o = res; v2 = dict(switches="".join(k for k in "HSFWGOADKY" if ARM[k]) or "-", grace=packed["totals"]["grace"],\n'
     '              young_ticks=SEASON if ARM["Y"] else YOUNG_TICKS, harvest_total_reported=o["harvest_total"], **_v2_out())\n'
     '    v2["harvest_net"] = round(v2["eaten_gross"] - v2["reeaten"], 6)\n'
     '    Path(str(outp) + ".v2.json").write_text(json.dumps(v2, sort_keys=True))\n')

OUT.write_text(src)
print("wrote", OUT.name, len(src), hashlib.sha256(src.encode()).hexdigest())
