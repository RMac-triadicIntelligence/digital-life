"""Run each supplied Raised v2 arm and compare to archived and original replay bytes."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "replay"
ARCHIVE = ROOT / "original"
V1 = ROOT.parent / "raised-replay-2026-11-16/runs"
TICKS = 29200
V1_MATCH = {"E_off": "off", "E_full": "full", "E_H": "H", "E_HS": "HS", "E_HSF": "HSF"}


def digest_file(path):
    return sha256(path.read_bytes()).hexdigest()


def jobs():
    yield "E_off", "-", 0, 8000
    for seed in range(11):
        yield "E_full", "HSFW", seed, TICKS
    for name in ("H", "HS", "HSF"):
        for seed in range(3):
            yield f"E_{name}", name, seed, TICKS
    for seed in range(11):
        yield "v2full", "HSFWGOADKY", seed, TICKS
    for flag in "GOADKY":
        for seed in range(3):
            yield f"x_{flag}", f"HSFW{flag}", seed, TICKS
    for seed in range(11):
        yield "v2H", "HGOA", seed, TICKS
        yield "v2HS", "HSGOAD", seed, TICKS
        yield "v2HSF", "HSFGOADK", seed, TICKS


def simulate(job):
    arm, switches, seed, ticks = job
    dest = REPLAY / "runs" / arm / f"seed_{seed:02}.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "PYTHONDONTWRITEBYTECODE": "1"}
    run = subprocess.run([sys.executable, "commons_raised_v2.py", str(seed), str(ticks), str(dest), switches],
                         cwd=REPLAY, env=env, capture_output=True, text=True)
    log = dest.parent / f"log_{seed:02}.txt"
    log.write_text(run.stdout + run.stderr)
    if run.returncode:
        raise RuntimeError(f"{arm}/{seed} exited {run.returncode}: {log.read_text()}")
    archived = ARCHIVE / "runs" / arm / dest.name
    suffixes = ("", ".arm.json", ".v2.json")
    outputs = {}
    for suffix in suffixes:
        out = Path(str(dest) + suffix)
        expected = Path(str(archived) + suffix)
        relation = {"replay_sha256": digest_file(out), "archive_sha256": digest_file(expected)}
        relation["same_bytes"] = relation["replay_sha256"] == relation["archive_sha256"]
        if arm in V1_MATCH and suffix != ".v2.json":
            path = V1 / V1_MATCH[arm] / out.name
            relation["prior_v1_sha256"] = digest_file(path)
            relation["matches_prior_v1"] = relation["replay_sha256"] == relation["prior_v1_sha256"]
        outputs[suffix or "raw"] = relation
    outputs["diagnostic_sha256"] = digest_file(Path(str(dest) + ".diag.json"))
    outputs["log_matches_archive"] = log.read_bytes() == (ARCHIVE / "runs" / arm / log.name).read_bytes()
    print(f"{arm:6} seed {seed:02} {time.monotonic()-start:6.1f}s "
          f"raw={outputs['raw']['same_bytes']} arm={outputs['.arm.json']['same_bytes']} "
          f"v2={outputs['.v2.json']['same_bytes']}", flush=True)
    return {"arm": arm, "switches": switches, "seed": seed, "ticks": ticks, "outputs": outputs}


def main():
    prediction = digest_file(ROOT / "REPLAY_PREDICTIONS.md")
    assert prediction == (ROOT / "REPLAY_PREDICTIONS.sha256").read_text().split()[0]
    subprocess.run([sys.executable, "make_v2.py"], check=True, cwd=REPLAY)
    assert digest_file(REPLAY / "commons_raised_v2.py") == digest_file(ARCHIVE / "commons_raised_v2.py")
    planned = list(jobs())
    assert len(planned) == len(set(planned)) == 83
    for arm, _, seed, _ in planned:
        assert (ARCHIVE / "runs" / arm / f"seed_{seed:02}.json").exists()
    with (ROOT / "REPLAY_RECEIPTS.jsonl").open("w") as evidence, ThreadPoolExecutor(max_workers=9) as pool:
        for future in as_completed(pool.submit(simulate, job) for job in planned):
            row = future.result()
            evidence.write(json.dumps(row, sort_keys=True) + "\n")
            evidence.flush()


if __name__ == "__main__":
    main()
