"""Run the six preregistered W/Y jobs missing from the supplied schedule."""

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from verify_job_schedule import digest_file


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "replay"
FLAGS = {"w_only": "HSFWGOADK", "y_only": "HSFGOADKY"}


def simulate(job):
    name, seed = job
    switches = FLAGS[name]
    out = REPLAY / "runs" / name / f"seed_{seed:02}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    log = out.parent / f"log_{seed:02}.txt"
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "PYTHONDONTWRITEBYTECODE": "1"}
    start = time.monotonic()
    with log.open("w") as stream:
        subprocess.run([sys.executable, "commons_raised_v2.py", str(seed), "29200", str(out), switches],
                       cwd=REPLAY, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
    print(f"{name} seed {seed:02} {time.monotonic() - start:.1f}s", flush=True)
    return {"arm": name, "seed": seed, "switches": switches, "ticks": 29200,
            "sha256": {suffix or "raw": digest_file(out.with_name(out.name + suffix))
                       for suffix in ("", ".arm.json", ".v2.json", ".diag.json")}}


if __name__ == "__main__":
    assert digest_file(ROOT / "FOLLOWUP_PREDICTIONS.md") == (ROOT / "FOLLOWUP_PREDICTIONS.sha256").read_text().split()[0]
    assert digest_file(REPLAY / "commons_raised_v2.py") == digest_file(ROOT / "original/commons_raised_v2.py")
    plan = [(arm, seed) for seed in range(3) for arm in FLAGS]
    with ThreadPoolExecutor(max_workers=2) as pool:
        receipts = list(pool.map(simulate, plan))
    (ROOT / "FOLLOWUP_RECEIPTS.json").write_text(json.dumps(receipts, indent=2, sort_keys=True) + "\n")
