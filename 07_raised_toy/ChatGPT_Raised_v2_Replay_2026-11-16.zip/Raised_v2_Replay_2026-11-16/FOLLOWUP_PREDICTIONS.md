# Raised v2 follow-up predictions

The shipped reports and source are visible. Use two missing switch
combinations to separate W (required proximity to an adult keeper) and Y
(150 rather than 100 ticks of youth) on the v2HSF rung. Keep every other
switch fixed. Use seeds 0, 1, 2 and 29,200 ticks, the shipped ablation
schedule. Add W-only HSF W GOADK and Y-only HSF GOADK Y (spaces for display),
using the shipped v2HSF and v2full results for neither and both. No retuning.

Specify the primary endpoint in advance: the fraction of newborn scouts
that reach 240 ticks, calculated within each seed before taking an equal
mean across seeds. Report each seed and the pooled counts too. Secondary:
newborn keeper survival to 240 and 800 ticks, founding lineages present at
ten years, births after year one, and the W tick count. Use the shipped
analysis definitions for exact replay, then check endpoint and lineage
definitions separately before interpreting them.

1. The W-only switch will reduce scout survival in each of the three seeds
   compared with neither W nor Y.
2. The mean absolute scout survival change for Y-only versus neither will
   be smaller than the mean absolute change for W-only versus neither.
3. The both-on arm will have lower mean scout survival than W-only.
   The three-seed comparison is exploratory and conditional on these switches.
4. An O gift that leaves exactly zero to return still changes the cell's
   most recent returner id. If an earlier member deposited food there, a
   bite by the zero-return giver will falsely attribute the re-eaten food
   to that giver in the self-re-eating counter.
