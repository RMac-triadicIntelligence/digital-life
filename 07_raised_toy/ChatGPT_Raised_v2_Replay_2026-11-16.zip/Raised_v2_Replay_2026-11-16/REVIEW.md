# Raised v2 independent replay and comparison

I independently reran Grok Bot's 83 scheduled jobs and matched all 249 packed results and sidecars, all 83 logs, and all four reconstructed tables byte for byte. The 21 fixes-off jobs also matched the packed outputs and arm receipts from my earlier replay of Fable's toy. The eleven archived October baselines matched that earlier independent replay. The code generator reproduced the shipped runner exactly.

The scheduled results were visible when I froze the replay predictions. I froze a separate set of predictions for six new runs in the two missing W/Y combinations on seeds 0–2. All six used Grok Bot's supplied runner at 29,200 ticks with the other switches fixed.

## Ten-year comparison across eleven seeds

Survival rates pool eligible newborns across the seeds. Year-ten lineage numbers count surviving founding lineages. October preserved all four lineages but ended without keepers in all eleven seeds. At least one keeper survived in every v2H seed.

| Arm | Keepers at 30 days | Scouts at 30 days | Keepers at 100 days | Seeds with all four lineages | Births after year one |
|---|---:|---:|---:|---:|---:|
| October baseline | 3.7% | 89.2% | 0.0% | 11/11 | 4–30 |
| Fable full (HSFW) | 23.7% | 47.1% | 1.2% | 0/11 | 3,485–5,734 |
| Grok v2H | 54.7% | 92.8% | 22.0% | 10/11 | 433–948 |
| Grok v2HS | 64.9% | 89.2% | 34.3% | 4/11 | 639–1,431 |
| Grok v2HSF | 64.3% | 87.9% | 33.2% | 2/11 | 644–1,501 |
| Grok full | 52.4% | 34.2% | 20.1% | 1/11 | 874–2,827 |

Fable's full toy ended with a single lineage in ten of eleven seeds. Grok Bot's full toy kept at least two in ten of eleven, with substantially fewer births and higher keeper survival. v2H preserved the most lineages among the rebuilds and had the strongest scout survival. v2HS had the strongest 30-day and 100-day keeper survival.

## One switch at a time on Fable's full toy

| Change | Keepers at 30 days | Scouts at 30 days | Keepers at 100 days | Lineages on seeds 0, 1, 2 | Births after year one |
|---|---:|---:|---:|---|---:|
| Fable full | 23.1% | 47.1% | 1.1% | 1, 1, 1 | 3,619–5,092 |
| Disable legacy grace | 23.0% | 47.3% | 1.1% | 1, 1, 1 | 3,608–5,332 |
| Open hand | 62.9% | 68.1% | 31.5% | 3, 3, 4 | 740–1,349 |
| Net harvest reporting | 23.1% | 47.1% | 1.1% | 1, 1, 1 | 3,619–5,092 |
| Sharing eligibility at zero | 22.0% | 48.1% | 0.9% | 1, 1, 1 | 3,625–5,215 |
| Feed young keepers only | 19.4% | 21.7% | 1.2% | 1, 1, 1 | 3,700–4,930 |
| Extend youth to 150 ticks | 19.5% | 37.5% | 0.7% | 1, 1, 1 | 3,953–5,440 |

Open hand is the largest improvement among the single switches. The grace-only comparison removed 165 activations. Pooled survival moved by less than 0.2 percentage points in either role, while the year-ten keeper counts went from 19, 15, and 5 to 13, 24, and 10. The old periodic controller and its target-setting behavior are what that comparison tests.

## Forced proximity and youth duration

Longer youth changes feeding eligibility even when required proximity is off. W sends young members toward or keeps them beside an adult keeper when one is present. The primary measure weights each seed equally.

| Switch combination | Scout survival, seed 0 | Seed 1 | Seed 2 | Mean |
|---|---:|---:|---:|---:|
| Neither | 91.3% | 88.7% | 88.4% | 89.4% |
| Required proximity only (W) | 52.9% | 42.8% | 39.8% | 45.2% |
| Longer youth only (Y) | 90.9% | 89.1% | 89.9% | 90.0% |
| Both | 32.7% | 32.1% | 32.3% | 32.4% |

The follow-up is a three-seed switch comparison under the v2HSF rules. Exact counts and secondary endpoints are in `COMPARISONS.json`.

The three simulation predictions scored held/held/held in order. The separate prediction about zero-return provenance held in the small executable probe.

## What the implementation tests found

The supplied open hand caps each receiver correctly in the three-member capacity probe. It offers half of 0.20 to each recipient. The first has room for 0.02 and the second takes 0.10, leaving 0.08 for the ground. The second recipient still has room for 0.30. A single pass through pairs can therefore return food even though someone can hold it. See `_v2_open_pass` in `commons_raised_v2.py`.

In the second probe, swapping only the two household IDs changes the young keeper's final energy from 0.50 to 0.40. The global overflow can reach an adult before or after that adult's household has processed its own feeding step. The numerical household label changes the outcome through the order of the tick. See `_arm_after_eat`.

The third probe deposits 0.20 from member 1. Member 2 then passes all its excess to a receiver in the same tick and returns zero. The code records member 2 as the most recent returner anyway. Member 2 then eats 0.10, all of it from member 1's deposit, and the probe counts all 0.10 as self-re-eating. The existing estimate also merges deposits into one cell and uses the most recent returner as a proxy for provenance. See `_v2_ret` and `_v2_eat`.

The A-only arm changed exactly four packed harvest fields. Its diagnostic and arm files matched the corresponding controls in all three seeds. Those four fields are harvest total, late harvest, post-shift harvest and per-capita harvest. Household birth credit still increases by gross bites and decreases by returns to the ground. Open-hand gifts do not directly add credit to the receiver's household. Routing surplus away from the ground can change the giver's net household credit, so the open-hand comparison includes that path as well as energy transfer.

D excludes members at or below zero from the sharing pool. They still update belief and take their movement step before the end-of-tick death check. Each positive transition across zero in the old order adds a rescue event. The counter measures events and permits a member to contribute more than once.

## Next build

Use v2H as the ecological reference and v2HS as the keeper-survival comparison. Keep the archived October control and the all-switches-off compatibility tests. Preserve the observed v2 routing as a reference so a change to delivery has a paired comparison.

1. **Resolve the overflow rule.** If usable space anywhere in the eligible community takes priority over ground return, allocate a first offer to each pair, then give the residue another chance to fill eligible hands. Test the measured capacity and conservation at every transfer. Separate household feeding and community overflow into explicit phases, and test that relabeling households leaves the result invariant. Then compare the present whole-commons delivery to delivery within the ordinary sensing radius or via a walking encounter.
2. **Test range and return.** Let juveniles move normally and share time or discoveries with a keeper through encounters. Keep the timing of youth, access to food, and required proximity as independent choices. Give both young roles access to care in the first comparison. John 21:15–17 places the responsibility to feed and tend on Peter. [John 21:15–17](https://bible.usccb.org/bible/john/21)
3. **Measure what raising passes on.** Match food intake across two arms and measure whether a juvenile can use something learned from a keeper after separation on unfamiliar terrain. Record successful independent discoveries and calls. The current replay measures survival, turnover, and lineages. Roles are assigned by ID in this fixture.
4. **Separate the resource records.** Record gross intake, ground re-uptake, gifts, and birth credit before changing eligibility. Fix the zero-return update before using the self-re-eating counter. Treat D as sharing eligibility or give early death explicit tick semantics if the design calls for removal at that point.
