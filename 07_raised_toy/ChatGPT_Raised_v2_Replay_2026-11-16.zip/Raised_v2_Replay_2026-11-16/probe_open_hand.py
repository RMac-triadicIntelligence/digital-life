"""Exercise three small, executable cases on the supplied runner."""

from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isclose
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parent
SPEC = spec_from_file_location("raised_v2", ROOT / "replay/commons_raised_v2.py")
toy = module_from_spec(SPEC)
SPEC.loader.exec_module(toy)


def member(aid, x, energy, household=0, born=0):
    return SimpleNamespace(id=aid, x=x, y=0, e=energy, fam=household, born=born)


def reset(*flags):
    for name in toy.ARM:
        toy.ARM[name] = name in flags
    toy.DG = toy.Diag()
    toy._ar_reset()
    toy._v2_reset()


def uneven_capacity():
    reset("H", "O")
    giver = member(0, 0, 1.0)
    near = member(1, 1, 0.98)
    next_near = member(2, 2, 0.60)
    toy.V2["pool"] = [giver, near, next_near]
    returned = toy._v2_open_pass(giver, 0.20)
    room = toy.HAND - next_near.e
    assert isclose(returned, 0.08) and isclose(room, 0.30)
    return {"initial_surplus": 0.20, "initial_room": [0.02, 0.40],
            "ground_return": round(returned, 8), "room_after": round(room, 8)}


def household_order(giver_household):
    reset("H", "F", "O")
    other = 1 - giver_household
    giver = member(0, 0, 1.20, giver_household)
    keeper = member(1, 1, 0.50, other)
    young = member(2, 2, 0.30, other, born=1)
    assert toy._is_scout(giver) and not toy._is_scout(keeper)
    households = {i: SimpleNamespace(period_harvest=0.0) for i in range(2)}
    ground = toy.np.zeros((toy.N, toy.N))
    toy._v2_after_eat([giver, keeper, young], households, ground, t=50)
    return {"giver_household_id": giver_household, "young_energy": round(young.e, 8),
            "adult_energy": round(keeper.e, 8), "within_household_feed": round(toy.AR["f_given"], 8)}


def zero_return_provenance():
    reset("H", "O")
    prior_giver = member(1, 0, 1.0)
    zero_return_giver = member(2, 0, 1.20)
    receiver = member(3, 1, 0.50)
    ground = toy.np.zeros((toy.N, toy.N))
    ground[0, 0] = 0.20
    toy._v2_ret(prior_giver, 0.20)
    owner_before = int(toy.V2["OWN"][0, 0])
    household = {0: SimpleNamespace(period_harvest=0.0)}
    toy._v2_after_eat([zero_return_giver, receiver], household, ground, t=50)
    owner_after = int(toy.V2["OWN"][0, 0])
    returned_by_second = toy.V2["returned_ground"] - 0.20
    ground[0, 0] -= 0.10
    toy._v2_eat(zero_return_giver, 0.10, ground)
    self_count = toy.V2["reeaten_self"]
    assert owner_before == prior_giver.id and owner_after == zero_return_giver.id
    assert isclose(returned_by_second, 0.0) and isclose(self_count, 0.10)
    return {"recorded_returner_before": owner_before, "recorded_returner_after": owner_after,
            "second_ground_return": returned_by_second, "counted_as_self_reeating": self_count,
            "actual_self_reeating_in_probe": 0.0}


if __name__ == "__main__":
    early = household_order(0)
    late = household_order(1)
    assert early["young_energy"] == 0.50 and late["young_energy"] == 0.40
    report = {"uneven_capacity": uneven_capacity(), "household_order": [early, late],
              "zero_return_provenance": zero_return_provenance()}
    print(json.dumps(report, indent=2, sort_keys=True))
