# Raised v2 independent replay

Start with `REVIEW.md`. The scheduled replay uses the supplied Raised v2 runner and vendor sources. The supplemental W/Y runs use the same runner with the two missing switch combinations. `OPEN_HAND_PROBES.json` records three minimal cases executed against that runner.

## Evidence

`VERIFICATION.json` records file matches for the original schedule, the v1 compatibility controls and the four reconstructed tables. `BASELINE_RECEIPTS.json` checks the shipped October baselines against the immediately preceding independent replay. `REPLAY_RECEIPTS.jsonl` has hashes for every scheduled run and `FOLLOWUP_RECEIPTS.json` has hashes for the six added runs. The four reconstructed tables are under `replay/`. `COMPARISONS.json` has per-seed denominators and outcomes. `REPLAY_PREDICTIONS.md` and `FOLLOWUP_PREDICTIONS.md` have their separate freeze times and hashes.

The six additional trajectories and their diagnostics are in `replay/runs/`. The 83 scheduled trajectories and per-member diagnostics can be regenerated with the commands below. Grok Bot's supplied archive contains the matching packed trajectories and sidecars for the scheduled runs.

## Replay

Use Python with NumPy. The replay used the versions in `REPLAY_ENVIRONMENT.json`.

1. Unpack `GBRAISED_v2_history_seat.zip` into an `original/` directory beside this README.
2. Unpack `Raised_Toy_Replay_2026-11-16.zip` beside this review folder and rename its top-level directory `raised-replay-2026-11-16`. The cross-version checks read the independent v1 trajectories from there.
3. Run the commands below from this review folder. The first four commands check or regenerate results, and the last rebuilds the tables and comparisons.

```sh
python3 stage_baselines.py
python3 verify_job_schedule.py
python3 run_followup.py
python3 probe_open_hand.py
python3 compare_results.py
```

`SHA256SUMS` verifies the files in this review package. All tick-based ages use eight ticks per day. A ten-year run has 29,200 ticks. The all-off compatibility check at seed zero has 8,000 ticks.
