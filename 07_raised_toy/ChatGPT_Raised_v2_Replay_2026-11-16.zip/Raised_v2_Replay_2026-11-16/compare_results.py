"""Compare the replay, audit preservation, and score the W/Y follow-up."""

from fractions import Fraction
import json
import statistics
import subprocess

from verify_job_schedule import ARCHIVE, REPLAY, ROOT, digest_file, jobs


TABLES = ("summary_main.json", "summary_ablation_seeds_0_2.json",
          "v2_tables_main.json", "v2_tables_ablation_seeds_0_2.json")
RUNG_ARMS = ("baseline", "E_full", "v2H", "v2HS", "v2HSF", "v2full")
SINGLE_ARMS = ("baseline", "E_H", "E_HS", "E_HSF", "E_full", "x_G", "x_O", "x_A", "x_D", "x_K", "x_Y")
FOLLOWUP_ARMS = ("v2HSF", "w_only", "y_only", "v2full")
HARVEST_FIELDS = ("harvest_total", "harvest_late", "post_shift", "per_capita")


def read(path):
    return json.loads(path.read_bytes())


def run_path(arm, seed, suffix=""):
    return REPLAY / "runs" / arm / f"seed_{seed:02}.json{suffix}"


def rebuild_tables():
    subprocess.run(["bash", "analyse_all.sh"], cwd=REPLAY, check=True)
    result = {}
    for name in TABLES:
        ours = REPLAY / name
        shipped = ARCHIVE / name
        result[name] = {"same_bytes": ours.read_bytes() == shipped.read_bytes(),
                        "same_json": read(ours) == read(shipped),
                        "replay_sha256": digest_file(ours), "archive_sha256": digest_file(shipped)}
    return result


def preservation(tables):
    replay = [json.loads(line) for line in (ROOT / "REPLAY_RECEIPTS.jsonl").read_text().splitlines()]
    planned = set(jobs())
    assert {(r["arm"], r["switches"], r["seed"], r["ticks"]) for r in replay} == planned and len(replay) == len(planned)
    suffixes = ("raw", ".arm.json", ".v2.json")
    identical = {suffix: sum(r["outputs"][suffix]["same_bytes"] for r in replay) for suffix in suffixes}
    controls = [r for r in replay if r["arm"].startswith("E_")]
    identical_to_v1 = {suffix: sum(r["outputs"][suffix]["matches_prior_v1"] for r in controls) for suffix in suffixes[:-1]}
    baseline = read(ROOT / "BASELINE_RECEIPTS.json")
    followup = read(ROOT / "FOLLOWUP_RECEIPTS.json")
    assert len(baseline) == 11 and len(followup) == 6
    return {"runs": len(replay), "matching_archive_by_output_type": identical,
            "matching_archive_logs": sum(r["outputs"]["log_matches_archive"] for r in replay),
            "fixes_off_runs": len(controls), "fixes_off_matching_v1": identical_to_v1,
            "baseline_runs": len(baseline), "baseline_matching_prior_replay": sum(b["same_bytes"] for b in baseline),
            "followup_runs": len(followup), "tables": tables,
            "regenerated_source_sha256": digest_file(REPLAY / "commons_raised_v2.py")}


def audit_a_only():
    comparisons = []
    for seed in range(3):
        control = read(run_path("E_full", seed))
        arm = read(run_path("x_A", seed))
        metrics = {}
        for field in HARVEST_FIELDS:
            metrics[field] = {"gross": control["october_style_summary"].pop(field),
                              "net": arm["october_style_summary"].pop(field)}
        other_same = control == arm
        arm_same, diag_same = (run_path("E_full", seed, suffix).read_bytes() == run_path("x_A", seed, suffix).read_bytes()
                              for suffix in (".arm.json", ".diag.json"))
        assert other_same and arm_same and diag_same
        comparisons.append({"seed": seed, "harvest_fields": metrics, "other_raw_equal": other_same,
                            "arm_bytes_equal": arm_same, "diagnostic_bytes_equal": diag_same})
    return comparisons


def survival(rows, scout, age, ticks):
    # Match the supplied analysis: count members born far enough before the
    # end, and members whose death tick is at least `age` ticks after birth.
    group = [r for r in rows if r["parent"] is not None and r["scout"] == scout and r["born"] + age <= ticks]
    survived = sum(r["died"] is None or r["died"] - r["born"] >= age for r in group)
    return [survived, len(group)]


def outcomes(arm, seed):
    raw = read(run_path(arm, seed))
    diag = read(run_path(arm, seed, ".diag.json"))
    grown = raw["members_alive"]
    year = raw["yearly"]
    arm_side = run_path(arm, seed, ".arm.json")
    a = read(arm_side) if arm_side.exists() else {}
    founder_lineages = {m["lineage"] for m in grown if m["born"] == 0}
    founder_lineages.update(m[1] for m in raw["members_dead"] if m[2] == 0)
    surviving_lineages = {m["lineage"] for m in grown}
    assert surviving_lineages <= founder_lineages
    result = {"seed": seed, "lineages_at_year_10": sorted(surviving_lineages),
              "keepers_at_year_10": sum(not m["scout"] for m in grown), "population_at_year_10": len(grown),
              "births_after_y1": year[-1]["births"] - year[0]["births"],
              "legacy_grace": raw["totals"]["grace"], "with_ticks": a.get("with_ticks", 0)}
    for role, scout in (("keepers", False), ("scouts", True)):
        for days in (30, 100):
            result[f"{role}_{days}d"] = survival(diag, scout, days * raw["ticks_per_day"], raw["ticks"])
    return result


def pool_arm(results):
    total = {}
    for label in ("keepers_30d", "keepers_100d", "scouts_30d", "scouts_100d"):
        pairs = [r[label] for r in results]
        n, d = map(sum, zip(*pairs))
        rates = [Fraction(count, eligible) for count, eligible in pairs if eligible]
        total[label] = {"count": n, "eligible": d, "pooled_rate": n / d if d else None,
                        "mean_seed_rate": float(statistics.mean(rates)) if rates else None}
    total["all_four_lineages"] = sum(len(r["lineages_at_year_10"]) == 4 for r in results)
    total["multiple_lineages"] = sum(len(r["lineages_at_year_10"]) >= 2 for r in results)
    total["seeds_with_keepers"] = sum(r["keepers_at_year_10"] > 0 for r in results)
    return total


def suite(arms, n_seeds):
    results = {}
    for name in arms:
        per_seed = [outcomes(name, i) for i in range(n_seeds)]
        results[name] = {"summary": pool_arm(per_seed), "by_seed": per_seed}
    return results


def compare_endpoint(shipped, independent):
    for name, measured in independent.items():
        for role in ("keepers", "scouts"):
            for days in (30, 100):
                m = measured["summary"][f"{role}_{days}d"]
                count, eligible, _ = shipped[name][f"newborn_{role}_{days}d"]
                assert (m["count"], m["eligible"]) == (count, eligible)
        assert [len(r["lineages_at_year_10"]) for r in measured["by_seed"]] == shipped[name]["lineages_10y"]


def score_followup(followup):
    rates = {name: [float(Fraction(*r["scouts_30d"])) for r in arm["by_seed"]] for name, arm in followup.items()}
    neither = rates["v2HSF"]
    w, y, both = (rates[n] for n in ("w_only", "y_only", "v2full"))
    mean = {n: statistics.mean(v) for n, v in rates.items()}
    return {"scouts_30d_seed_rates": rates, "scouts_30d_mean_seed_rates": mean,
            "W_hurts_each_seed": all(a < b for a, b in zip(w, neither)),
            "mean_abs_Y_only_smaller_than_W_only": statistics.mean(abs(a - b) for a, b in zip(y, neither))
            < statistics.mean(abs(a - b) for a, b in zip(w, neither)),
            "both_mean_below_W_only": mean["v2full"] < mean["w_only"],
            "W_only_minus_neither": [a - b for a, b in zip(w, neither)],
            "Y_only_minus_neither": [a - b for a, b in zip(y, neither)],
            "both_minus_W_only": [a - b for a, b in zip(both, w)]}


if __name__ == "__main__":
    tables = rebuild_tables()
    verification = preservation(tables)
    (ROOT / "VERIFICATION.json").write_text(json.dumps(verification, indent=2) + "\n")
    rungs, singles, followup = suite(RUNG_ARMS, 11), suite(SINGLE_ARMS, 3), suite(FOLLOWUP_ARMS, 3)
    compare_endpoint(read(REPLAY / "v2_tables_main.json"), rungs)
    compare_endpoint(read(REPLAY / "v2_tables_ablation_seeds_0_2.json"), singles)
    results = {"rungs": rungs, "one_switch": singles, "A_reporting_only": audit_a_only(),
               "W_Y_followup": followup, "W_Y_followup_predictions": score_followup(followup)}
    (ROOT / "COMPARISONS.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
