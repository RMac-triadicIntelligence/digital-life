# Independent Raised v2 replay predictions

The reports, implementation diff and packaged outcomes are already visible.
This is a reproduction and targeted interface audit, with no blind claims.
Run the supplied program unmodified for its 83-job schedule: 21 equivalence
jobs, 18 single-switch additions, and 44 v2 ladder jobs. Compare the 11
archived baseline trajectories to the independently run original baselines
from the immediately preceding replay. Compare code, receipts and reconstructed
tables. Do not tune any parameter.

1. Expect every simulated output to be equivalent to the archive, aiming for
   exact bytes. Sidecar rounding can expose runtime-dependent floating math.
   Expect all 21 fixes-off packed outputs and arm receipts to equal the original
   replay, including the 8,000-tick neutral control.
2. Expect the G-only arm to remove the legacy intervention with little effect
   on the published pooled 30-day survival rates for its three seeds. Expect O
   to materially improve those rates in the matched comparison. Expect v2HS and
   v2HSF to outperform v2full on juvenile scout survival while retaining more
   lineages. Check the per-seed results, not only pooled percentages.
3. Expect A to change harvest reporting while keeping trajectories equal.
   D excludes members at or below zero from transfers, but code order suggests
   those members still take the ordinary movement step before removal.
4. The O description says only surplus no recipient can hold returns to the
   ground. Predict that with two recipients and uneven capacity, a one-pass
   pair split can return surplus while one recipient still has room. Also probe
   whether gift delivery depends on the sequential order of households.
5. Compare broad outcomes and distinguish single-switch contrasts from bundled
   changes. Do not characterize lineage and 30-day survival in this fixture as
   proof of teaching or a universally effective resource policy.
