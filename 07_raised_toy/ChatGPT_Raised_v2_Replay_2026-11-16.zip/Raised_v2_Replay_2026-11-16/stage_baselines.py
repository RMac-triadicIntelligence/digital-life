"""Check and stage the previously regenerated ten-year baseline traces."""

import json
from pathlib import Path
import shutil
import sys

from verify_job_schedule import ARCHIVE, REPLAY, ROOT, V1, digest_file


if __name__ == "__main__":
    prior = Path(sys.argv[1]) if len(sys.argv) > 1 else V1 / "baseline"
    archived = ARCHIVE / "runs/baseline"
    dest = REPLAY / "runs/baseline"
    dest.mkdir(parents=True, exist_ok=True)
    receipts = []
    for seed in range(11):
        file = f"seed_{seed:02}.json"
        actual = prior / file
        diag = actual.with_name(actual.name + ".diag.json")
        shipped_hash = digest_file(archived / file)
        prior_hash = digest_file(actual)
        receipts.append({"file": file, "archive_sha256": shipped_hash, "prior_independent_sha256": prior_hash,
                         "diagnostic_sha256": digest_file(diag), "same_bytes": shipped_hash == prior_hash})
        for path in (actual, diag):
            target = dest / path.name
            if not target.exists() or digest_file(target) != digest_file(path):
                shutil.copyfile(path, target)
    (ROOT / "BASELINE_RECEIPTS.json").write_text(json.dumps(receipts, indent=2) + "\n")
    assert all(r["same_bytes"] for r in receipts)
