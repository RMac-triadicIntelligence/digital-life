# Raised Toy independent replay

This is a replay of the 15 Nov 2026 Raised Toy, using Python and NumPy
as recorded in REPLAY_ENVIRONMENT.json. The replay ran 20 scored archived
arms, the packaged 8,000-tick control and 11 all-switches-off baselines
at ten years. The advice in REVIEW.md is a design proposal for a future
build.

## Inspect

- REVIEW.md gives the outcomes, discrepancies and rebuild advice.
- REPLAY_PREDICTIONS.md records the pre-run predictions, with its SHA-256
  and UTC freeze time alongside.
- RUN_RECEIPTS.jsonl records the SHA-256 for the raw output, arm
  receipt and per-member diagnostics of every run.
- VERIFICATION.json records exact comparison counts and summary differences.
- COMPARISONS.json contains the matched ladder and full/baseline comparisons.
- LEGACY_INTERVENTION.json gives the recorded legacy grace counts by
  arm, seed and role.
- PEDIGREES.json reports living parent-link depths by seed.
- REBUILD.md records the practical next comparisons.
- Both reconstructed summaries use the archived analysis program and
  regenerated diagnostic records.
- runs/ contains all archived-arm and baseline replays with their
  per-member diagnostic sidecars. The three-seed summary used only
  seeds 0–2 for each arm.

## Reproduce

Use a clean output directory containing replay.py, verify_replay.py,
compare_arms.py, read_pedigree.py and the three REPLAY_PREDICTIONS files. Put the two
original ZIPs, raised_toy_2026-11-15.zip and
FablePiccoloworkbench_2026-11-14f.zip, in the sibling upload/ directory.
The second provides the hash-pinned October simulations. The runner
copies only the validated Commons dependency files. It makes a
one-line portable copy of the frozen simulation source to resolve
the vendor directory locally. The archived rules, inputs and output
serializer are used.

    python3 replay.py
    python3 verify_replay.py
    python3 compare_arms.py
    python3 read_pedigree.py

The source/ directory contains the archived simulation and analysis,
the relocated runner, and the vendor dependencies used. The archived
generation helper expects a separate historical keeper-diagnostic base
source. Replay uses the frozen generated simulation in the original ZIP.
