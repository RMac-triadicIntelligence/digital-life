"""Report measured rebuild dependencies from the reconstructed simulation summaries."""
from collections import Counter
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_bytes())


def local_run(label, seed):
    return read(f"runs/{label}/seed_{seed:02}.json")


def report_arm(data):
    pooled = data["pooled"]
    seeds = data["seeds"]
    return {
        "keeper_30_days": pooled["KN"]["survive"]["240"],
        "scout_30_days": pooled["SN"]["survive"]["240"],
        "keeper_100_days": pooled["KN"]["survive"]["800"],
        "scout_100_days": pooled["SN"]["survive"]["800"],
        "lineages_by_seed": [value["lineages_alive"] for value in seeds.values()],
        "keepers_by_seed": [value["keepers_alive"] for value in seeds.values()],
        "births_after_year_1": [value["births_after_y1"] for value in seeds.values()],
        "food_to_young": round(sum(value["f_given"] for value in seeds.values()), 2),
        "food_to_keepers": round(sum(value["s_given"] for value in seeds.values()), 2),
    }


def age_30_by_seed(label):
    rows = []
    for seed in range(3):
        diag = read(f"runs/{label}/seed_{seed:02}.json.diag.json")
        cohorts = {}
        for name, scout in (("keep", False), ("scout", True)):
            eligible = [member for member in diag
                        if member["scout"] is scout and member["parent"] is not None
                        and member["born"] + 240 <= 29200]
            survived = sum(member["died"] is None or member["died"] - member["born"] >= 240
                           for member in eligible)
            cohorts[name] = {"survived": survived, "eligible": len(eligible),
                             "fraction": survived / len(eligible) if eligible else None}
        rows.append({"seed": seed, **cohorts})
    return rows


def main():
    ladder = read("summary_ladder_seeds_0_2.json")["arms"]
    primary = read("summary.json")["arms"]
    full = [local_run("full", seed) for seed in range(11)]
    baseline = [local_run("baseline", seed) for seed in range(11)]
    role_baseline = Counter()
    role_raised = Counter()
    for arm, counter in ((baseline, role_baseline), (full, role_raised)):
        for run in arm:
            counter["founders_alive"] += sum(member["born"] == 0 for member in run["members_alive"])
            counter["grace"] += run["totals"]["grace"]
    out = {
        "ladder": {("full" if arm == "HSFW" else arm): report_arm(data) for arm, data in ladder.items()},
        "ladder_30d_by_seed": {arm: age_30_by_seed(arm) for arm in ("baseline", "H", "HS", "HSF", "full")},
        "baseline": report_arm(primary["baseline"]) | dict(role_baseline),
        "full": report_arm(primary["full"]) | dict(role_raised),
    }
    (ROOT / "COMPARISONS.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
