# Raised toy replay predictions

Scope: reproduce the 20 archived ten-year trials and the archived 8,000-tick all-switches-off control without changing rules. Also rerun the 11 ten-year all-switches-off baselines used in the comparisons. Use the archived October dependency by pinned hash. Only relocate the hard-coded vendor path. Run the archived analysis on regenerated per-member records. No new intervention or keeper policy is tested.

1. Expect all 21 packaged run data files and their 21 arm receipts to match bytes. Expect baseline and full summaries to match on their published metrics. Platform-level JSON or floating differences would surprise me and will be localized at the first differing field.
2. Expect the three-seed H to HS comparison to reproduce the large improvement in newborn keeper survival at 30 days. Expect HSF to HSFW to reproduce lower juvenile survival in both roles and greater keeper-to-young transfers.
3. Expect the full toy to have keepers at year ten in 11 of 11 seeds and retain one founding lineage in 10 of 11. Expect no grace events in the full arm. Any baseline trajectory diverging from the documented ten-year metrics will remain visible alongside the reported values.
