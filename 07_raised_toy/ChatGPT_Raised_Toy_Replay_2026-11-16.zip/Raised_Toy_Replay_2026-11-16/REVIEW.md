# Raised Toy replay findings

Source: raised_toy_2026-11-15.zip. The independently run outputs and
comparisons are alongside this report. The code followed the archived
seed and arm schedule. Additional baselines reproduced each of the
11 ten-year comparison trajectories from the all-switches-off runner.
The runtime used Python 3.12.14 and NumPy 2.3.5. The only source-line
adjustment relocated the vendor directory, and the imported October
simulations were verified against their pinned digests.

All 21 packaged run outputs and their 21 arm receipts matched byte for
byte. Both summary reconstructions match on every reported outcome.
The replay records a zero for the disabled W movement mode and cap
bookkeeping in the all-switches-off baseline, where the old diagnostic
listed no W entry and no cap value. That produces 15 field differences
in the full summary and seven in the three-seed summary.

## Unexpected result

Prediction 3 expected zero grace events in the full arm. The baseline
had zero, but the full toy had 598 activations of the legacy routine,
33–69 in every seed. On the three ladder seeds the counts were H 673,
HS 169, HSF 184 and HSFW 165. Across all 11 full runs, archived member
records attribute 428 to scouts and 170 to keepers. Summing the
per-member counts reproduces the arm totals. The prediction failed.
The replay bytes reproduce Fable's raw result exactly.

The toy carried forward the old periodic intervention. It resets the
member's dwelling state and can assign a target from the household's
confirmed finds. It is distinct from the new hand transfers. The
raising and survival comparisons therefore include a legacy mechanism
whose actual exposure changes across arms. The stored runs establish
when it was active in aggregate. They leave open how much it changed
survival, births, or lineage concentration. The first proposed new arm
is a legacy-intervention disable control with the exact same raising
rules and paired world seeds.

## What matters for a rebuild

The three-seed ladder pools the newborn cohorts from the same seeds
0–2 at each step. This compares complete world runs, so cohort sizes
and identities differ. A seed is the unit of replication.

| Arm | Newborn keepers alive at 30 days | Newborn scouts alive at 30 days |
|---|---:|---:|
| October | 2.54% | 91.00% |
| H, hand and return to ground | 0.37% | 75.79% |
| HS, add scout overflow to keepers | 35.41% | 75.30% |
| HSF, add nearby keeper gifts to young | 33.98% | 74.94% |
| HSFW, add forced proximity to a keeper | 23.11% | 47.13% |

The HS step is strong evidence for this resource transfer in this
fixture. The W step delivered more food from keeper to young (93.09
to 2,752.14 units across compared worlds) and reduced 30-day survival.
It also replaced ordinary juvenile movement on ticks with a keeper.
The design bundles proximity, travel, foraging alternatives and gifts.
Its lower survival is an outcome of that bundle. Adjusted age-specific
intake and a range-and-return comparison can separate those mechanisms.

Across all eleven full trials, each world had keepers at year ten.
Newborn keepers had 23.66% survival to 30 days and 1.2% survival to
100 days. All 264 original founders died. Ten of eleven worlds had
one founding lineage at the end, and one world had two. Living members
were 24–60 parent links from a founder. October retained all four
lineages and had living descendants from all four in every replay
at year ten, with living members zero to four links from a founder.
That demonstrates very different turnover and lineage concentration.
October's coexistence of founders and descendants does not show which
lineages would persist if its founders died.

The current H switch reduces stored reserves, returns the overflow to
edible ground and deducts that return from household harvest credit.
Physical stock and harvest credit subsequently enter the birth checks.
Separate those variables so the next build can establish which feedback
explains the change in births. Track lineage persistence alongside
population and cohort survival.

The full reconstruction used the archived cohort definition. Regenerated
diagnostics are included, and the originals from Fable's bench were not
in the delivered ZIP. The published comparisons and all seed/pedigree
calculations can be inspected directly in the evidence package.

See REBUILD.md for the proposed controls and interpretation boundaries.
