# Proposed rebuild for the Raised Toy

## Isolate the legacy intervention first

The October baseline had zero legacy grace activations. The full
Raised Toy had 598 and hand-only had 673 across three seeds. The current
legacy path writes dwelling and may assign a confirmed family target.
Cross the same arm schedule with that routine enabled and disabled.
Keep the default on to reproduce the archived behavior. Record who
would qualify, when it fired, whether it assigned a target, and what
happened to intake and survival afterward. Retain grace as a distinct
future test with its own rules.

## Isolate which part of the hand changes the Commons

Begin with October and the existing H arm as the reference points. H
currently does three things at once. It lowers individual reserves to one
unit, returns surplus as edible food to the same grid cell, and subtracts
that return from the household harvest count used at the birth gate.
At a cost of 0.025 per tick and a cap of 1.0, 40 unfed and unaided ticks
can consume a full reserve. That short runway is part of the experiment,
alongside recycling of food and the changed birth accounting.

Log gross intake, transfers, return to ground, metabolic expenditure,
and birth credit as distinct quantities. After fixing the exact metrics
and arms, compare a bounded reserve alone with a bounded reserve and
food return. If a cap-only control removes surplus from circulation,
record it explicitly as outflow. Compare gross and net household
harvest credit with the same return rule. Keep the stock threshold
constant. Record which birth condition blocks each attempt, living
lineages over time, depth of living pedigrees, and the number of
different parents per lineage. Test out-of-sample seeds after the three
ladder seeds. Retain mortality and loss of lineages even if they
contradict the hoped-for path.

## Give a young member freedom to range and return

Keep scout support for keepers fixed. Compare the existing unrestricted
movement, the existing forced proximity, and a candidate where a young
member can range and return to a keeper. The reference with local keeper
feeding is HSF. In the current HSFW arm, finding a keeper makes the
young member take the keeper branch instead of its normal movement
policy. That intervention changes proximity, travel, access to own food,
and keeper gifts together. The current ladder identifies the total
effect of adding W after HSF.

For the immediate comparison, record intake from the ground and gifts
by age and role, time spent following or near a keeper, and time near
food with and without a keeper. Report the paired seed effects along
with pooled member counts. Follow the cohort through the end of the
first season and after aid stops. Treat the age/role mix and population
feedback as outcomes of these world simulations. The identical seed
holds the environmental schedule fixed. Agent actions and random draw
order can diverge across arms.

If the next claim is about teaching, define one concrete thing an adult
can pass to a juvenile and show the juvenile using it later. Compare
that result with food-matched care. Measure independent intake on
unfamiliar ground and survival after aid ends. Evidence of that ability
would support a claim about raising beyond proximity and calories.

## Preserve the experiment as a runnable package

Put the exact October source, the frozen generated program, the analysis
program, and the original generator input or a clearly identified
reference to it alongside the runnable entry point. Include checksums
and the per-member diagnostics used to score the results. Keep the
simulated resource transfers distinct from any later test of grace or
signed facets. The replay uses the frozen October behavior and the
archive's resource rules.
