"""Read parent depth from regenerated diagnostic sidecars."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
COUNTS = {"baseline": 11, "H": 3, "HS": 3, "HSF": 3, "full": 11}


def main():
    rows = []
    for label, seeds in COUNTS.items():
        for seed in range(seeds):
            path = ROOT / "runs" / label / f"seed_{seed:02}.json"
            result = json.loads(path.read_bytes())
            diag = json.loads(Path(str(path) + ".diag.json").read_bytes())
            depths = {}
            for row in sorted(diag, key=lambda item: item["id"]):
                parent = row["parent"]
                depths[row["id"]] = 0 if parent is None else depths[parent] + 1
            members = result["members_alive"]
            depth = [depths[member["id"]] for member in members]
            assert sorted(member["id"] for member in members) == sorted(
                row["id"] for row in diag if row["died"] is None)
            rows.append({
                "arm": label,
                "seed": seed,
                "living_lineages": len({member["lineage"] for member in members}),
                "living_founders": depth.count(0),
                "lineages_with_living_descendants": len({member["lineage"] for member in members
                                                         if depths[member["id"]] > 0}),
                "minimum_living_pedigree_depth": min(depth) if depth else None,
                "maximum_living_pedigree_depth": max(depth) if depth else None,
            })
    (ROOT / "PEDIGREES.json").write_text(json.dumps(rows, indent=2) + "\n")
    for label in COUNTS:
        group = [row for row in rows if row["arm"] == label]
        print(label, "founders alive", sum(row["living_founders"] for row in group),
              "living depths", min(row["minimum_living_pedigree_depth"] for row in group),
              max(row["maximum_living_pedigree_depth"] for row in group))


if __name__ == "__main__":
    main()
