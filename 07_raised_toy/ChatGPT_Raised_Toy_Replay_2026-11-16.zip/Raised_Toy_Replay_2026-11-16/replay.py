"""Reproduce the archived Raised Toy using its original October Commons dependency."""
from concurrent.futures import ProcessPoolExecutor, as_completed
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
ATTACHMENTS = ROOT.parent / "upload"
TOY = ATTACHMENTS / "raised_toy_2026-11-15.zip"
OCTOBER = ATTACHMENTS / "FablePiccoloworkbench_2026-11-14f.zip"
PREFIX = "raised_toy_2026-11-15/"
VENDOR_PREFIX = "workbench_2026-11-14f/15_piccolo_v1/vendor/"
RUNS = ROOT / "runs"


def copy_sources():
    with ZipFile(TOY) as source:
        for name in ("commons_raised.py", "analyse_raised.py", "PREREG_and_PREDICTIONS.md", "FROZEN.sha256"):
            target = ROOT / "source" / name
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(source.read(PREFIX + name))
        for line in (ROOT / "source/FROZEN.sha256").read_text().splitlines():
            checksum, name = line.split()
            assert sha256(source.read(PREFIX + name)).hexdigest() == checksum, name
    with ZipFile(OCTOBER) as vendor:
        manifest_name = VENDOR_PREFIX.replace("vendor/", "MANIFEST.sha256")
        manifest = dict((name.removeprefix("./"), checksum) for checksum, name in
                        (line.split(maxsplit=1) for line in vendor.read(manifest_name).decode().splitlines()))
        for name in vendor.namelist():
            if name.startswith(VENDOR_PREFIX + "commons/") and not name.endswith("/"):
                relative = "vendor/" + name.removeprefix(VENDOR_PREFIX)
                data = vendor.read(name)
                assert sha256(data).hexdigest() == manifest[relative], relative
                target = ROOT / "source" / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
    original = ROOT / "source/commons_raised.py"
    patched = ROOT / "source/commons_raised_portable.py"
    slash = original.read_bytes()
    line = b'HERE = Path("/home/claude/piccolo_v1")'
    assert slash.count(line) == 1
    patched.write_bytes(slash.replace(line, b'HERE = Path(__file__).resolve().parent'))


def simulate(job):
    label, switch, seed, ticks = job
    path = RUNS / label / f"seed_{seed:02}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    command = [sys.executable, str(ROOT / "source/commons_raised_portable.py"),
               str(seed), str(ticks), str(path), switch]
    env = os.environ | {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"}
    proc = subprocess.run(command, text=True, capture_output=True, env=env, cwd=ROOT)
    if proc.returncode:
        raise RuntimeError(f"{label}/{seed}: {proc.stderr}\n{proc.stdout}")
    record = {"label": label, "switch": switch, "seed": seed, "ticks": ticks,
              "checksum": sha256(path.read_bytes()).hexdigest(),
              "arm_checksum": sha256(Path(str(path) + ".arm.json").read_bytes()).hexdigest(),
              "diagnostic_checksum": sha256(Path(str(path) + ".diag.json").read_bytes()).hexdigest()}
    if label != "baseline":
        with ZipFile(TOY) as source:
            name = PREFIX + f"{label}/{path.name}"
            record["matches_archived_run"] = path.read_bytes() == source.read(name)
            record["matches_archived_arm"] = Path(str(path) + ".arm.json").read_bytes() == source.read(name + ".arm.json")
    print(f"{label:8} seed {seed:02}: {time.monotonic()-start:.1f}s "
          f"run={record.get('matches_archived_run', 'new baseline')} "
          f"arm={record.get('matches_archived_arm', 'new baseline')}", flush=True)
    return record


def summaries():
    analyses = {
        "summary.json": [(name, name) for name in ("baseline", "H", "HS", "HSF", "full")],
        "summary_ladder_seeds_0_2.json": [(("HSFW" if name == "full" else name), name if name in ("H", "HS", "HSF") else name + "_0_2")
                                        for name in ("baseline", "H", "HS", "HSF", "full")],
    }
    for name in ("full", "baseline"):
        dest = RUNS / (name + "_0_2")
        dest.mkdir(exist_ok=True)
        for seed in range(3):
            for suffix in (".json", ".json.diag.json", ".json.arm.json"):
                fname = f"seed_{seed:02}{suffix}"
                (dest / fname).symlink_to(RUNS / name / fname)
    for output, arms in analyses.items():
        args = [sys.executable, str(ROOT / "source/analyse_raised.py"), "29200",
                *[f"{name}={RUNS / path}" for name, path in arms]]
        (ROOT / output).write_bytes(subprocess.check_output(args, cwd=ROOT))


def main():
    frozen = ROOT / "REPLAY_PREDICTIONS.md"
    assert sha256(frozen.read_bytes()).hexdigest() == (ROOT / "REPLAY_PREDICTIONS.sha256").read_text().split()[0]
    copy_sources()
    jobs = [("off", "-", 0, 8000)]
    jobs += [(label, switch, seed, 29200) for seed in range(11)
             for label, switch in (("full", "HSFW"), ("baseline", "-"))]
    jobs += [(arm, arm, seed, 29200) for arm in ("H", "HS", "HSF") for seed in range(3)]
    rows = []
    with (ROOT / "RUN_RECEIPTS.jsonl").open("w") as log, ProcessPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(simulate, job) for job in jobs]
        for future in as_completed(futures):
            row = future.result()
            rows.append(row)
            print(json.dumps(row, sort_keys=True), file=log, flush=True)
    summaries()
    import numpy
    (ROOT / "REPLAY_ENVIRONMENT.json").write_text(json.dumps({
        "python": sys.version, "numpy": numpy.__version__,
        "toy_zip": sha256(TOY.read_bytes()).hexdigest(),
        "dependency_zip": sha256(OCTOBER.read_bytes()).hexdigest(),
        "prediction_sha256": sha256(frozen.read_bytes()).hexdigest(),
        "run_count": len(rows),
    }, indent=2) + "\n")
    print("All jobs and both summary reconstructions finished.", flush=True)


if __name__ == "__main__":
    main()
