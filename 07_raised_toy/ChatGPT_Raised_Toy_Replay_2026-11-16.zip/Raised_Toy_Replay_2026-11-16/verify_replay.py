"""Compare replay receipts and both reconstructed summaries to the packaged evidence."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
SOURCE_ZIP = ROOT.parent / "upload/raised_toy_2026-11-15.zip"
PREFIX = "raised_toy_2026-11-15/"


def changes(expected, actual, path=()):
    if isinstance(expected, dict) and isinstance(actual, dict):
        for key in sorted(expected.keys() | actual.keys()):
            if key not in expected or key not in actual:
                yield {"path": (*path, key), "archived": expected.get(key), "replay": actual.get(key)}
            else:
                yield from changes(expected[key], actual[key], (*path, key))
    elif expected != actual:
        yield {"path": path, "archived": expected, "replay": actual}


def digest(data):
    return sha256(data).hexdigest()


def main():
    rows = [json.loads(line) for line in (ROOT / "RUN_RECEIPTS.jsonl").read_text().splitlines()]
    rows.sort(key=lambda row: (row["label"], row["seed"]))
    by_run = {}
    for row in rows:
        key = (row["label"], row["seed"])
        assert key not in by_run
        by_run[key] = row
        path = ROOT / "runs" / row["label"] / f"seed_{row['seed']:02}.json"
        for suffix, name in (("", "checksum"), (".arm.json", "arm_checksum"),
                             (".diag.json", "diagnostic_checksum")):
            assert digest(Path(str(path) + suffix).read_bytes()) == row[name]
    expected_counts = {"off": 1, "full": 11, "baseline": 11, "H": 3, "HS": 3, "HSF": 3}
    expected_keys = {(label, seed) for label, count in expected_counts.items() for seed in range(count)}
    assert by_run.keys() == expected_keys
    packed = [row for row in rows if row["label"] != "baseline"]
    receipts = {
        "all_trials": len(rows),
        "packed_run_matches": sum(row["matches_archived_run"] for row in packed),
        "packed_arm_matches": sum(row["matches_archived_arm"] for row in packed),
        "expected_packed": len(packed),
        "summaries": {},
    }
    with ZipFile(SOURCE_ZIP) as original:
        for name in ("summary.json", "summary_ladder_seeds_0_2.json"):
            reference = original.read(PREFIX + name)
            local = (ROOT / name).read_bytes()
            differences = list(changes(json.loads(reference), json.loads(local)))
            receipts["summaries"][name] = {
                "byte_equal": reference == local,
                "archived": digest(reference), "replay": digest(local),
                "differences": differences,
            }
    (ROOT / "VERIFICATION.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print(json.dumps({
        **{key: value for key, value in receipts.items() if key != "summaries"},
        "summaries": {name: {"byte_equal": result["byte_equal"],
                             "difference_count": len(result["differences"]),
                             "first_differences": result["differences"][:5]}
                      for name, result in receipts["summaries"].items()},
    }, indent=2))


if __name__ == "__main__":
    main()
