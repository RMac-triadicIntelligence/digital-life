"""Boot the pinned Commons v2 ecology with six members and log every constructor event."""

import argparse
import importlib.util
import json
from pathlib import Path


def load_source(path):
    spec = importlib.util.spec_from_file_location("archived_commons_v2", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Path to the pinned Commons v2 sim_v2.py")
    parser.add_argument("output", type=Path, help="New directory for the observations")
    args = parser.parse_args()
    model = load_source(args.source.resolve())
    archived = json.loads(args.source.with_name("results.json").read_text())
    original_agent = model.Agent
    events = []

    class RecordedAgent(original_agent):
        __slots__ = ()

        def __init__(self, aid, fam, lineage, x, y, e, belief, born):
            super().__init__(aid, fam, lineage, x, y, e, belief, born)
            events.append({
                "id": aid, "household_at_birth": fam, "founding_lineage": lineage,
                "x": x, "y": y, "energy": float(e), "birth_tick": born,
            })

    model.Agent = RecordedAgent
    reference = model.run("V2_FULL", 0)
    if reference != archived["per_seed"]["V2_FULL"][0]:
        raise RuntimeError("The observer changed the pinned seed-0 baseline result.")

    old_counts = {"households": model.FAMS, "founders_per_household": model.FOUNDERS}
    model.FAMS, model.FOUNDERS = 2, 3
    args.output.mkdir(parents=True, exist_ok=False)
    summaries = []
    for variant in ("V2_FULL", "V2_LONE", "NO_ROLES", "V2_SELF_REPLICATING"):
        for seed in (0, 1, 2):
            events.clear()
            results, series = model.run(variant, seed, log_series=True)
            summary = {
                "variant": variant, "seed": seed,
                "initial_members": sum(row["birth_tick"] == 0 for row in events),
                "subsequent_births": sum(row["birth_tick"] > 0 for row in events),
                **results,
            }
            if summary["initial_members"] != 6:
                raise RuntimeError("The six-member fixture failed to initialize.")
            summaries.append(summary)
            trace = {"summary": summary, "construction_events": events, "per_tick": series}
            (args.output / f"{variant}_{seed}.json").write_text(json.dumps(trace, indent=2) + "\n")
    result = {
        "reference_seed_0_exact": True,
        "reference_fixture": old_counts,
        "smoke_fixture": {"founding_lineages": 2, "founders_per_lineage": 3},
        "semantics": "Exploratory smoke. The only model settings changed were the two founding counts.",
        "receipt_limit": "Constructor events include a founding lineage and omit the direct parent's identity.",
        "runs": summaries,
    }
    (args.output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
