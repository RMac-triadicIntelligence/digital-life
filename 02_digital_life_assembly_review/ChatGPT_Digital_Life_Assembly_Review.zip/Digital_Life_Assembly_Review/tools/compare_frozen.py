"""Recalculate the selected birth and resource contrasts from frozen result tables."""

import argparse
import json
from pathlib import Path
from statistics import mean


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("relational_results", type=Path)
    parser.add_argument("open_hand_results", type=Path)
    parser.add_argument("commons_results", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    rel = read(args.relational_results)
    oh = read(args.open_hand_results)
    commons = read(args.commons_results)

    def net(row):
        total = row["total"]
        return (total["correct"] - total["wrong"]) / total["episodes"]

    birth = {
        arm: [net(row) for row in rows]
        for arm, rows in rel["birth_assay"].items()
    }
    if any(len(rows) != len(rel["seeds"]) for rows in birth.values()):
        raise ValueError("Unexpected founder count in the matched birth assay.")
    pair_effects = {
        arm: [100 * (a - b) for a, b in zip(birth["FULL"], rows, strict=True)]
        for arm, rows in birth.items() if arm != "FULL"
    }

    def resource(world, arm, window, measure):
        selected = {
            row["seed"]: row["windows"][window][measure]
            for row in oh["cells"] if row["world"] == world and row["arm"] == arm
        }
        if set(selected) != set(oh["seeds"]):
            raise ValueError(f"Unexpected world seed count in {world}/{arm}.")
        return selected

    far = {
        arm: resource("half_plenty", arm, "primary", "far_unmet")
        for arm in ("EXPERIENCE", "SILENT_UNIFORM", "FROZEN_TRACE")
    }
    drought = {
        arm: resource("drought_unbounded", arm, "late", "mean_unmet")
        for arm in ("EXPERIENCE", "UNIFORM")
    }
    moved = {
        arm: resource("moving_supply", arm, "late", "mean_unmet")
        for arm in ("EXPERIENCE", "UNIFORM", "FROZEN_TRACE")
    }
    result = {
        "method": "Arithmetic on archived founder counts and world-window measures. Native verifiers checked the raw ledgers separately.",
        "relational": {
            "founder_seeds": rel["seeds"],
            "birth_net_rate_percent": {arm: 100 * mean(values) for arm, values in birth.items()},
            "full_minus_control_points": {arm: mean(values) for arm, values in pair_effects.items()},
            "full_minus_control_by_founder_points": pair_effects,
        },
        "open_hand": {
            "world_seeds": oh["seeds"],
            "primary_distant_unmet_percent": {arm: 100 * mean(values.values()) for arm, values in far.items()},
            "drought_late_unmet_percent": {arm: 100 * mean(values.values()) for arm, values in drought.items()},
            "drought_experience_minus_uniform_points": 100 * mean(
                drought["EXPERIENCE"][seed] - drought["UNIFORM"][seed] for seed in oh["seeds"]
            ),
            "moved_supply_late_unmet_percent": {arm: 100 * mean(values.values()) for arm, values in moved.items()},
        },
        "commons": {
            "verdicts": commons["verdicts"],
            "means": {arm: commons["means"][arm] for arm in ("V2_FULL", "V2_LONE", "V2_SELF_REPLICATING")},
            "paired_directions": commons["seeds_agreeing_of_20"],
        },
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
