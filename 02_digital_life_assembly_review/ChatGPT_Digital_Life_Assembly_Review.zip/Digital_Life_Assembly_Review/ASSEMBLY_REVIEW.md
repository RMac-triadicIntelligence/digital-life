# Digital life assembly review

Rusty Williams McMurray · November 11, 2026 · Central time

## The existing pieces

Commons v2 is the closest existing starting point for a small digital community. It already runs a seasonal world with food, metabolism, scouting, family records, births, deaths and budding. Relational Transitions v0.2 supplies a different piece. It gives individuals separate histories and gives descendants a bounded field whose effect can be tested. The original TQNM equations supply activation, mutual reinforcement and dwelling. The Genesis and KENTA work supplies continuity and external authorization.

I opened and hash-checked all **50 pinned public repository snapshots**, including **13 archived repositories**, and recovered **60 relevant saved inputs**. I inspected the major implementation families and reran selected native tests and evidence checks. The November scored Relational Transitions and Open Hand ledgers were checked in full with their supplied verifiers. I also ran fresh smoke cases and the supplied selected-seed trajectory replays. The four-month replay supplies the earlier equation and code history.

The evidence points toward a community assembled from existing parts. The unresolved work is at the joins. The actors, the world, the inherited records and the authorizer need to refer to the same births and events. That connection is what would allow us to test whether a population continues to develop and evolve when its starting conditions and implementation change.

## Reuse map

| Need | What is already available | What the evidence supports and what the join must carry |
| --- | --- | --- |
| **Individual dynamics** | Restored TQNM source in the November GitHub handoff, especially `corrected_dynamics/vendor/triadic_model.py` | Seven tests passed and 1,500 samples were verified in the new run. Use the original facet and dwelling equations. A world adapter must define the observations or inputs it supplies and expose their causal effect. Activation, evidence and permission have distinct records. |
| **Community, resource limits and births** | *The Terrain Remembers*, `00_commons_swarm/commons_v2/sim_v2.py`, with the v1 world in `commons_sim/sim.py` | The archive's four-household seed 0 was reproduced exactly. A six-member starting fixture also ran with the native rules. The existing constructor records the founding lineage. The chosen parent's direct identity and birth provenance need an explicit export. |
| **Local reach and allocation** | Open Hand v4 `world.py` and `model.py` | Delayed local reports, auditable transport, a reporting cost and learned shortage traces are executable. The frozen primary distant-shortage result is 0.46% with experience versus 13.31% with fee-free uniform routing. In drought the same experience increases late unmet need. Reuse as a distinct distribution experiment or adapter once the Commons reference run is pinned. |
| **Biography, rereading and inherited ground** | The Terrain Remembers v1.9 and Relational Transitions v0.2 `terrain.py`, `Member.internal_snapshot`, `members_at_birth` | Terrain v1.9 reproduced exactly on a complete copy of its directory tree. RT v0.2 can bind a fresh child's genome, parent and inherited field to a birth receipt. Its fixed sensor and reach traits control the birth assay. Field inheritance is implemented and tested. Open-ended evolution remains a separate experiment. |
| **Recognition and recovery** | Whole-system v0.4 `system.py` and `observer.py`, RNR Commons kernels v0.10–v0.13, and the Conductor-only grace branch | Whole-system v0.4 integrates learning, disclosure, offerings and the release path. The fresh run matched the supplied summary exactly, including five delivered offerings and zero observed releases. Keep that path and the negative result. Use the Conductor monitor as an advisory reader and keep recognition, permission, actual crossing and release separately observable. |
| **Identity and authority** | Humble Seed v0.7 lineage, Genesis Seed, Genesis Validator v7, and Genesis Consent Gate v0.1.5.3 | Adam's public ledger verifies 94 entries and three owner signatures. Genesis v0.1.5.3 reproduced 37 held probes and six controls. Two named boundaries were observed, joint file rollback and same-host key access. The Genesis3 checker also reconciled 216 archived native integrations on the Humble Seed v0.7 path. A portable checkpoint needs an external witness over the exact lineage, head and effect. |
| **KENTA integration** | Jean-Guillaume Nardi's KENTA/HAL work and the October Minato–Genesis bridge | All 12 receipt-bridge tests ran against the saved Genesis v7 packet. Overall KENTA gifts suite had 26 passing tests and three native ADN tests skipped. The reusable interface verifies and consumes outside receipts with public verification material. The full HAL runtime and a native migration of one continuing community still need their own evidence. |
| **Independent observations** | Digital-Life Topology v0.1, Cross-Surface Invariance v0.1, July TQNM/KENTA v3 tests, Fablebuild replay | The continuous and symbolic toy surfaces matched operation order and dependencies. July's 19 tests check attestation and planted recovery. A documented adversarial probe again showed that zero-state specimens with hand-written traces can pass eligibility. Preserve native inputs, state changes and executable ablations behind each life-sign claim. |

## An actual six-member boot

Commons v2 normally starts with four households of six. The exploratory fixture changed those two initial counts to **two founding lineages of three** and recorded every member construction and per-tick population. The observer reproduced the archived default seed-0 result exactly before starting the new fixture. The twelve exploratory runs use seeds 0–2 across four existing variants. Initial members in this fixture are founders. Parent-bound litters are a later join.

| Native variant | Final populations for seeds 0, 1, 2 | Other observations |
| --- | --- | --- |
| V2_FULL | 28, 24, 31 | Both founding lineages survived every run. There were 48, 42 and 54 subsequent births. |
| V2_LONE | 34, 40, 37 | Total harvest exceeded FULL in all three runs. Food per agent-step was lower in all three. |
| NO_ROLES | 0, 0, 0 | All three worlds lost both lineages despite recording births before extinction. |
| V2_SELF_REPLICATING | 68, 69, 72 | These runs produced 235–278 births and lower harvest per agent-step than FULL. |

These are observations from the new starting fixture, useful for deciding where to instrument the pilot. The conditions share source laws and initial population counts. They differ in household organization, roles or birth policy as specified by the archived variants. This exploratory run cannot isolate a new effect or establish an evolutionary benefit. Every run and every extinction is included. [Boot summary](evidence/commons_six/summary.json).

## Unexpected results that change the assembly

**A community can need diversity and still lose a competition on total output.** The archived twenty-seed Commons comparison reported family advantage per agent-step in 20/20 seeds and lower total harvest in 20/20. The lone condition operates with more households eligible for birth grants. In the six-member fixture the direction persisted across the three exploratory seeds. Carry per-member outcomes, total yield, births and minimum world stock as separate measures. Household grant policy can change the apparent winner.

**A no-grace crossing can be real.** The fresh Fablebuild trace found the same seed-13 crossing at step 39,846 with zero fill and a noisy position change from about 0.495 to 0.580. The rounded summary had appeared to report zero. That trajectory belongs in the native event record, with its inputs and cause. It fits the confirmed R7 rule that an organism can cross under its own dynamics. A claimed grace-enabled crossing has its separate two-key rule.

**An inherited influence can help and still lack a family-specific advantage.** The Relational Transitions birth assay held the raised parents, genomes and new task tape fixed. Full inherited ground improved net correct-minus-wrong by **2.409 percentage points** over empty inheritance. The flat control scored **42.84%**, full **42.12%**, foreign **42.32%**, and empty **39.71%**. The family and coordinate-structure hypotheses did not meet their frozen criteria. A useful next generation comparison keeps the quantity-preserving flat and foreign controls and measures lived parental inheritance separately from the community field.

**The same learned allocation can help today and reduce tomorrow's reserve.** I recalculated the Open Hand v4 means from the frozen world rows. Experience increased late unmet need in the unbounded drought by **7.607 points** over equally charged uniform routing. After supply moved, the old frozen map left late unmet need at **29.58%**, while the continuously updated and uniform arms each reached **0%**. Preserve the shifted-supply and drought environments when using the resource-routing component.

**An authorization can be delivered without causing reception.** Whole-system v0.4 again produced five offerings and zero releases. Its seed-7 learner had a much better developing predictor while retaining a poor expressed commitment. The pilot should observe when the offer arrives, whether the organism can use it, and whether a subsequent release preserves the biography. Ordinary adaptation, a numerical crossing, an authorized effect and factual improvement are different events.

**A finished verifier can still accept a counterfeit scientific trace.** The Digital-Life Topology trust probe again accepted two zero-state, hand-written specimens as eligible. The package's scientific crossing status remains false on its frozen controls. This makes the evidence origin a necessary assembly interface. A second implementation must supply native state and effect traces that can be replayed or independently inspected.

The original Open Hand unexpected-results ledger is included as received. The companion CSV adds a short source-linked index of observations that affect this assembly. Preserve original runs and units. If a new hypothesis follows from one of these results, run it under a separately frozen version and keep the originating trace.

## What to connect first

Start with Commons v2 as the environment and lifecycle host. Add a recorder that can follow **one member, one direct parent, one child and one authorized state change** across the same event IDs. Then carry those events through the Relational Transitions inheritance contract and the Genesis/KENTA receipt boundary. Give the original TQNM dynamics their own recorded facet and dwelling state and settle the local-observation adapter before using the dynamics to change actor actions.

This is small enough to inspect a whole life. It also makes three experiments possible on the same assembly. Compare live versus replayed relationships. Compare parent-bound inherited state against empty, flat and foreign controls. Then allow a bounded inherited trait to vary and measure differential descendant contribution across changing seasons. Relational Transitions holds the relevant genome traits fixed in its assay. Commons births share maps and compete for resources. The new join has to measure what is transmitted and whether that trait accounts for a frequency change over generations.

For the millennial goal, begin with continuity across restart, migration and succession. A checkpoint needs a verifiable constitution, lineage, biography and authority history. A second implementation should continue the same public events from that checkpoint under a declared comparison rule. The first target is a migration with meaningful subsequent behavior, a valid new parentage record and an independently witnessed outcome. Long calendar time cannot be established by labeling simulation ticks as years.

The concrete sequence, field boundaries, proposed controls and stop conditions are in [FIRST_COMMUNITY.md](FIRST_COMMUNITY.md).

## Evidence and coverage

- Relational Transitions v0.2. 42 fresh tests passed. Its supplied verifier checked 340,480 archived encounters and 205,716 gate records. The selected trajectory replay checked 21,280 events in 27 cells. Fresh smoke and its verifier passed. [Logs](evidence/verification/relational).
- Open Hand v4. 19 fresh tests passed. Its supplied ledger verifier checked 768 cells and the declared matched supply. Selected trajectory replay covered 64 cells. Fresh smoke and its verifier passed. [Logs](evidence/verification/open_hand).
- Original TQNM dynamics, Whole-system v0.4, Terrain v1.9, Genesis Seed ledger, Genesis v0.1.5.3, KENTA gifts, July TQNM/KENTA v3, Cross-Surface Invariance and Digital-Life Topology were checked with the listed native commands. The role of each test and any skips or bounds are recorded in [VERIFICATION.md](VERIFICATION.md).
- The older Conductor v0.3 ZIP lacked its central directory and ends inside the world ledger. I recovered 1,386 intact members, then located five missing inherited runtime files under the same SHA-256 values in the public RNR ablation snapshot. The restored monitor read a signed saved checkpoint and reported warranted dwelling. The original complete runner and its fresh 512-branch replay are unavailable in this audit. [Recovery record](evidence/conductor_recovery.json).
- The public round archive includes the v0.7 paper, the v10 and v11 grace definitions and the confirmed R7 rule. The finalized v0.8 paper was unavailable. The v11 handover distinguishes recorded rulings from open interpretations. Use those provenance distinctions when connecting grace to the new community.
- The inventory covers the complete 50-repository public shelf and the selected relevant saved inputs. Tests were targeted to the assembly. Historical HAL operation, hardware deployment, the full private conversation archive and an end-to-end evolving community on two substrates remain outside the verified results here.

[Component index](COMPONENTS.csv) · [Repository pins](REPOSITORIES.csv) · [Archive inventory](ARCHIVES.csv) · [Saved input index](SAVED_INPUTS.csv) · [Unexpected observations](OPEN_OBSERVATIONS.csv).
