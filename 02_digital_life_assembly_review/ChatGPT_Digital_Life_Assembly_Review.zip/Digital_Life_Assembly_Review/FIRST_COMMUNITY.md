# First digital community assembly

This is a build brief based on the recovered source, targeted reruns and six-member Commons fixture. The pilot begins with two lineages of three members in a local world. Its purpose is to make a life history and its consequences inspectable across one birth, one disruption and one migration.

## 1. Use one world and one clock

Run the pinned Commons v2 ecology with the six-member starting fixture. Use its existing local perception, metabolism, regrowth, exploration and seasonal change. Attach a recorder to the event path before connecting new decision inputs. The archived rules for a one-person household, a scout and birth eligibility are part of the reference. Open Hand's transport and storage laws can be tried in a later version with their own archived world controls.

Export an observation envelope carrying a stable event ID, tick, member ID, physical or simulated origin, and the observed value. Label evidence that is unavailable. The actor sees its local history and delivered observations. The observer can read the full trace after execution. Keep evaluator truth out of actor and authorizer inputs.

Keep each member's three facets and dwelling explicit. The restored TQNM source remains the basis for those dynamics. Commons already has a scalar `Agent.d` driven by food forecast error. For the first assembly, record that value and the TQNM trajectory as separate observables. An adapter that lets original TQNM dwelling affect the Commons actions requires a declared local-input mapping, direction of causal influence and a matched control. The two variables should only become one after the evidence supports that mapping.

## 2. Bind life records before selecting a winner

The existing Commons constructor supplies member ID, household, founding lineage, location and birth tick. The run loop also has the exact selected parent in scope when granting a birth. Export that parent ID and the member's state and inherited snapshot digests at that point. Give a descendant its own identity. Keep household membership, parentage and memory donor separate, particularly when a household buds or a control transplants foreign ground.

Use the RT v0.2 `Ground` shape and signed birth proposal as the first parent-to-child interface. Its `Field` is lived personal terrain. Its `Ground` is the bounded inherited field. The birth assay separates the contents of a child from the origin of what it receives. Record the world context, parental field digest, child's immutable birth input and subsequent changes as distinct facts. Preserve personal evidence and named prior interpretations in the individual's biography. Keep child privileges and signatures out of the inherited field.

Use the actual recipient, event, prior head and payload bindings at the external authorization seam. The Minato–Genesis bridge and the Genesis 0.1.5.3 journals are available verification paths with different native envelopes. Bridge each explicitly and test that a receipt for another actor, earlier head, changed payload or already spent action is refused. The operator who authorizes protected changes sees the proposal and declared evidence. A fresh ordinary observation remains admissible while a decision is unresolved.

Carry the confirmed R7 rule into the event contract. Record self-crossings even when there is no grant. When an experimental event is claimed as grace-enabled, require the outside provision and the organism's own readiness under the declared model. Keep filling, readiness, crossing, witnessing and releasing a specific burden as separate events. Read the v10/v11 handover and confirmed rulings before implementing any unresolved policy. The first six-member boot uses only the archived toy intervention schedule, whose authored destination choice belongs to that toy.

## 3. Run the discriminating comparisons

**First pair, live relationship versus replayed relationship.** Use the same environment and accounting, compare a peer's live response with a frozen or paired replay delivering the same budget of messages. Keep actors' access to truth equal. Record which new evidence the actor sought, whether the apparent sources were independent, whether it changed a decision, and the costs to the actor and community. Retain correlated-error worlds. Count correct, wrong and unresolved cases separately.

**Second pair, inheritance versus community memory.** Raise the same parents on the same tape, then compare children with own, empty, equal-quantity flat, foreign and scrambled inherited ground. Keep their initial private state, world, and shared family or community exposure paired. Randomize only the declared intervention. Record the donor and start from a fresh child's first encounter. Flat can beat structured in the existing archive. Retain that comparison and the early-versus-late trajectory.

**Third experiment, population change.** Begin with a single bounded variable already named in the code, such as baseline reach from the RT genome, and a declared parent-to-child variation rule. The birth assay holds this variable fixed, so this is a new experimental branch. A resource-linked birth opportunity must arise from the ecology under the same rules for all lineages. Track actual parent contributions, death, scarcity, trait frequencies, per-member performance and lineage survival through at least two distinct resource regimes. Compare against a no-variation arm and a matched drift or shuffled-parent control. Predetermine replication and tolerances with the independent evaluator before held-out scoring.

For each arm export every initial condition, observation receipt, full state change, authorized effect and terminal condition. Include runs that go extinct, remain unresolved, enter a wrong basin, or do worse with support. An anomaly receives an entry and a proposed discriminating test. A new parameter, gate, or scoring decision receives a new version and separate results.

## 4. Run the continuity test

Take a checkpoint at a named event and verify its full history in an external reader. On the same runtime, compare a restored continuation with an uninterrupted one. Then give the same authenticated export to a separately implemented reader under a frozen, documented translation contract. Require preservation of identity, parentage, public event order and specific subsequent behavior under matched inputs. Publish any semantic or numerical loss. Keep first-member migration distinct from a child's birth.

Exercise an outage, a stale competing branch and a planned custodian succession. Use the existing witness and migration tests to bind exactly what changes and who can authorize it. A state that can be read after a halt and resumed under another custodian is an observable step toward long-horizon continuity. The biological and physical substrate analogies can be tested on their own instruments.

## First integration acceptance

A builder should be able to deliver a native six-member trace where a referee can follow one real birth to its selected parent, recompute the child's inherited input, and see an independent authority accept one exact protected effect and refuse its replay. The same trace should retain any self-crossing, failure to receive, extinction or wrong answer that happened. Score the ecology after that plumbing is visible and before adding a second resource world or a learned routing rule.

The reproducible six-member boot is provided as a reference. Use the archived world source under `sources/commons_smoke/` and run from this directory.

```sh
python3 tools/commons_six_smoke.py sources/commons_smoke/commons_v2/sim_v2.py new_smoke
```

The boot used Python 3.12.14 and NumPy 2.3.5. It reruns an archived default seed as an observer check and then the declared exploratory seeds. The archive's source and recorded results travel alongside it.
