"""Mechanical checks only. Deliberately prints no evolutionary outcome."""
import sys, json, gzip, statistics as st
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import rest_gene as G
B = Path(sys.argv[1]).resolve()
shipped = json.loads((B/"evidence/live/runs.json").read_bytes())
for size in ([2,3],[4,6]):
    r = G.world(B, "FIXED_0", size, 0)
    nat = next(x for x in shipped if x["size"]==size and x["arm"]=="NATIVE" and x["seed"]==0)
    print(size, "FIXED_0 reproduces shipped NATIVE world receipt exactly:", r["world"]==nat["world"], "| pauses:", r["pauses"])
r = G.world(B, "EVOLVE", [4,6], 999)
d = [b["gene"]-b["parent_gene"] for b in r["births"]]
print("EVOLVE seed 999: births", len(d), "child-parent diff mean %.1f sd %.1f (target 0 / %d)" % (st.mean(d), st.pstdev(d), G.SIGMA_BP),
      "| genes in range:", all(0<=b["gene"]<=G.GENE_MAX for b in r["births"]), "| max generation:", max(b["generation"] for b in r["births"]))
n = [G.mutation_noise(1, i, i+7) for i in range(200000)]
print("noise over 200k draws: mean %.2f sd %.1f min %d max %d" % (st.mean(n), st.pstdev(n), min(n), max(n)))
print("reflect:", G.reflect(-30), G.reflect(10040), G.reflect(5000))
print("verify refuses chosen gene:", not G.verify_birth_gene("EVOLVE", 1, 5000, 3, 9, 9999, G.CONSTITUTION, G.CONSTITUTION),
      "| refuses changed constitution:", not G.verify_birth_gene("EVOLVE", 1, 5000, 3, 9, G.child_gene("EVOLVE",1,5000,3,9), G.CONSTITUTION, "edited"),
      "| accepts honest birth:", G.verify_birth_gene("EVOLVE", 1, 5000, 3, 9, G.child_gene("EVOLVE",1,5000,3,9), G.CONSTITUTION, G.CONSTITUTION))
a = G.world(B, "EVOLVE", [2,3], 999); b = G.world(B, "EVOLVE", [2,3], 999)
print("deterministic rerun identical:", a == b)
r = G.world(B, "NEUTRAL", [2,3], 999); print("NEUTRAL arm runs; NO_HEREDITY, NO_MUTATION, INVADE arms run:", all(G.world(B, x, [2,3], 999)["world"]["pop_peak"]>0 for x in ("NO_HEREDITY","NO_MUTATION","INVADE_LOW","INVADE_HIGH","FIXED_10000")))
# generation depth available in the shipped 600-tick worlds
dep=[]
for s in range(20):
    e=json.loads(gzip.decompress((B/f"evidence/live/4x6_EMPTY_{s:02}.json.gz").read_bytes())); g={}
    for x in e["births"]: g[x["id"]]=g.get(x["parent"],0)+1
    dep.append(max(g.values()))
print("shipped 4x6 EMPTY: deepest generation per run, median %s, range %s-%s" % (st.median(dep), min(dep), max(dep)))
for ticks in (3000, 6000):
    r = G.world(B, "EVOLVE", [4,6], 999, ticks=ticks)
    gens = [b["generation"] for b in r["births"]]
    alive_founders = r["census"][-1][1]
    print(f"long run {ticks} ticks, seed 999: births {len(gens)}, deepest generation {max(gens)}, median generation of births {st.median(gens)}, final pop {r['world']['pop_final']}")
