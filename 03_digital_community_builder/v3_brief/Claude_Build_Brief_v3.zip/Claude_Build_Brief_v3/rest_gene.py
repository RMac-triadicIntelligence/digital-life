"""Rest-gene world hooks for Commons v2 (DRAFT for the builder; not a frozen protocol).

Usage:  python3 rest_gene.py <path-to-Builder-v2-dir> <arm> <lineages> <founders> <seed>
Reuses load_world() from the v2 bundle's live.py unchanged. Integer-only gene maths so a
second runtime can recompute every birth exactly. No draw here touches the world RNG.
"""
import hashlib, json, sys
from collections import Counter
from pathlib import Path

SIGMA_BP = 400            # mutation sd in basis points (Palette v0.2 used sigma ~ 0.04)
GENE_MAX = 10_000         # rest propensity in basis points, 0..10000
ARMS = ("EVOLVE", "NEUTRAL", "NO_HEREDITY", "NO_MUTATION", "FIXED_0", "FIXED_5000",
        "FIXED_10000", "INVADE_LOW", "INVADE_HIGH")
CONSTITUTION = "RT02-fixed-genesis-v1"   # never mutates; a birth with another tag is refused


def _h(*parts):
    return hashlib.sha256(json.dumps(parts, sort_keys=True, separators=(",", ":")).encode()).digest()


def founder_gene(arm, seed, agent_id, lineage):
    if arm.startswith("FIXED_"):
        return int(arm.split("_")[1])
    if arm == "INVADE_LOW":
        return 0 if lineage == 0 else 7500
    if arm == "INVADE_HIGH":
        return 7500 if lineage == 0 else 0
    return int.from_bytes(_h(seed, "founder-rest", agent_id)[:8], "big") % (GENE_MAX + 1)


def mutation_noise(seed, parent_id, child_id):
    """Integer, roughly normal, mean 0, sd SIGMA_BP: sum of four hash bytes, centred."""
    s = sum(_h(seed, "rest-mutation", parent_id, child_id)[:4]) - 510   # sd of s is 147.8
    mag = (abs(s) * SIGMA_BP + 74) // 148
    return mag if s >= 0 else -mag


def reflect(v):
    """Reflect at the bounds so mutation has no pull toward the middle or the edges."""
    while v < 0 or v > GENE_MAX:
        v = -v if v < 0 else 2 * GENE_MAX - v
    return v


def child_gene(arm, seed, parent_gene, parent_id, child_id):
    if arm in ("EVOLVE", "NEUTRAL"):
        return reflect(parent_gene + mutation_noise(seed, parent_id, child_id))
    if arm == "NO_HEREDITY":   # variation without inheritance
        return int.from_bytes(_h(seed, "fresh-rest", child_id)[:8], "big") % (GENE_MAX + 1)
    return parent_gene         # NO_MUTATION, FIXED_*, INVADE_*


def verify_birth_gene(arm, seed, parent_gene, parent_id, child_id, claimed, parent_constitution, child_constitution):
    """Authority-side check: the organism never chooses its own mutation or its constitution."""
    return (child_constitution == parent_constitution == CONSTITUTION and
            type(claimed) is int and claimed == child_gene(arm, seed, parent_gene, parent_id, child_id))


def expressed(arm, gene):
    return 5000 if arm == "NEUTRAL" else gene      # NEUTRAL: gene inherited but never acted on


def pause_draw(seed, t, agent_id, q_bp):
    return int.from_bytes(_h(seed, "rest-draw", t, agent_id)[:4], "big") * GENE_MAX < q_bp * 2**32


def world(bundle, arm, size, seed, shock_tick=300, regrowth_multiplier=0.7, ticks=None):
    sys.path.insert(0, str(bundle / "vendor/rt")); sys.path.insert(0, str(bundle))
    import live
    genes, generation, paused = {}, {}, {}
    births, deaths, census_rows, pauses = [], [], [], 0

    def gene_of(agent):
        if agent.id not in genes:                       # founders only reach this branch
            genes[agent.id] = founder_gene(arm, seed, agent.id, agent.lineage); generation[agent.id] = 0
        return genes[agent.id]

    def observe(t, agent, family, obs, tolerance):
        gene_of(agent)

    def born(parent, child, live_agents):
        pg = gene_of(parent)
        g = child_gene(arm, seed, pg, parent.id, child.id)
        assert verify_birth_gene(arm, seed, pg, parent.id, child.id, g, CONSTITUTION, CONSTITUTION)
        genes[child.id] = g; generation[child.id] = generation[parent.id] + 1
        births.append(dict(tick=child.born, id=child.id, parent=parent.id, lineage=child.lineage,
                           gene=g, parent_gene=pg, generation=generation[child.id],
                           mean_gene_living=sum(genes[a.id] for a in live_agents) // max(1, len(live_agents))))

    def move(t, agent, native_move, out, family, rng):
        nonlocal pauses
        x, y = agent.x, agent.y
        active_target = agent.target is not None and agent.target != (x, y)
        native_move(agent, out, family, rng)            # always consumes its ordinary draws
        ordinary = not active_target and agent.target is None and (x, y) != (agent.x, agent.y)
        if not ordinary or paused.get(agent.id) == t - 1:
            return
        if pause_draw(seed, t, agent.id, expressed(arm, gene_of(agent))):
            agent.x, agent.y = x, y; paused[agent.id] = t; pauses += 1

    def census(t, live_agents):
        by = Counter(); tot = Counter()
        for a in live_agents:
            by[a.lineage] += 1; tot[a.lineage] += gene_of(a)
        n = len(live_agents); s = sum(tot.values())
        var = sum((genes[a.id] - s / n) ** 2 for a in live_agents) / n if n else 0.0
        census_rows.append([t, n, s // n if n else None, round(var), *[[by[i], tot[i] // by[i] if by[i] else None] for i in range(size[0])]])

    def died(t, agent):
        deaths.append([t, agent.id, agent.lineage, genes.get(agent.id), generation.get(agent.id)])
        paused.pop(agent.id, None)

    def regrow(t, native):
        return native * regrowth_multiplier if t >= shock_tick else native

    scope = live.load_world(observe, born, move, census, died, regrow)
    scope.update(FAMS=size[0], FOUNDERS=size[1])
    if ticks is not None:
        scope.update(STEPS=ticks)                      # long-run arm; native default is 600
    result, series = scope["run"]("V2_FULL", seed, log_series=True)
    return dict(arm=arm, size=size, seed=seed, world=result, births=births, deaths=deaths,
                census=census_rows, pauses=pauses, sigma_bp=SIGMA_BP, constitution=CONSTITUTION)


if __name__ == "__main__":
    b, arm, fams, founders, seed = sys.argv[1:6]
    r = world(Path(b).resolve(), arm, [int(fams), int(founders)], int(seed))
    print(json.dumps({k: r[k] for k in ("arm", "size", "seed", "world", "pauses")}))
