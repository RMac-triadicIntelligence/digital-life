# Digital Community Builder v2

This round asks whether inherited terrain from a child's own parent improves reproduction when the child acts in a living Commons community. It also exercises a separate local receiver fixture against the false-parent, stale-checkpoint and altered-tape cases from the first review round.

## Run the package

Use Python 3.12, NumPy 2.3.5, cryptography 50.0.0, and Node 24.

```sh
sha256sum -c SHA256SUMS
python3 verify_live.py evidence/live
python3 receiver_demo.py new_receiver
OPENBLAS_NUM_THREADS=1 python3 live.py new_live --workers 4
python3 verify_live.py evidence/live --repeat new_live
```

`protocol.json` was frozen before scoring. `protocol.sha256` records the freeze. `live.py` adapts the vendored Commons source in memory. The original Commons files and the original Relational Transitions modules are included. The verifier checks the census against birth and death records for every tick and checks all 12 unshocked native reference outcomes. A fresh 240-run execution reproduced both receipts and every decompressed trace byte for byte.

## What happened in the live communities

The 240 scored runs cover 20 seeds, two founder sizes and six arms. Resource regrowth slows at tick 300. A descendant can pause an ordinary move for one tick when its readout crosses the fixed threshold. Native dwelling and movement toward witness or grace targets take precedence. The live arms use the same field-write rule for founders and descendants. The pressure channel now tracks a still-pending observation from an earlier tick.

| Post-shock births per founding lineage | Two lineages, three founders each | Four lineages, six founders each |
|---|---:|---:|
| Native Commons | 12.150 | 2.8375 |
| Own-parent terrain | 12.750 | 6.5750 |
| Alternate same-quadrant donor | 13.175 | 6.8750 |
| Flat terrain with matched channel mass | 12.925 | 7.7375 |
| Empty inherited terrain | 12.625 | 6.6375 |
| First-build birth-local projection with the v2 live reader | 12.425 | 7.7250 |

The primary paired contrast, OWN minus MATCHED, was −0.425 and −0.300 births per founding lineage. The exact two-sided sign test returned p = 0.815 and p = 1.000. Neither size met the frozen threshold for benefit or harm. Donor coverage was 907 of 950 births in the smaller communities and 1,334 of 1,335 in the larger communities. Of those matches, 713 and 1,325 respectively crossed lineages. With no eligible alternate donor, the control used own terrain and logged the fallback.

The larger communities had more post-shock births on average in every pause-enabled arm. The empty-terrain arm exceeded native Commons in all 20 paired seeds at that size, by 3.8 births per founding lineage on average. At the smaller size it won nine seeds, lost eight, and tied three. Treat that as a secondary pattern for this coupling, founder size and shock. The table gives arm means. It does not isolate the pause mechanism or establish a parent-specific advantage. No run ended extinct. All 240 records retain their per-tick lineage census, births, deaths, inherited ground, donor IDs and every applied pause, including the native proposed destination.

This design uses seeds from the earlier work. The positional kernel still treats quadrant IDs as ordinal. Same-quadrant donor matching addresses the birth-location confound in the primary comparison. It leaves the geometric limitation in the underlying reader. The legacy arm carries forward the first build's projection and pressure rule for its parent field, using the common v2 reader and movement rule during live play. The frozen shock changes regrowth only. One-tick pauses are separated by a tick of ordinary decision making.

## What the receiver enforces

`receiver_demo.py` rebuilds a birth, checkpoint, and continuation tape from the pinned seed-0 first-build trace. It generates two fresh local software keys and enrolls the expected birth proposal, checkpoint and tape in SQLite through an operator-side function. The packet supplies none of the trust pins to `receiver.py`. The SQLite transaction checks the enrolled record, calls the Node numerical reader, and stores a result once per subject. Node still checks the witness and birth signatures.

The fixture rejects a wrong parent, invented ground, real signed checkpoints at observations 7 and 9, a signed checkpoint edit, signed tape truncation and signed pressure edit, and an invalid signature. In a concurrent pair, one commits and the other is refused. A fresh process refuses the same subject after commit, and re-enrollment fails. The valid path matches the Python replay through 566 observations. The receiver evidence includes the attack packets, local journal, and case receipts. Private signing keys are ephemeral.

This is a local, single-handoff fixture built from the archived tape. Operator enrollment is trusted. The standalone Node reader is a numerical component. Receiver protections apply when using `receiver.py` with its trusted registry. Successive legitimate migrations, off-host custody, independent issuers, and migration of the live v2 ecology remain open.

## Files for independent review

- `evidence/live/runs.json` and `summary.json` hold all run receipts and paired results.
- `evidence/live/*.json.gz` holds the individual traces.
- `evidence/receiver/summary.json` holds the receiver results.
- `FALSIFIER.md` contains the next review targets.
