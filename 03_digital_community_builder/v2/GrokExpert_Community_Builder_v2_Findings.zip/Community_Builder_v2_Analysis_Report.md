# Analysis Report: ChatGPTDigital_Community_Builder_v2

**Analyst:** Grok  
**Date:** 2026-11-12  
**Source Package:** ChatGPTDigital_Community_Builder_v2.zip  

## Executive Summary

v2 advances the digital community builder from offline tape replay to **live inheritance experiments** inside Commons communities. Descendants can pause ordinary moves when inherited terrain readouts cross a fixed threshold. It also hardens a local receiver fixture against a broader set of signed attacks. The primary OWN-vs-MATCHED contrast on post-shock births did not meet the frozen significance threshold in either founder size. Verification of all 240 traces and reference outcomes passed.

## Live Experiment Design

- **Seeds:** 0–19  
- **Founder sizes:** [2,3] and [4,6]  
- **Arms:** NATIVE, OWN, MATCHED, FLAT, EMPTY, LEGACY  
- **World:** V2_FULL, 600 ticks, shock at tick 300 (regrowth ×0.7)  
- **Decision rule:** After native movement, cancel ordinary displacement for a newborn/descendant when check ≥ 0.5, at most once in two successive ticks. Witness/grace targets and native dwelling take precedence. A pause changes position only.  
- **Primary endpoint:** OWN minus MATCHED post-shock births per founding lineage; exact two-sided sign test. Directional claim requires both sizes to meet coverage, effect size, and p ≤ 0.05 thresholds.  
- Protocol frozen in `protocol.json` before scoring (`protocol.sha256`).

## Results (post-shock births per founding lineage)

| Arm | 2×3 founders | 4×6 founders |
|-----|-------------:|-------------:|
| Native Commons | 12.150 | 2.8375 |
| Own-parent terrain | 12.750 | 6.5750 |
| Alternate same-quadrant donor | 13.175 | 6.8750 |
| Flat (matched channel mass) | 12.925 | 7.7375 |
| Empty inherited terrain | 12.625 | 6.6375 |
| Legacy birth-local projection | 12.425 | 7.7250 |

- OWN − MATCHED: −0.425 (p = 0.815) and −0.300 (p = 1.000). Neither size met the pre-registered threshold for benefit or harm.  
- Donor coverage: 907/950 and 1,334/1,335; majority crossed lineages.  
- Larger communities produced more post-shock births in every pause-enabled arm. Empty terrain beat native in all 20 seeds at the larger size (mean +3.8 births/lineage).  
- No run ended extinct. All 240 records retain full per-tick census, births, deaths, inherited ground, donor IDs, and applied pauses.

## Receiver Fixture

`receiver_demo.py` rebuilds the pinned seed-0 first-build tape, generates fresh local keys, and enrolls trusted records. The packet supplies none of the trust pins. Node still verifies signatures. Refusals recorded for:

- wrong parent / invented ground  
- validly signed checkpoints at observations 7 and 9  
- re-signed checkpoint edit, shorter tape, pressure edit  
- bad witness signature  
- concurrent double handoff (one accepted, one refused)  
- fresh-process replay and re-enrollment after commit  

Valid path matches Python replay through 566 observations. Operator enrollment is trusted; keys are ephemeral.

## Verification

- SHA256SUMS: passed  
- `python3 verify_live.py evidence/live`: “Verified 240 traces and 12 unshocked native reference outcomes.”  

## Boundaries / Open Work

- Operator enrollment is trusted.  
- Successive legitimate migrations, off-host custody, independent issuers, and full migration of the live v2 ecology remain open.  
- The positional kernel still treats quadrant IDs as ordinal.  
- Seeds were previously used; this is a prospective live run on known seeds.  
- The design does not isolate the pause mechanism or establish a parent-specific advantage.

## Files of Interest

- `evidence/live/runs.json` — all run receipts  
- `evidence/live/*.json.gz` — individual traces  
- `evidence/receiver/summary.json` — receiver case results  
- `protocol.json` / `protocol.sha256` — frozen protocol  
- `FALSIFIER.md` — next independent review targets  

---

*Report generated from direct inspection of README.md, protocol.json, evidence/verification.txt, evidence/receiver/summary.json, and live aggregation of runs.json. All checksum and live-trace verifications passed in the analysis environment.*
