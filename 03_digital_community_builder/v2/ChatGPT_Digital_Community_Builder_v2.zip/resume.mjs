import fs from 'node:fs';
import {createHash, createPublicKey, verify} from 'node:crypto';

function canonical(x) {
  if (Array.isArray(x)) return '[' + x.map(canonical).join(',') + ']';
  if (x !== null && typeof x === 'object')
    return '{' + Object.keys(x).sort().map(k => JSON.stringify(k)+':'+canonical(x[k])).join(',') + '}';
  return JSON.stringify(x);
}
const sha = x => createHash('sha256').update(canonical(x)).digest('hex');
function valid(message, signature, rawKey) {
  const der = Buffer.from('302a300506032b6570032100' + rawKey, 'hex');
  return verify(null, Buffer.from(canonical(message)),
    createPublicKey({key:der, format:'der', type:'spki'}), Buffer.from(signature,'hex'));
}
const requireThat = (condition, error) => { if (!condition) throw Error(error); };
const [path, witnessKey, birthKey, expectedHead] = process.argv.slice(2);
const {checkpoint, permit, signature, observations} = JSON.parse(fs.readFileSync(path === '-' ? 0 : path, 'utf8'));
requireThat(valid(permit, signature, witnessKey), 'witness signature');
requireThat(permit.kind === 'resume' && permit.target === 'node:terrain-v1' &&
  permit.head === expectedHead && permit.head === sha(checkpoint) &&
  permit.subject === checkpoint.birth.proposal.subject && permit.tape === sha(observations),
  'resume binding');
const p = checkpoint.birth.proposal;
requireThat(p.kind === 'birth' && p.issuer === 'external-research-authority' &&
  p.parent === checkpoint.parent && p.lineage === checkpoint.lineage &&
  checkpoint.schema === 'terrain-v1' && checkpoint.field.frozen === false &&
  p.genome.reach_basis_points === 9000 && canonical(p.ground.axes) === '[2,3]' &&
  p.ground.values.length === 32 && p.ground.values.every(v => Number.isInteger(v) && v >= 0) &&
  p.ground.values.reduce((sum,v)=>sum+v,0) <= 1024 &&
  valid(p, checkpoint.birth.signature, birthKey), 'birth binding');
const cells = new Map(checkpoint.field.cells.map(([i,a,b]) => [i,[a,b]]));
let previous = checkpoint.field.previous;
const decode = i => [i>>6,(i>>4)&3,(i>>2)&3,i&3];
const encode = (q) => 64*q[0]+16*q[1]+4*q[2]+q[3];
function write(i, pressure) {
  const [a,b] = cells.get(i) ?? [0,0];
  const [pa,pb] = cells.get(previous) ?? [0,0];
  const a1 = Math.min(255, a + Math.max(1, Math.floor((255-a)*(4+Math.floor(pa/32))/255)));
  const b1 = pressure ? Math.min(255,b+Math.max(1,Math.floor((255-b)*(20+Math.floor(pb/8))/255))) : b;
  cells.set(i,[a1,b1]);
  previous = i;
}
const metrics = [];
let last = checkpoint.last;
for (const event of observations) {
  requireThat(event.subject === p.subject && Number.isInteger(event.id) && event.id > last &&
    typeof event.pressure === 'boolean' && event.point.length === 4 &&
    event.point.every(v=>Number.isInteger(v) && v>=0 && v<4), 'observation continuity');
  last = event.id;
  const q = event.point;
  const i = encode(q);
  write(i,event.pressure);
  let a=0,b=0,c=0,d=0;
  for (const [j,[u,v]] of cells) {
    const w = 1/(1+decode(j).reduce((sum,z,k)=>sum+(k>=2?3:1)*(q[k]-z)**2,0));
    a+=w*u; b+=w*v;
  }
  for (let j=0;j<16;j++) {
    const w=1/(1+3*((j>>2)-q[2])**2+3*((j&3)-q[3])**2);
    c+=w*p.ground.values[j]; d+=w*p.ground.values[16+j];
  }
  const ratio=(b+d)/(a+b+c+d+16);
  write(i,false);
  metrics.push([event.id, Math.min(.99,Math.max(.2,.9+.12*ratio)),
    Math.min(.9,Math.max(.05,.10+.75*ratio)),ratio]);
}
const field = {cells:[...cells].sort((a,b)=>a[0]-b[0]).map(([i,v])=>[i,...v]), previous, frozen:false};
process.stdout.write(JSON.stringify({subject:p.subject,last,field,metrics}));
