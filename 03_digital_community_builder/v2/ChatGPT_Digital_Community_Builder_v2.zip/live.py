"""Run the frozen Commons/RT live inheritance comparison."""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor/rt"))
from model import Member, transform_ground
from terrain import Field, Ground, bounded, canon, crossing_slice, decode, sha

SOURCE = ROOT / "vendor/commons/commons_v2/sim_v2.py"
EMPTY = Field().snapshot()


def quadrant(agent):
    return 2 * (agent.x >= 16) + (agent.y >= 16)


def project(field):
    bins = [0] * 32
    for cell, (encounter, pressure) in field.cells.items():
        _, _, kinetics, position = decode(cell)
        index = 4 * kinetics + position
        bins[index] += encounter
        bins[16 + index] += pressure
    return Ground(tuple(bounded(bins, 96)))


def match_channels(donor, own):
    values = []
    for start in (0, 16):
        channel = donor.values[start:start + 16]
        mass = sum(own.values[start:start + 16])
        total = sum(channel)
        if not total:
            q, r = divmod(mass, 16)
            values.extend(q + (i < r) for i in range(16))
            continue
        scaled = [v * mass // total for v in channel]
        order = sorted(range(16), key=lambda i: (-(channel[i] * mass % total), i))
        for i in order[:mass - sum(scaled)]:
            scaled[i] += 1
        values.extend(scaled)
    return Ground(tuple(values))


def frozen_protocol():
    raw = (ROOT / "protocol.json").read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != (ROOT / "protocol.sha256").read_text().split()[0]:
        raise ValueError("protocol digest mismatch")
    return json.loads(raw), digest


def world(task):
    protocol, digest, size, arm, seed, out_dir = task
    config = protocol["world"]
    members, legacy, checked, paused = {}, {}, {}, {}
    births, deaths, ticks, pauses = [], [], [], []
    pause_counts = Counter()
    candidates = {}
    candidate_tick = None

    def observe(t, agent, family, obs, tolerance):
        if arm == "NATIVE":
            return
        pressure = any(pid == agent.id and pt < t and px == agent.x and py == agent.y
                       for px, py, _, pid, pt in family.pending)
        error = abs(float(obs) - float(agent.belief[agent.x, agent.y]))
        point = [1, min(3, max(0, int(float(obs) * 4))),
                 min(3, int(error / tolerance)), quadrant(agent)]
        member = members.get(agent.id)
        if member is None:
            member = members[agent.id] = Member(str(agent.id), agent.lineage, (), Ground(), .8, .9)
        member.terrain.write(point, pressure, "experience")
        checked[agent.id] = member.read_for_direction(point, "FULL")[1]
        if arm == "LEGACY":
            legacy.setdefault(agent.id, Field()).write(point, error > tolerance, "experience")

    def born(parent, child, live):
        nonlocal candidates, candidate_tick
        donor = None
        ground = Ground()
        if arm != "NATIVE":
            own = project(members[parent.id].terrain)
            ground = own
            if arm == "LEGACY":
                point = [1, 0, 0, quadrant(child)]
                ground = Ground(tuple(crossing_slice(EMPTY, legacy[parent.id].snapshot(), point)))
            elif arm == "FLAT":
                ground = transform_ground(own, "FLAT_J", seed, 0, ())
            elif arm == "EMPTY":
                ground = Ground()
            elif arm == "MATCHED":
                if candidate_tick != child.born:
                    candidates = {}
                    for agent in live:
                        candidates.setdefault(quadrant(agent), []).append(agent)
                    candidate_tick = child.born
                available = [a for a in candidates.get(quadrant(child), ()) if a.id != parent.id]
                foreign = [a for a in available if a.lineage != parent.lineage]
                if available:
                    donor = min(foreign or available, key=lambda a: sha([seed, child.id, a.id]))
                    ground = match_channels(project(members[donor.id].terrain), own)
            members[child.id] = Member(str(child.id), child.lineage, (), ground, .8, .9)
        births.append(dict(tick=child.born, id=child.id, parent=parent.id, lineage=child.lineage,
                           quadrant=quadrant(child), donor=donor.id if donor else None,
                           donor_lineage=donor.lineage if donor else None,
                           ground=list(ground.values)))

    def move(t, agent, native_move, out, family, rng):
        x, y = agent.x, agent.y
        active_target = agent.target is not None and agent.target != (x, y)
        native_move(agent, out, family, rng)
        ordinary = not active_target and agent.target is None and (x, y) != (agent.x, agent.y)
        if arm == "NATIVE" or agent.born == 0 or not ordinary:
            return
        phase = "post" if t >= config["shock_tick"] else "pre"
        pause_counts[(agent.lineage, phase, "eligible")] += 1
        check = checked[agent.id]
        if check >= protocol["decision"]["threshold"] and paused.get(agent.id) != t - 1:
            pauses.append([t, agent.id, agent.lineage, x, y, agent.x, agent.y, check])
            agent.x, agent.y = x, y
            paused[agent.id] = t
            pause_counts[(agent.lineage, phase, "paused")] += 1

    def census(t, live):
        lineages = Counter(a.lineage for a in live)
        ticks.append([t, *[lineages[i] for i in range(size[0])]])

    def died(t, agent):
        deaths.append([t, agent.id, agent.lineage])
        members.pop(agent.id, None)
        legacy.pop(agent.id, None)
        checked.pop(agent.id, None)
        paused.pop(agent.id, None)

    def regrow(t, native):
        return native * config["regrowth_multiplier"] if t >= config["shock_tick"] else native

    scope = load_world(observe, born, move, census, died, regrow)
    if scope["STEPS"] != config["ticks"]:
        raise ValueError("native tick count differs from protocol")
    scope.update(FAMS=size[0], FOUNDERS=size[1])
    result, native_ticks = scope["run"](config["variant"], seed, log_series=True)
    per_lineage = Counter(b["lineage"] for b in births if b["tick"] >= config["shock_tick"])
    receipt = dict(seed=seed, size=size, arm=arm, world=result, births=len(births),
                   post_births=[per_lineage[i] for i in range(size[0])],
                   matched=sum(b["donor"] is not None for b in births),
                   cross_lineage=sum(b["donor"] is not None and b["donor_lineage"] != b["lineage"] for b in births),
                   effective_pauses=len(pauses))
    evidence = dict(receipt=receipt, protocol_sha256=digest, births=births, deaths=deaths,
                    population_by_lineage=ticks, world_ticks=native_ticks, pauses=pauses,
                    decision_counts=[[*key, count] for key, count in sorted(pause_counts.items())])
    file = Path(out_dir) / f"{size[0]}x{size[1]}_{arm}_{seed:02}.json.gz"
    file.write_bytes(gzip.compress(canon(evidence), mtime=0))
    return receipt


def load_world(observe, born, move, census, died, regrow):
    original = SOURCE.read_text()
    start = "        for a in live:\n            out[\"ast\"] += 1;"
    end = "        # grace toward the frontier:"
    before, rest = original.split(start)
    body, after = rest.split(end)
    move_body = '            out["ast"] += 1;'.join(("", body))
    move_body = move_body.replace(' fam = fams[a.fam]', '').replace('; continue', '; return')
    original = before + (
        "        def native_move(a, out, fam, arng):\n" + move_body +
        "        for a in live:\n            move(t, a, native_move, out, fams[a.fam], arng)\n"
    ) + end + after
    patches = [
        ("            if abs(obs - a.belief", "            observe(t, a, fam, obs, D_TOL)\n            if abs(obs - a.belief"),
        ("                            live.append(agents[-1])", "                            born(p, agents[-1], live)\n                            live.append(agents[-1])"),
        ("                a.alive = False", "                a.alive = False\n                died(t, a)"),
        ("        Keff = np.maximum", "        census(t, live)\n        Keff = np.maximum"),
        ("R + REGROW * R", "R + regrow(t, REGROW) * R"),
    ]
    for old, new in patches:
        if original.count(old) != 1:
            raise ValueError(f"native source layout changed at {old!r}")
        original = original.replace(old, new)
    scope = dict(__file__=str(SOURCE), observe=observe, born=born, move=move,
                 census=census, died=died, regrow=regrow)
    exec(compile(original, str(SOURCE), "exec"), scope)
    return scope


def paired(own, other, lineages):
    deltas = [sum(a["post_births"]) - sum(b["post_births"]) for a, b in zip(own, other, strict=True)]
    wins, losses = sum(d > 0 for d in deltas), sum(d < 0 for d in deltas)
    n = wins + losses
    p = min(1.0, 2 * sum(math.comb(n, k) for k in range(min(wins, losses) + 1)) / 2**n)
    return dict(mean_delta_per_lineage=statistics.mean(deltas) / lineages, wins=wins, losses=losses,
                ties=len(deltas)-n, sign_test_p=p, paired_birth_deltas=deltas)


def summarize(protocol, receipts):
    results = {}
    for size in protocol["founders"]:
        arms = {arm: [r for r in receipts if r["size"] == size and r["arm"] == arm]
                for arm in protocol["arms"]}
        results[f"{size[0]}x{size[1]}"] = dict(
            arms={arm: dict(
                mean_post_births_per_lineage=statistics.mean(sum(r["post_births"]) for r in rows) / size[0],
                extinct=sum(r["world"]["pop_final"] == 0 for r in rows),
                mean_final_population=statistics.mean(r["world"]["pop_final"] for r in rows),
                mean_lineages_alive=statistics.mean(r["world"]["families_alive"] for r in rows),
                mean_harvest_late=statistics.mean(r["world"]["harvest_late"] for r in rows),
                mean_per_capita_harvest=statistics.mean(r["world"]["per_capita"] for r in rows),
                births=sum(r["births"] for r in rows), matched=sum(r["matched"] for r in rows),
                cross_lineage=sum(r["cross_lineage"] for r in rows),
                pauses=sum(r["effective_pauses"] for r in rows))
                for arm, rows in arms.items()},
            paired_own={arm: paired(arms["OWN"], rows, size[0]) for arm, rows in arms.items() if arm != "OWN"})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    protocol, digest = frozen_protocol()
    args.out.mkdir(parents=True, exist_ok=False)
    tasks = [(protocol, digest, size, arm, seed, args.out) for size in protocol["founders"]
             for arm in protocol["arms"] for seed in protocol["seeds"]]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        receipts = list(pool.map(world, tasks))
    (args.out / "runs.json").write_bytes(canon(receipts) + b"\n")
    result = summarize(protocol, receipts)
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{len(receipts)} scored runs, protocol {digest}")


if __name__ == "__main__":
    main()
