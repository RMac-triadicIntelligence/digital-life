"""One authorized cross-runtime handoff per subject in a local trusted registry."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess

ROOT = Path(__file__).resolve().parent


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate packet key")
        result[key] = value
    return result


def register(db_path, checkpoint, observations, witness_key, birth_key):
    """Operator-side enrollment. Call with independently reconstructed source state."""
    proposal = checkpoint["birth"]["proposal"]
    with sqlite3.connect(db_path) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS handoffs(
            subject TEXT PRIMARY KEY, birth TEXT NOT NULL, head TEXT NOT NULL,
            tape TEXT NOT NULL, witness_key TEXT NOT NULL, birth_key TEXT NOT NULL,
            result BLOB)""")
        db.execute("INSERT INTO handoffs VALUES (?, ?, ?, ?, ?, ?, NULL)",
                   (proposal["subject"], digest(proposal), digest(checkpoint),
                    digest(observations), witness_key, birth_key))


def receive(db_path, raw):
    packet = json.loads(raw, object_pairs_hook=unique_pairs)
    checkpoint = packet["checkpoint"]
    permit = packet["permit"]
    proposal = checkpoint["birth"]["proposal"]
    observations = packet["observations"]
    subject = permit["subject"]
    with sqlite3.connect(db_path, timeout=30) as db:
        db.execute("BEGIN IMMEDIATE")
        entry = db.execute("SELECT birth, head, tape, witness_key, birth_key, result "
                           "FROM handoffs WHERE subject = ?", (subject,)).fetchone()
        if entry is None:
            raise ValueError("unknown subject")
        birth, head, tape, witness_key, birth_key, committed = entry
        if committed is not None:
            raise ValueError("handoff already committed for subject")
        if proposal["subject"] != subject or digest(proposal) != birth:
            raise ValueError("birth conflicts with trusted source record")
        if permit["head"] != head or digest(checkpoint) != head:
            raise ValueError("checkpoint conflicts with trusted source record")
        if permit["tape"] != tape or digest(observations) != tape:
            raise ValueError("observations conflict with trusted source record")
        node = subprocess.run(
            ["node", str(ROOT / "resume.mjs"), "-", witness_key, birth_key, head],
            input=canonical(packet), capture_output=True, check=True, timeout=20,
        )
        result = json.loads(node.stdout)
        expected_last = observations[-1]["id"] if observations else checkpoint["last"]
        if result["subject"] != subject or result["last"] != expected_last:
            raise ValueError("reader returned inconsistent identity or observation")
        db.execute("UPDATE handoffs SET result = ? WHERE subject = ?", (canonical(result), subject))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("registry", type=Path)
    parser.add_argument("packet", type=Path)
    args = parser.parse_args()
    print(canonical(receive(args.registry, args.packet.read_bytes())).decode())


if __name__ == "__main__":
    main()
