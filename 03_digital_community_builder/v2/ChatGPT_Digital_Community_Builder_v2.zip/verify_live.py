"""Audit every scored trace and compare an optional fresh replay."""
import argparse
from collections import Counter
import gzip
import json
from pathlib import Path

from live import ROOT, frozen_protocol, load_world, paired, summarize


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify(out, repeat):
    protocol, digest = frozen_protocol()
    receipts = json.loads((out / "runs.json").read_bytes())
    scheduled = [(size, arm, seed) for size in protocol["founders"] for arm in protocol["arms"]
                 for seed in protocol["seeds"]]
    require([(r["size"], r["arm"], r["seed"]) for r in receipts] == scheduled, "schedule mismatch")
    for size, arm, seed in scheduled:
        name = f"{size[0]}x{size[1]}_{arm}_{seed:02}.json.gz"
        raw = gzip.decompress((out / name).read_bytes())
        if repeat:
            require(raw == gzip.decompress((repeat / name).read_bytes()), f"replay differs: {name}")
        e = json.loads(raw)
        r = e["receipt"]
        require(e["protocol_sha256"] == digest, f"protocol mismatch: {name}")
        require(r == receipts[scheduled.index((size, arm, seed))], f"receipt mismatch: {name}")
        live = {i: i // size[1] for i in range(size[0] * size[1])}
        post = Counter()
        births, deaths = iter(e["births"]), iter(e["deaths"])
        birth, death = next(births, None), next(deaths, None)
        for t, row in enumerate(e["population_by_lineage"]):
            while death is not None and death[0] == t:
                require(live.pop(death[1]) == death[2], f"death lineage mismatch: {name}")
                death = next(deaths, None)
            while birth is not None and birth["tick"] == t:
                lin = birth["lineage"]
                require(live[birth["parent"]] == lin and birth["id"] not in live,
                        f"birth lineage mismatch: {name}")
                live[birth["id"]] = lin
                if t >= protocol["world"]["shock_tick"]:
                    post[lin] += 1
                birth = next(births, None)
            counts = Counter(live.values())
            require(row == [t, *[counts[i] for i in range(size[0])]], f"census mismatch: {name}")
            require(e["world_ticks"][t]["pop"] == len(live), f"population mismatch: {name}")
        require(len(e["population_by_lineage"]) == protocol["world"]["ticks"] and
                birth is None and death is None and r["world"]["pop_final"] == len(live),
                f"terminal mismatch: {name}")
        require(r["post_births"] == [post[i] for i in range(size[0])], f"birth totals mismatch: {name}")
        prior = {}
        for t, aid, _, x, y, nx, ny, check in e["pauses"]:
            require((x, y) != (nx, ny) and check >= protocol["decision"]["threshold"] and
                    prior.get(aid) != t - 1 and prior.get(aid) != t, f"pause mismatch: {name}")
            prior[aid] = t
        require(r["effective_pauses"] == len(e["pauses"]), f"pause totals mismatch: {name}")
        require(r["matched"] == sum(b["donor"] is not None for b in e["births"]),
                f"donor total mismatch: {name}")

    result = summarize(protocol, receipts)
    require(result == json.loads((out / "summary.json").read_bytes()), "summary mismatch")
    if repeat:
        for name in ("runs.json", "summary.json"):
            require((out / name).read_bytes() == (repeat / name).read_bytes(), f"replay differs: {name}")

    native = load_world(lambda *a: None, lambda *a: None,
                        lambda t, a, fn, out, fam, rng: fn(a, out, fam, rng),
                        lambda *a: None, lambda *a: None, lambda t, rate: rate)
    native.update(FAMS=2, FOUNDERS=3)
    reference = json.loads((ROOT / "fixtures/reference.json").read_bytes())["runs"]
    for row in reference:
        actual = native["run"](row["variant"], row["seed"])
        require(all(row[k] == v for k, v in actual.items()), "native instrumentation regression")

    print(f"Verified {len(receipts)} traces and {len(reference)} unshocked native reference outcomes.")
    if repeat:
        print("Fresh run agrees byte for byte on both receipts and all decompressed traces.")
    for size in protocol["founders"]:
        own = [r for r in receipts if r["size"] == size and r["arm"] == "OWN"]
        native_rows = [r for r in receipts if r["size"] == size and r["arm"] == "NATIVE"]
        empty = [r for r in receipts if r["size"] == size and r["arm"] == "EMPTY"]
        matched = result[f"{size[0]}x{size[1]}"]["arms"]["MATCHED"]
        print(f"{size}: matched donor coverage {matched['matched']}/{matched['births']}, "
              f"own mean births {sum(sum(r['post_births']) for r in own)/len(own)/size[0]:.4f}, "
              f"empty vs native {paired(empty, native_rows, size[0])}")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("out", type=Path)
    p.add_argument("--repeat", type=Path)
    args = p.parse_args()
    verify(args.out, args.repeat)
