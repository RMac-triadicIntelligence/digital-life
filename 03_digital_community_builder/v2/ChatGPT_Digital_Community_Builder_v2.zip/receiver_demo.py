"""Rebuild trusted source records, then exercise the actual receiver entry point."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import gzip
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import subprocess
import sys

from receiver import ROOT, canonical, digest, receive, register
sys.path.insert(0, str(ROOT / "vendor/rt"))
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from model import Member
from terrain import Field, Ground, crossing_slice
SOURCE_DIGEST = "a89a90c67c63b9abb48896de8c0c181407666fd30a765dbfb2bdf49170e5c027"


def key_hex(key):
    return key.public_key().public_bytes_raw().hex()


def source_trace():
    path = ROOT / "fixtures/commons_seed0.json.gz"
    raw = gzip.decompress(path.read_bytes())
    if hashlib.sha256(raw).hexdigest() != SOURCE_DIGEST:
        raise ValueError("source trace integrity failure")
    return json.loads(raw)


def events(rows, subject, through_tick=None):
    aid = int(subject.rsplit("/", 1)[-1])
    return [dict(subject=subject, id=r["id"], point=r["point"], pressure=r["pressure"])
            for r in rows if r["member"] == aid and (through_tick is None or r["tick"] <= through_tick)]


def replay(actor, tape):
    readings = []
    for event in tape:
        actor.terrain.write(event["point"], event["pressure"], "experience")
        readings.append([event["id"], *actor.read_for_direction(event["point"], "FULL")])
    return readings


def signed_birth(proposal, key):
    return dict(proposal=proposal, signature=key.sign(canonical(proposal)).hex())


def checkpoint_at(receipt, tape, n):
    p = receipt["proposal"]
    actor = Member(p["subject"], p["lineage"], (), Ground(tuple(p["ground"]["values"])), .8, .9)
    prefix = tape[:n]
    replay(actor, prefix)
    checkpoint = dict(schema="terrain-v1", birth=receipt, parent=p["parent"], lineage=p["lineage"],
                      last=prefix[-1]["id"], field=actor.terrain.snapshot(), prefix=digest(prefix))
    metrics = replay(actor, tape[n:])
    return checkpoint, metrics, actor.terrain.snapshot()


def packet_for(checkpoint, tape, witness):
    permit = dict(kind="resume", subject=checkpoint["birth"]["proposal"]["subject"],
                  target="node:terrain-v1", head=digest(checkpoint), tape=digest(tape))
    return dict(checkpoint=checkpoint, permit=permit, signature=witness.sign(canonical(permit)).hex(),
                observations=tape)


def verify(out):
    out.mkdir(parents=True, exist_ok=False)
    raw = source_trace()
    birth = raw["births"][0]
    field = Field()
    for event in events(raw["observations"], birth["parent"], birth["tick"]):
        field.write(event["point"], event["pressure"], "experience")
    parent_field = field.snapshot()
    ground = Ground(tuple(crossing_slice(Field().snapshot(), parent_field, birth["point"])))
    if parent_field != birth["parent_field"] or ground.payload() != birth["ground"]:
        raise ValueError("source birth cannot be rebuilt")
    proposal = {k: birth[k] for k in ("subject", "parent", "lineage", "tick")}
    proposal.update(ground=ground.payload(), issuer="external-research-authority", kind="birth",
                    parent_field=digest(parent_field), genome={"reach_basis_points": 9000})
    birth_key, witness = Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()
    receipt = signed_birth(proposal, birth_key)
    tape = events(raw["observations"], birth["subject"])
    checkpoint, metrics, field = checkpoint_at(receipt, tape, 8)
    tail = tape[8:]
    journal = out / "receiver.sqlite"
    keys = key_hex(witness), key_hex(birth_key)
    register(journal, checkpoint, tail, *keys)
    packet = packet_for(checkpoint, tail, witness)
    cases = []
    attacks = out / "rejected_packets"
    attacks.mkdir()

    def refuse(label, altered, expected):
        (attacks / (label.replace(" ", "_") + ".json")).write_bytes(canonical(altered) + b"\n")
        try:
            receive(journal, canonical(altered))
        except ValueError as error:
            if str(error) != expected:
                raise
            cases.append(dict(case=label, refusal=str(error)))
            return
        raise AssertionError(f"{label} accepted")

    for label in ("wrong parent", "invented ground"):
        altered = deepcopy(checkpoint)
        p = deepcopy(proposal)
        if label == "wrong parent":
            p["parent"] = altered["parent"] = "commons/0/5"
        else:
            p["ground"] = Ground(tuple([0] * 31 + [96])).payload()
        altered["birth"] = signed_birth(p, birth_key)
        refuse(label, packet_for(altered, tail, witness), "birth conflicts with trusted source record")

    for n in (7, 9):
        alternate, _, _ = checkpoint_at(receipt, tape, n)
        refuse(f"validly signed checkpoint at {n}", packet_for(alternate, tape[n:], witness),
               "checkpoint conflicts with trusted source record")
    changed = deepcopy(checkpoint)
    changed["field"]["cells"][0][1] ^= 1
    refuse("re-signed checkpoint edit", packet_for(changed, tail, witness),
           "checkpoint conflicts with trusted source record")
    changed_tape = deepcopy(tail)
    changed_tape[0]["pressure"] ^= True
    for label, revised in (("re-signed shorter tape", tail[:-1]), ("re-signed pressure edit", changed_tape)):
        refuse(label, packet_for(checkpoint, revised, witness), "observations conflict with trusted source record")

    invalid = deepcopy(packet)
    invalid["signature"] = "00" * 64
    (attacks / "bad_witness_signature.json").write_bytes(canonical(invalid) + b"\n")
    try:
        receive(journal, canonical(invalid))
    except subprocess.CalledProcessError as error:
        if b"witness signature" not in error.stderr:
            raise
        cases.append(dict(case="bad witness signature", refusal="witness signature"))
    else:
        raise AssertionError("invalid witness signature accepted")

    def race():
        try:
            return receive(journal, canonical(packet))
        except ValueError as error:
            return str(error)

    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(lambda _: race(), range(2)))
    accepted = [x for x in outcomes if isinstance(x, dict)]
    if len(accepted) != 1 or "handoff already committed for subject" not in outcomes:
        raise AssertionError("concurrent handoff did not commit exactly once")
    result = accepted[0]
    if result["field"] != field or not all(a[0] == b[0] and
            all(math.isclose(x, y, abs_tol=1e-12) for x, y in zip(a[1:], b[1:], strict=True))
            for a, b in zip(result["metrics"], metrics, strict=True)):
        raise AssertionError("continuation differs from source replay")
    cases.append(dict(case="two concurrent handoffs", refusal="one accepted, one refused"))
    (out / "packet.json").write_bytes(canonical(packet) + b"\n")
    command = [sys.executable, str(ROOT / "receiver.py"), str(journal), str(out / "packet.json")]
    retry = subprocess.run(command, capture_output=True, check=False)
    if retry.returncode == 0 or b"handoff already committed for subject" not in retry.stderr:
        raise AssertionError("fresh process accepted replay")
    cases.append(dict(case="fresh process replay", refusal="handoff already committed for subject"))
    try:
        register(journal, checkpoint, tail, *keys)
    except sqlite3.IntegrityError:
        cases.append(dict(case="re-enroll same subject", refusal="subject already registered"))
    else:
        raise AssertionError("duplicate enrollment accepted")
    summary = dict(subject=birth["subject"], observations=len(tail), final_field_matches=True, cases=cases)
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    verify(parser.parse_args().out)
