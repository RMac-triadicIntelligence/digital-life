"""Exploratory follow-ups (NOT part of the frozen protocol). Original traces untouched."""
import sys, json, copy, math, statistics as st, gzip
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
B = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(B/"vendor/rt")); sys.path.insert(0, str(B))
src = (B/"live.py").read_text()
patches = [
 ('            elif arm == "EMPTY":', '            elif arm in ("EMPTY", "RANDPAUSE"):'),
 ('        check = checked[agent.id]\n',
  '        check = checked[agent.id]\n        if arm == "RANDPAUSE":\n            check = 1.0 if int(sha([seed, t, agent.id, "rp"])[:8], 16) / 2**32 < protocol["rand_q"] else 0.0\n'),
]
for a, b in patches:
    assert src.count(a) == 1, a
    src = src.replace(a, b)
scope = {"__file__": str(B/"live.py"), "__name__": "live_patched"}
exec(compile(src, str(B/"live.py"), "exec"), scope)
world, paired = scope["world"], scope["paired"]
def job(t): return world(t)
if __name__ == "__main__":
    base = json.loads((B/"protocol.json").read_bytes()); base["rand_q"] = 0.75
    noshock = copy.deepcopy(base); noshock["world"]["regrowth_multiplier"] = 1.0
    tasks = []
    def add(tag, proto, sizes, arms, seeds):
        d = OUT/tag; d.mkdir(exist_ok=True)
        for size in sizes:
            for arm in arms:
                for seed in seeds: tasks.append((tag, (proto, "exploratory", size, arm, seed, d)))
    add("A_randpause_seeds0-19", base, [[2,3],[4,6]], ["RANDPAUSE"], range(20))
    add("B_newseeds20-39", base, [[4,6]], ["NATIVE","EMPTY","RANDPAUSE","OWN","MATCHED"], range(20,40))
    add("C_noshock_seeds0-19", noshock, [[4,6]], ["NATIVE","EMPTY"], range(20))
    with ProcessPoolExecutor(max_workers=2) as pool:
        receipts = list(pool.map(job, [t[1] for t in tasks]))
    rows = [dict(tag=t[0], **r) for t, r in zip(tasks, receipts)]
    (OUT/"extra_runs.json").write_text(json.dumps(rows))
    shipped = json.loads((B/"evidence/live/runs.json").read_bytes())
    def sel(src, size, arm, tag=None): return sorted([r for r in src if r["size"]==size and r["arm"]==arm and (tag is None or r["tag"]==tag)], key=lambda r:r["seed"])
    def show(label, a, b, n):
        p = paired(a, b, n); fa = st.mean(r["world"]["pop_final"] for r in a); fb = st.mean(r["world"]["pop_final"] for r in b)
        print(f"{label}: post-births/lineage {st.mean(sum(r['post_births']) for r in a)/n:.3f} vs {st.mean(sum(r['post_births']) for r in b)/n:.3f}  delta={p['mean_delta_per_lineage']:+.3f} W/L/T={p['wins']}/{p['losses']}/{p['ties']} p={p['sign_test_p']:.2g} | final pop {fa:.1f} vs {fb:.1f} | pauses/run {st.mean(r['effective_pauses'] for r in a):.0f} vs {st.mean(r['effective_pauses'] for r in b):.0f}")
    print("== A. terrain-blind random pause (q=0.75, empty ground), original seeds ==")
    for size in ([2,3],[4,6]):
        rp = sel(rows, size, "RANDPAUSE", "A_randpause_seeds0-19")
        show(f"{size} RANDPAUSE vs NATIVE", rp, sel(shipped, size, "NATIVE"), size[0])
        show(f"{size} RANDPAUSE vs EMPTY ", rp, sel(shipped, size, "EMPTY"), size[0])
        show(f"{size} RANDPAUSE vs OWN   ", rp, sel(shipped, size, "OWN"), size[0])
    print("== B. new seeds 20-39, 4x6 ==")
    g = lambda arm: sel(rows, [4,6], arm, "B_newseeds20-39")
    show("EMPTY vs NATIVE    ", g("EMPTY"), g("NATIVE"), 4)
    show("RANDPAUSE vs NATIVE", g("RANDPAUSE"), g("NATIVE"), 4)
    show("RANDPAUSE vs EMPTY ", g("RANDPAUSE"), g("EMPTY"), 4)
    show("OWN vs MATCHED     ", g("OWN"), g("MATCHED"), 4)
    show("OWN vs EMPTY       ", g("OWN"), g("EMPTY"), 4)
    print("== C. no resource shock (regrowth x1.0), 4x6, seeds 0-19 ==")
    h = lambda arm: sel(rows, [4,6], arm, "C_noshock_seeds0-19")
    show("EMPTY vs NATIVE    ", h("EMPTY"), h("NATIVE"), 4)
    # final-pop paired on shipped
    print("== shipped: paired final population EMPTY - NATIVE ==")
    for size in ([2,3],[4,6]):
        d=[a["world"]["pop_final"]-b["world"]["pop_final"] for a,b in zip(sel(shipped,size,"EMPTY"),sel(shipped,size,"NATIVE"))]
        print(size, "mean", st.mean(d), "W/L/T", sum(x>0 for x in d), sum(x<0 for x in d), sum(x==0 for x in d))
