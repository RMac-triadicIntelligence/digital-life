import gzip, json, sys, statistics as st
from pathlib import Path
from collections import Counter, defaultdict
E = Path(sys.argv[1])
def load(size, arm, seed): return json.loads(gzip.decompress((E/f"{size}_{arm}_{seed:02}.json.gz").read_bytes()))
for size in ("2x3","4x6"):
    print("=====", size)
    for arm in ("NATIVE","OWN","MATCHED","FLAT","EMPTY","LEGACY"):
        el=pa=0; pre=post=0; deaths=0; smin=[]; chk=[]; popshock=[]; masses=Counter(); pchan=[]; preP=postP=preE=postE=0
        for s in range(20):
            e=load(size,arm,s)
            for lin,ph,kind,c in e["decision_counts"]:
                if kind=="eligible":
                    el+=c; preE+=c*(ph=="pre"); postE+=c*(ph=="post")
                else:
                    pa+=c; preP+=c*(ph=="pre"); postP+=c*(ph=="post")
            pre+=sum(b["tick"]<300 for b in e["births"]); post+=sum(b["tick"]>=300 for b in e["births"])
            deaths+=len(e["deaths"]); smin.append(e["receipt"]["world"]["stock_min"])
            popshock.append(e["world_ticks"][299]["pop"])
            chk+= [p[7] for p in e["pauses"]]
            for b in e["births"]:
                masses[sum(b["ground"])]+=1; pchan.append(sum(b["ground"][16:]))
        r=pa/el if el else 0
        print(f"{arm:8s} eligible={el:6d} paused={pa:6d} rate={r:.3f} (pre {preP/max(preE,1):.3f} post {postP/max(postE,1):.3f}) births pre/post={pre/20:.1f}/{post/20:.1f} deaths/run={deaths/20:.1f} pop@299={st.mean(popshock):.1f} stock_min={st.mean(smin):.3f}"
              + (f" check@pause med={st.median(chk):.3f} min={min(chk):.3f}" if chk else "")
              + f" ground mass={dict(masses)} mean pressure-channel={st.mean(pchan) if pchan else 0:.1f}")
# how distinct are OWN grounds between parents in the same tick+quadrant vs different quadrant
print("===== OWN ground distinctness (L1 distance out of 192)")
for size in ("2x3","4x6"):
    same=[];diff=[];sameLin=[];crossLin=[]
    for s in range(20):
        e=load(size,"OWN",s); by=defaultdict(list)
        for b in e["births"]: by[b["tick"]].append(b)
        for bs in by.values():
            for i in range(len(bs)):
                for j in range(i+1,len(bs)):
                    if bs[i]["parent"]==bs[j]["parent"]: continue
                    d=sum(abs(x-y) for x,y in zip(bs[i]["ground"],bs[j]["ground"]))
                    (same if bs[i]["quadrant"]==bs[j]["quadrant"] else diff).append(d)
                    (sameLin if bs[i]["lineage"]==bs[j]["lineage"] else crossLin).append(d)
    f=lambda v:(f"n={len(v)} mean={st.mean(v):.1f} med={st.median(v)}" if v else "n=0")
    print(size,"same-quadrant:",f(same),"| diff-quadrant:",f(diff),"| same-lineage:",f(sameLin),"| cross-lineage:",f(crossLin))
# post-shock stock gate: births by 25-tick window NATIVE vs EMPTY at 4x6
print("===== births per birth-tick window, 4x6, mean over seeds")
for arm in ("NATIVE","EMPTY"):
    c=Counter(); pop=Counter()
    for s in range(20):
        e=load("4x6",arm,s)
        for b in e["births"]: c[b["tick"]//100]+=1
        for t in (0,100,200,299,400,500,599): pop[t]+=e["world_ticks"][t]["pop"]
    print(arm,"births/100 ticks:",[round(c[k]/20,1) for k in range(6)],"pop at 0,100,200,299,400,500,599:",[round(pop[t]/20,1) for t in (0,100,200,299,400,500,599)])
