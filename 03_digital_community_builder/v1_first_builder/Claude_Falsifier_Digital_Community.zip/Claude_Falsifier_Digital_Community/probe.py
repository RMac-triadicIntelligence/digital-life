import sys, json, gzip, copy, random, statistics as st, subprocess, tempfile, sqlite3
from pathlib import Path
from fractions import Fraction as F
B = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(B/"vendor/rt")); sys.path.insert(0, str(B))
import run as R
from terrain import Field, Ground, canon, sha, crossing_slice, decode, encode
from model import Member
from authority import ResearchAuthority
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
nat = json.loads(gzip.open(B/"evidence/V2_FULL.json.gz").read())
rows, births = nat["observations"], nat["births"]
b0 = births[0]; subj = b0["subject"]; tape = R.events_for(rows, subj)
g_own = Ground(tuple(b0["ground"]["values"]))
child = lambda g: Member(subj, b0["lineage"], (), g, .8, .9)
base = R.apply(child(g_own), tape)
print("births", len(births), "tape", len(tape), "own ground", b0["ground"]["values"])
print("== A. controls on same tape (vs own-parent inheritance) ==")
def cmp(name, g):
    m = R.apply(child(g), tape)
    dr = [abs(a[1]-b[1]) for a,b in zip(base,m)]; dc = [abs(a[2]-b[2]) for a,b in zip(base,m)]
    nd = sum(a!=b for a,b in zip(base,m))
    print(f"{name:28s} rows_diff={nd:3d}/{len(m)} reach: mean={st.mean(dr):.5f} max={max(dr):.5f} last100={st.mean(dr[-100:]):.6f} | check: mean={st.mean(dc):.5f} max={max(dc):.5f} last100={st.mean(dc[-100:]):.6f}")
    return m
cmp("empty", Ground())
cmp("flat 96 (3/cell)", Ground((3,)*32))
rng = random.Random(1); v = list(g_own.values); rng.shuffle(v); cmp("shuffled own", Ground(tuple(v)))
seen=set()
for b in births[1:]:
    key=(b["lineage"],tuple(b["ground"]["values"]))
    if b["lineage"]!=b0["lineage"] and len(seen)<3 and key not in seen:
        seen.add(key); cmp(f"foreign L{b['lineage']} {b['parent'][-2:]}@t{b['tick']}", Ground(tuple(b["ground"]["values"])))
sib=[b for b in births[1:] if b["lineage"]==b0["lineage"]][:2]
for b in sib: cmp(f"kin {b['parent'][-2:]}@t{b['tick']}", Ground(tuple(b["ground"]["values"])))
print("ground mass over all births:", sorted(set(sum(b["ground"]["values"]) for b in births)))
rr=[x[1] for x in base]; cc=[x[2] for x in base]
print(f"own reach range {min(rr):.4f}-{max(rr):.4f}; check range {min(cc):.4f}-{max(cc):.4f}; reach clamped at .99: {sum(r>=.99 for r in rr)}")

print("== E. exact-rational third reader ==")
cells={}; prev=None; gv=g_own.values; worst=0
def w(i,p):
    global prev
    a,b=cells.get(i,[0,0]); pa,pb=cells.get(prev,[0,0])
    a=min(255,a+max(1,(255-a)*(4+pa//32)//255))
    if p: b=min(255,b+max(1,(255-b)*(20+pb//8)//255))
    cells[i]=[a,b]; prev=i
for ev,row in zip(tape,base):
    q=ev["point"]; i=64*q[0]+16*q[1]+4*q[2]+q[3]; w(i,ev["pressure"])
    a=b=c=d=F(0)
    for j,(u,v) in cells.items():
        z=(j//64,(j//16)%4,(j//4)%4,j%4); wt=F(1,1+sum((3 if k>=2 else 1)*(q[k]-z[k])**2 for k in range(4))); a+=wt*u; b+=wt*v
    for j in range(16):
        wt=F(1,1+3*(j//4-q[2])**2+3*(j%4-q[3])**2); c+=wt*gv[j]; d+=wt*gv[16+j]
    ratio=(b+d)/(a+b+c+d+16); worst=max(worst,abs(float(ratio)-row[3]),abs(min(.99,max(.2,.9+.12*float(ratio)))-row[1]),abs(min(.9,max(.05,.1+.75*float(ratio)))-row[2]))
    w(i,False)
m=child(g_own); R.apply(m,tape)
print("max abs dev vs python floats:", worst, "| final integer field equal:", [[i,*v] for i,v in sorted(cells.items())]==m.terrain.snapshot()["cells"])

print("== C/D. receiver probes ==")
auth=ResearchAuthority(); wit=Ed25519PrivateKey.generate(); wk=wit.public_key().public_bytes_raw().hex()
tmp=Path(tempfile.mkdtemp()); journal=tmp/"j.sqlite"
def packet(n, parent=b0["parent"], ground=g_own, pfield=None):
    prop={k:b0[k] for k in ("subject","lineage","tick")}
    prop.update(parent=parent, ground=ground.payload(), issuer="external-research-authority", kind="birth",
                parent_field=pfield or sha(b0["parent_field"]), genome={"reach_basis_points":9000})
    rec=auth.approve(prop); a=child(ground); R.apply(a,tape[:n])
    cp=dict(schema="terrain-v1",birth=rec,parent=parent,lineage=b0["lineage"],last=tape[n-1]["id"],field=a.terrain.snapshot(),prefix=sha(tape[:n]))
    head=sha(cp); permit=dict(kind="resume",subject=subj,target="node:terrain-v1",head=head,tape=sha(tape[n:]))
    return dict(checkpoint=cp,permit=permit,signature=wit.sign(canon(permit)).hex(),observations=tape[n:]),head
def attempt(label,pk,head):
    p=tmp/(str(abs(hash(label)))+".json"); R.save(p,pk)
    try: r=R.receive(p,journal,wk,auth.public,head); print(f"{label}: ACCEPTED+committed, resumed {len(r['metrics'])} obs")
    except Exception as e: print(f"{label}: rejected ({type(e).__name__})")
p8,h8=packet(8); p7,h7=packet(7)
attempt("head@8 (current)",p8,h8)
attempt("head@7 w/ pin=head@8 (true stale head)",p7,h8)
attempt("head@7 w/ pin=head@7 (same child, 2nd resume)",p7,h7)
print("journal rows for one child:", sqlite3.connect(journal).execute("select count(*) from resumed").fetchone()[0])
fb=next(b for b in births if b["lineage"]!=b0["lineage"])
pf,hf=packet(8,parent=fb["parent"],ground=Ground(tuple(fb["ground"]["values"])),pfield="00"*32)
attempt(f"different valid parent {fb['parent']} + its foreign ground + bogus parent_field",pf,hf)
print("== F. how lineage-specific is the inherited ground? ==")
from collections import Counter
u=Counter((tuple(b["ground"]["values"])) for b in births)
print("births",len(births),"distinct grounds",len(u))
for g,n in u.most_common(6):
    ls=Counter(b["lineage"] for b in births if tuple(b["ground"]["values"])==g)
    print(n,"births; lineages",dict(ls),"nonzero",{i:v for i,v in enumerate(g) if v})
print("== B. seed sweep at 2x3 founders ==")
src=(B/"vendor/commons/commons_v2/sim_v2.py"); sys.path.insert(0,str(src.parent))
sc={"__file__":str(src)}; exec(compile(src.read_text(),str(src),"exec"),sc); sc.update(FAMS=2,FOUNDERS=3)
for var in ("V2_FULL","NO_ROLES"):
    res=[sc["run"](var,s) for s in range(20)]
    res=[r[0] if isinstance(r,tuple) else r for r in res]
    pf=[r["pop_final"] for r in res]
    print(var,"pop_final by seed",pf,"extinct",sum(p==0 for p in pf),"/20")
