# Independent Run Results
Date: 2026-11-12
Command: python3 run.py /tmp/independent_run
Environment: Python 3.10.21, Node 20.20.2, NumPy 2.2.6, cryptography 50.0.1

## Outcome
All critical assertions passed. Summary.json is byte-identical to the archived evidence.
Final integer terrain field is identical. All 566 metrics match within tolerance.
Fresh witness key was generated (as designed). Birth authority public key and expected head match.

## Key matches
- parent / child / lineage / birth_tick: identical
- inherited_density: 96
- resumed_observations: 566
- changed_readouts_vs_empty_ground: 566
- full_final / no_roles_final: 28 / 0
- final_field_identical: true
- All six rejection cases confirmed

Witness key differs (expected). All other fixture trust fields match.
