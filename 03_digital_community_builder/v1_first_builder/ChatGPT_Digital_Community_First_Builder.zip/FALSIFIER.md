# Independent falsifier handoff

1. Verify the bundle with `sha256sum -c SHA256SUMS`, then run `python3 run.py independent_run` from the extracted directory. Compare `summary.json` and `resumed.json` with the originals. The software witness key is newly generated per run.
2. Rebuild the first birth from `evidence/V2_FULL.json.gz` using the original Commons observations and the mapping in `capture.py` and `run.py`. Check that the parent's state stops at the birth boundary. Try a different valid parent and a correctly signed permit for a different checkpoint. Verify what the runner and the receiving Node process each reject.
3. Write a second reader from the original Relational Transitions equations. Compare the final integer terrain and every reach/check/ratio row. Python uses relative tolerance 1e-9 and absolute tolerance 1e-12.
4. Compare inherited terrain with empty, flat, and foreign fields on the same tape. Then let the readouts affect live decisions under a changed resource regime. Specify the decision rule and outcome measure before running. Record survival, extinction, and lineage histories for all seeds tested.
