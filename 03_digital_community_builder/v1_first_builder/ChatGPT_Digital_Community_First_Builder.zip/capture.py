"""Attach observation hooks to the archived ecology in memory."""
from pathlib import Path
import sys
from terrain import Field, Ground, crossing_slice

ROOT = Path(__file__).parent
SOURCE = ROOT / "vendor/commons/commons_v2/sim_v2.py"

def capture(variant):
    observations, births, fields = [], [], {}

    def observe(t, agent, obs, tolerance):
        error = abs(float(obs) - float(agent.belief[agent.x, agent.y]))
        point = [1, min(3, max(0, int(float(obs) * 4))),
                 min(3, int(error / tolerance)), 2 * (agent.x >= 16) + (agent.y >= 16)]
        event = dict(tick=t, id=len(observations), member=agent.id, point=point,
                     pressure=error > tolerance, x=agent.x, y=agent.y,
                     observation=float(obs), prior_belief=float(agent.belief[agent.x, agent.y]))
        observations.append(event)
        fields.setdefault(agent.id, Field()).write(point, event["pressure"], "experience")

    def born(parent, child):
        terrain = fields[parent.id].snapshot()
        point = [1, 0, 0, 2 * (child.x >= 16) + (child.y >= 16)]
        ground = Ground(tuple(crossing_slice(Field().snapshot(), terrain, point)))
        births.append(dict(parent=f"commons/0/{parent.id}", subject=f"commons/0/{child.id}",
                           lineage=child.lineage, tick=child.born, point=point,
                           parent_field=terrain, ground=ground.payload()))

    original = SOURCE.read_text()
    patches = [
        ("            if abs(obs - a.belief", "            observe(t, a, obs, D_TOL)\n            if abs(obs - a.belief"),
        ("                            live.append(agents[-1])", "                            born(p, agents[-1])\n                            live.append(agents[-1])"),
    ]
    for old, new in patches:
        if original.count(old) != 1:
            raise RuntimeError("Unexpected Commons source layout")
        original = original.replace(old, new)
    scope = {"__file__": str(SOURCE), "observe": observe, "born": born}
    sys.path.insert(0, str(SOURCE.parent))
    exec(compile(original, str(SOURCE), "exec"), scope)
    scope.update(FAMS=2, FOUNDERS=3)
    result, ticks = scope["run"](variant, 0, log_series=True)
    return dict(result=result, ticks=ticks, births=births, observations=observations)
