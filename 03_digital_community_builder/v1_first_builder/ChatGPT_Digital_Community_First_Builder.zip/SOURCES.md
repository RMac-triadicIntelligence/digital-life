# Source archives

- `Digital_Life_Assembly_Review.zip` supplies the archived Commons source and seed-0 reference runs. SHA-256 `a1de23703512f0d0dd59331abdc17bb78b913930d96915f16696370341c2861d`.
- `Relational_Transitions_v0_2_2026-11-10.zip` supplies the three original Python modules under `vendor/rt`. SHA-256 `06366bfdd40ea24e87d84c4e0efa71bcfda1f0626e8c755629757b47c2e7646a`.
