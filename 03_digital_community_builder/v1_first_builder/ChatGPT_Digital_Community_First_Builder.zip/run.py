"""First builder rehearsal. The witness and receiving journal are local fixtures."""
import argparse
import copy
import gzip
import json
import math
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor/rt"))
from authority import ResearchAuthority, Verifier, Gate
from model import Member
from terrain import Field, Ground, canon, sha, crossing_slice
from capture import capture
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def save(path, obj):
    path.write_bytes(canon(obj) + b"\n")


def events_for(rows, subject):
    member = int(subject.rsplit("/", 1)[-1])
    return [dict(subject=subject, id=row["id"], point=row["point"], pressure=row["pressure"])
            for row in rows if row["member"] == member]


def apply(member, events):
    out = []
    for event in events:
        member.terrain.write(event["point"], event["pressure"], "experience")
        out.append([event["id"], *member.read_for_direction(event["point"], "FULL")])
    return out


def receive(path, journal, witness_key, birth_key, head):
    result = subprocess.run(
        ["node", str(ROOT / "resume.mjs"), str(path), witness_key, birth_key, head],
        check=True, capture_output=True, text=True,
    )
    resumed = json.loads(result.stdout)
    packet = json.loads(path.read_bytes())
    with sqlite3.connect(journal) as db:
        db.execute("CREATE TABLE IF NOT EXISTS resumed(head TEXT PRIMARY KEY, result BLOB NOT NULL)")
        try:
            db.execute("INSERT INTO resumed VALUES (?, ?)", (packet["permit"]["head"], canon(resumed)))
        except sqlite3.IntegrityError as error:
            raise ValueError("resume already committed") from error
    return resumed


def main():
    if not __debug__:
        raise RuntimeError("Run with verification assertions enabled")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    out = args.out
    out.mkdir(parents=True, exist_ok=False)
    reference = json.loads((ROOT / "reference.json").read_bytes())["runs"]
    experiments = {}
    for variant in ("V2_FULL", "NO_ROLES"):
        native = capture(variant)
        expected = next(r for r in reference if r["variant"] == variant and r["seed"] == 0)
        assert all(expected[k] == v for k, v in native["result"].items())
        with gzip.open(out / f"{variant}.json.gz", "wb") as archive:
            archive.write(canon(native))
        experiments[variant] = native

    native = experiments["V2_FULL"]
    birth = native["births"][0]
    rows = native["observations"]
    parent_field = Field()
    for event in events_for(rows, birth["parent"]):
        if rows[event["id"]]["tick"] <= birth["tick"]:
            parent_field.write(event["point"], event["pressure"], "experience")
    assert parent_field.snapshot() == birth["parent_field"]
    ground = Ground(tuple(crossing_slice(Field().snapshot(), parent_field.snapshot(), birth["point"])))
    assert ground.payload() == birth["ground"]
    authority = ResearchAuthority()
    verifier = Verifier(authority.public)
    proposal = {k: birth[k] for k in ("subject", "parent", "lineage", "tick", "ground")}
    proposal.update(issuer="external-research-authority", kind="birth",
                    parent_field=sha(birth["parent_field"]), genome={"reach_basis_points": 9000})
    receipt = authority.approve(proposal)
    subject = birth["subject"]
    assert verifier.birth_matches(receipt, subject, birth["parent"], birth["lineage"], ground, proposal["genome"])
    assert not verifier.birth_matches(receipt, subject, "wrong-parent", birth["lineage"], ground, proposal["genome"])
    gate = Gate(verifier)
    gate.register_birth(receipt)
    try:
        gate.register_birth(receipt)
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate birth accepted")

    tape = events_for(rows, subject)
    assert len(tape) > 8
    prefix, tail = tape[:8], tape[8:]
    def child(inherited):
        return Member(subject, birth["lineage"], (), inherited, .8, .9)

    actor = child(ground)
    apply(actor, prefix)
    checkpoint = dict(schema="terrain-v1", birth=receipt, parent=birth["parent"], lineage=birth["lineage"],
                      last=prefix[-1]["id"], field=actor.terrain.snapshot(), prefix=sha(prefix))
    expected_metrics = apply(actor, tail)
    expected_field = actor.terrain.snapshot()
    uninterrupted = child(ground)
    assert apply(uninterrupted, tape)[8:] == expected_metrics
    assert uninterrupted.terrain.snapshot() == expected_field

    witness = Ed25519PrivateKey.generate()
    witness_key = witness.public_key().public_bytes_raw().hex()
    head = sha(checkpoint)
    permit = dict(kind="resume", subject=subject, target="node:terrain-v1", head=head, tape=sha(tail))
    packet = dict(checkpoint=checkpoint, permit=permit, signature=witness.sign(canon(permit)).hex(),
                  observations=tail)
    save(out / "fixture_trust.json", dict(witness=witness_key, birth=authority.public, expected_head=head))
    save(out / "resume_packet.json", packet)
    journal = out / "receiver.sqlite"
    for name in ("tampered_tape", "wrong_target", "stale_head"):
        altered = copy.deepcopy(packet)
        if name == "tampered_tape":
            altered["observations"][0]["pressure"] ^= True
        else:
            altered["permit"]["target" if name == "wrong_target" else "head"] = "wrong"
            altered["signature"] = witness.sign(canon(altered["permit"])).hex()
        path = out / f"{name}.json"
        save(path, altered)
        try:
            receive(path, journal, witness_key, authority.public, head)
        except subprocess.CalledProcessError:
            pass
        else:
            raise AssertionError(f"{name} accepted")
    resumed = receive(out / "resume_packet.json", journal, witness_key, authority.public, head)
    assert resumed["subject"] == subject and resumed["last"] == tape[-1]["id"]
    assert resumed["field"] == expected_field
    for a, b in zip(resumed["metrics"], expected_metrics, strict=True):
        assert a[0] == b[0] and all(math.isclose(x, y, abs_tol=1e-12) for x, y in zip(a[1:], b[1:], strict=True))
    try:
        receive(out / "resume_packet.json", journal, witness_key, authority.public, head)
    except ValueError as error:
        assert str(error) == "resume already committed"
    else:
        raise AssertionError("duplicate resume committed")
    empty = apply(child(Ground()), tape)[8:]
    save(out / "comparison.json", dict(python=expected_metrics, node=resumed["metrics"], empty_ground=empty))
    save(out / "resumed.json", resumed)
    summary = dict(
        parent=birth["parent"], child=subject, lineage=birth["lineage"], birth_tick=birth["tick"],
        inherited_density=sum(ground.values), checkpoint_observations=len(prefix),
        resumed_observations=len(tail), final_field_identical=True,
        changed_readouts_vs_empty_ground=sum(a != b for a, b in zip(expected_metrics, empty, strict=True)),
        reference_world_outcomes_match=True, full_final=native["result"]["pop_final"],
        no_roles_final=experiments["NO_ROLES"]["result"]["pop_final"],
        rejected=["wrong parent", "duplicate birth", "tampered tape", "wrong target", "stale head", "duplicate resume"],
    )
    save(out / "summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
