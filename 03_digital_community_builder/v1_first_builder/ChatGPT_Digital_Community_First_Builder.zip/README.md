# First digital community builder handoff

Run from this directory with Python 3.12, Node 24, NumPy 2.3.5, and cryptography 50.0.0.

```sh
python3 run.py new_run
```

## What ran

Seed 0 began with two founding lineages of three in Commons v2. The observer attaches at the native food observation and actual parent selection. Both the FULL and NO_ROLES world summaries match the earlier six-member archive. FULL ended with 28 members. NO_ROLES went extinct. Both complete observation, birth and population traces are retained in `evidence/*.json.gz`.

At tick 25, parent `commons/0/0` produced child `commons/0/6`. The birth record binds the parent's identity, lineage, terrain digest and a 96-unit bounded inherited field. The Python builder recomputes the field from the parent's own recorded observations and signs the child birth through the Relational Transitions research fixture. The child starts with empty personal terrain and the signed inherited field.

After eight observations, a separate witness key signs a resume permit bound to the checkpoint digest, recipient, runtime and recorded continuation tape. Node verifies the signatures against supplied pins, then implements the terrain and reach/check equations directly. The child continued through 566 observations. Final integer terrain matched exactly. Reach, check and ratio matched within the declared numerical tolerance. All 566 readout rows differed from the empty-inheritance control on the same tape. That is a causal effect on these readouts under the fixture, with ecological value still unmeasured.

The run rejects a wrong parent, duplicate birth, altered tape, validly signed wrong target, validly signed stale head and duplicate resume. The receiving SQLite transaction stores one resumed result per checkpoint head. Reopening the local journal preserves that refusal.

## Builder choices and boundaries

- The Commons source and three Relational Transitions v0.2 modules are vendored as received. The small in-memory Commons hooks are in `capture.py`. The food-to-SDKP mapping is an explicit new experimental adapter. Size is one observation, density bins the noisy food observation, kinetics bins prediction error relative to the native tolerance, and position uses the world quadrant. The inherited slice uses the existing bounded projection on the parent's field at birth. The projection is a birth operation in this fixture.
- The child reads on a recorded Commons tape. The inherited readouts have yet to drive the child's actions in a live world. The Node port resumes that child's terrain, identity and readouts. Full ecology migration, TQNM dynamics integration, trait selection, and migration to native HAL remain future work.
- The RT birth authority uses its published test key. The builder holds a fresh software witness key for the checkpoint and approves the exact research fixture. Trust pins come through the runner and are independent of the packet. The SQLite journal is a local receiver fixture. Genesis or Minato integration and off-host custody remain open.
- The initial child ID was selected by first actual birth in native order. Every seed-0 observation and birth is recorded. The NO_ROLES result stays in the archive. Future falsification should include flat and foreign inheritance, an independently authored reader, and live decisions under changed resource conditions.

`evidence/summary.json` is the compact receipt. `comparison.json` contains all three readout streams. `resume_packet.json`, `fixture_trust.json` and `resumed.json` allow inspection. Fresh runs use a fresh witness key.
