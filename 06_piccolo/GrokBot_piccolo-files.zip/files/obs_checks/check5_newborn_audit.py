"""OBS check 5: audit a newborn organism before its first checkpoint has been witnessed.
Runs identical scenarios on humble_seed_v0_7 (01db270a...) and humble_seed_v0_7_1 (8b849cd0...).
Private keys stay in memory; nothing secret is printed."""
import importlib, hashlib, shutil
from pathlib import Path

def run(label, fn):
    try:
        print(f"  {label}: returned {fn()!r}")
    except Exception as ex:
        print(f"  {label}: {type(ex).__name__}: {ex}")

for name in ("humble_seed_v0_7", "humble_seed_v0_7_1"):
    m = importlib.import_module(name)
    print(f"\n=== {name} (sha256 {hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()}) ===")

    # A: hatched, genesis checkpoint never installed, never witnessed; audit the live object.
    d = Path(f"./c5_{name}_A"); shutil.rmtree(d, ignore_errors=True)
    s = m.HumbleSeed(data_dir=d); oid, pem, gcp = s.hatch()
    o = m.OwnerTool(pem, m.OwnerWitness(d / "witness.json"))
    print("A. hatch() only; no checkpoint installed; witness empty")
    run("owner.audit(live newborn)", lambda: o.audit(s))
    run("fresh HumbleSeed.load() from disk", lambda: m.HumbleSeed(data_dir=d).load())

    # C: owner signs the genesis checkpoint and the organism installs it,
    #    but the witness never records it (attest() bypassed).
    d = Path(f"./c5_{name}_C"); shutil.rmtree(d, ignore_errors=True)
    s = m.HumbleSeed(data_dir=d); oid, pem, gcp = s.hatch()
    w = m.OwnerWitness(d / "witness.json"); o = m.OwnerTool(pem, w)
    installed = s.install_checkpoint(gcp, o.sign_proposal(m.HumbleSeed.checkpoint_payload(gcp)))
    print(f"C. genesis checkpoint owner-signed and installed (install_checkpoint -> {installed}); witness ledger entries: {len(w.ledger)}")
    run("owner.audit(live newborn)", lambda: o.audit(s))
    r = m.HumbleSeed(data_dir=d)
    run("fresh HumbleSeed.load() from disk", lambda: r.load())
    run("owner.audit(reloaded newborn)", lambda: o.audit(r))
    run("witness.check_current(checkpoint)", lambda: w.check_current(r.checkpoint))
    run("owner with NO witness: OwnerTool(pem, None).audit(reloaded)", lambda: m.OwnerTool(pem, None).audit(r))
    # then the normal path: attest the next state, does the witness accept enrollment?
    run("after that: witness.check_successor(genesis cp) (enrollment)", lambda: w.check_successor(r.checkpoint))
    run("then witness.record(genesis cp) (late enrollment)", lambda: w.record(r.checkpoint))
    run("owner.audit(reloaded newborn) after late enrollment", lambda: o.audit(r))

    # B (control): normal path, attest() witnesses genesis, then audit.
    d = Path(f"./c5_{name}_B"); shutil.rmtree(d, ignore_errors=True)
    s = m.HumbleSeed(data_dir=d); oid, pem, gcp = s.hatch()
    o = m.OwnerTool(pem, m.OwnerWitness(d / "witness.json"))
    print(f"B. control: owner.attest(genesis) -> {o.attest(s, gcp)}; witness ledger entries: {len(o.witness.ledger)}")
    r = m.HumbleSeed(data_dir=d); r.load()
    run("owner.audit(reloaded newborn)", lambda: o.audit(r))
