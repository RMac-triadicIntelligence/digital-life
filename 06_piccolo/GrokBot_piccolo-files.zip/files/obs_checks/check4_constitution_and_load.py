"""OBS check 4: constitution text/hash v0.7 vs v0.7.1, and cross-version state loading.
Run in a scratch dir containing humble_seed_v0_7.py (01db270a...) and humble_seed_v0_7_1.py (8b849cd0...)."""
import importlib, json, hashlib, shutil, sys, inspect, re
from pathlib import Path
v07 = importlib.import_module("humble_seed_v0_7")
v071 = importlib.import_module("humble_seed_v0_7_1")
for m in (v07, v071):
    print(f"module {m.__name__}: file sha256 {hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} SCHEMA_VERSION={m.SCHEMA_VERSION!r}")

# (a) constitution text: compare the source of HumbleSeed.hatch (which builds the constitution literal)
s0 = inspect.getsource(v07.HumbleSeed.hatch); s1 = inspect.getsource(v071.HumbleSeed.hatch)
print("hatch() source identical:", s0 == s1)

# (b) constitution hash computed the kernel's way: _sha256(_canonical_json(constitution)) from a real hatch
hashes = {}
for m in (v07, v071):
    d = Path(f"./c4_hatch_{m.__name__}"); shutil.rmtree(d, ignore_errors=True)
    s = m.HumbleSeed(data_dir=d); s.hatch()
    ch = m._sha256(m._canonical_json(s.constitution))
    assert ch == s.birth.constitution_hash
    hashes[m.__name__] = (ch, m._canonical_json(s.constitution))
    print(f"{m.__name__}: constitution_hash = {ch}  (birth.constitution_hash agrees: True)")
    print(f"{m.__name__}: constitution_root (checkpoint field) = {s._constitution_root()}")
print("constitution canonical JSON byte-identical:", hashes['humble_seed_v0_7'][1] == hashes['humble_seed_v0_7_1'][1])
print("constitution hash identical:", hashes['humble_seed_v0_7'][0] == hashes['humble_seed_v0_7_1'][0])

# (c) a state written by v0.7 (hatch, attest, one authorized mutation, attest) loaded by v0.7.1
def grow(m, d):
    shutil.rmtree(d, ignore_errors=True)
    s = m.HumbleSeed(data_dir=d)
    oid, pem, gcp = s.hatch()
    w = m.OwnerWitness(d / "witness.json"); o = m.OwnerTool(pem, w)
    assert o.attest(s, gcp)
    r = s.dwell_or_propose("verbosity", "response_length", "I always prefer shorter answers")
    cp = s.authorize_and_apply(r["proposal_id"], o.sign_proposal(r["payload_to_sign"]), "concise please")
    assert o.attest(s, cp)
    return oid, pem, s

def cross(writer, reader):
    d = Path(f"./c4_state_written_by_{writer.__name__}")
    oid, pem, s = grow(writer, d)
    print(f"\nstate written by {writer.__name__}: checkpoint sequence {s.checkpoint.sequence}, character {s.character}")
    print(f"  state file sha256 {hashlib.sha256(s._state_path().read_bytes()).hexdigest()}")
    r = reader.HumbleSeed(data_dir=d)
    try:
        r.load(); print(f"  {reader.__name__}.load(): OK, verify() = {r.verify()}, character {r.character}")
    except Exception as ex:
        print(f"  {reader.__name__}.load(): {type(ex).__name__}: {ex}"); return
    o = reader.OwnerTool(pem, reader.OwnerWitness(d / "witness.json"))
    for label, kw in (("audit(seed)", {}), ("audit(seed, expected_organism_id=oid)", {"expected_organism_id": oid})):
        if "expected" in label and "expected_organism_id" not in inspect.signature(reader.OwnerTool.audit).parameters:
            print(f"  {reader.__name__} OwnerTool.{label}: not available in this kernel"); continue
        try: print(f"  {reader.__name__} OwnerTool.{label}: {o.audit(r, **kw)}")
        except Exception as ex: print(f"  {reader.__name__} OwnerTool.{label}: {type(ex).__name__}: {ex}")
    # continue growing under the reader kernel
    rr = r.dwell_or_propose("formality", "tone", "I always prefer shorter answers")
    if rr.get("status") == "proposal":
        cp = r.authorize_and_apply(rr["proposal_id"], o.sign_proposal(rr["payload_to_sign"]), "ok")
        print(f"  {reader.__name__} continues growth: authorize_and_apply -> {cp is not None}, attest -> {o.attest(r, cp) if cp else None}, sequence {r.checkpoint.sequence}")
        r2 = reader.HumbleSeed(data_dir=d); r2.load(); print(f"  reload after growth under {reader.__name__}: OK, audit {o.audit(r2)}")
    else:
        print(f"  {reader.__name__} dwell_or_propose status: {rr.get('status')}")

cross(v07, v071)
cross(v071, v07)
