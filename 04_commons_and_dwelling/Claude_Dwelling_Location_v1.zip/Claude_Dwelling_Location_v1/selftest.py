"""Plumbing checks. None of these is evidence about the question; a failure aborts the build."""
import json, sys
from pathlib import Path
import locate as L
protocol = json.loads(Path("protocol.json").read_bytes())
if protocol["timer_stay_bp"]["2x3"] is None:
    protocol["timer_stay_bp"] = {"2x3": 0, "4x6": 0}
ok = True
def check(label, cond):
    global ok
    ok = ok and bool(cond); print(("PASS  " if cond else "FAIL  ") + label)
V2, MORNING = (Path(p) if p != "-" else None for p in (sys.argv[1:3] + ["-", "-"])[:2])
if V2:
    shipped = json.loads((V2 / "evidence/live/runs.json").read_bytes())
    for size in protocol["founders"]:
        for seed in (0, 1, 2):
            mine = L.world((protocol, "dev", "LIGHT", size, seed, None))
            theirs = next(r for r in shipped if r["size"] == size and r["arm"] == "NATIVE" and r["seed"] == seed)
            check(f"LIGHT {size} seed {seed} reproduces the shipped v2 NATIVE world receipt", mine["world"] == theirs["world"] and mine["births"] == theirs["births"])
if MORNING:
    morning = json.loads((MORNING / "runs.json").read_bytes())
    for size in protocol["founders"]:
        for seed in (40, 41):
            mine = L.world((protocol, "dev", "LIGHT", size, seed, None))
            theirs = next(r for r in morning if r["size"] == size and r["arm"] == "FIXED_HUSTLE" and r["seed"] == seed)
            check(f"LIGHT {size} seed {seed} reproduces this morning's FIXED_HUSTLE receipt", mine["world"] == theirs["world"] and mine["births"] == theirs["births"] and mine["deaths"] == theirs["deaths"])
dev = protocol["dev_seeds"][0]
for arm in L.ARMS:
    a = L.world((protocol, "dev", arm, [4, 6], dev, None)); b = L.world((protocol, "dev", arm, [4, 6], dev, None))
    check(f"{arm} runs, reruns identically, and its stay count matches the world's own stuck share", a == b)
n = L.world((protocol, "dev", "NONE", [2, 3], dev, None))
check("NONE never stays and is never released", n["stays"] == 0 and n["grace_releases"] == 0 and n["world"]["stuck_frac"] == 0.0)
print("ALL PASS" if ok else "SELFTEST FAILED"); sys.exit(0 if ok else 1)
