"""Set the TIMER arm's stay probability so its staying share matches LIGHT's. Development seeds only."""
import json, statistics as st
from pathlib import Path
import locate as L
path = Path("protocol.json"); protocol = json.loads(path.read_bytes())
dev = protocol["dev_seeds"]; log = []
for size in protocol["founders"]:
    key = f"{size[0]}x{size[1]}"
    work = json.loads(json.dumps(protocol)); work["timer_stay_bp"] = {"2x3": 0, "4x6": 0}
    target = st.mean(L.world((work, "dev", "LIGHT", size, s, None))["world"]["stuck_frac"] for s in dev)
    lo, hi, best = 0, 10_000, None
    for _ in range(11):
        mid = (lo + hi) // 2; work["timer_stay_bp"][key] = mid
        got = st.mean(L.world((work, "dev", "TIMER", size, s, None))["world"]["stuck_frac"] for s in dev)
        log.append(f"{key} q_bp={mid} timer_share={got:.4f} target={target:.4f}")
        if best is None or abs(got - target) < abs(best[1] - target): best = (mid, got)
        if got < target: lo = mid
        else: hi = mid
    protocol["timer_stay_bp"][key] = best[0]
    log.append(f"{key} CHOSEN q_bp={best[0]} timer_share={best[1]:.4f} target={target:.4f}")
path.write_text(json.dumps(protocol, indent=2) + "\n")
Path("CALIBRATION.txt").write_text("\n".join(log) + "\n"); print("\n".join(l for l in log if "CHOSEN" in l))
