"""Dwelling Location v1 - the Commons' own dwelling field and grace rule, unchanged, with only the
place the field is kept moved between arms. Nothing under vendor/ is edited; the source is patched
in memory at the four lines where the native code touches the member's field `a.d`."""
from __future__ import annotations

import gzip
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

if not __debug__:
    raise RuntimeError("assertions are part of this evidence; do not run with -O")

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "vendor/commons/commons_v2/sim_v2.py"
ARMS = ("LIGHT", "LAND", "FAMILY", "CENTRAL", "NONE", "TIMER")


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def hash_unit(*parts):
    return int.from_bytes(hashlib.sha256(canon(list(parts))).digest()[:4], "big")   # 0 .. 2**32-1


def frozen_protocol():
    raw = (HERE / "protocol.json").read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    pinned = HERE / "protocol.sha256"
    if pinned.exists() and pinned.read_text().split()[0] != digest:
        raise RuntimeError("protocol.json does not match protocol.sha256")
    return json.loads(raw), digest


def load_world(dw_up, dw_down, dw_stay, dw_release, born, died, census, regrow):
    original = SOURCE.read_text()
    patches = [
        ("a.d += D_UP * (1 - a.d)", "dw_up(a, fam)"),
        ("a.d -= D_DOWN * a.d", "dw_down(a, fam)"),
        ("if a.d > D_STAY and here > DWELL_FOOD:", "if here > DWELL_FOOD and dw_stay(t, a, fam):"),
        ("a.d, a.run = 0.3, 0", "dw_release(a, fam); a.run = 0"),
        ("                            live.append(agents[-1])", "                            born(p, agents[-1])\n                            live.append(agents[-1])"),
        ("                a.alive = False", "                a.alive = False\n                died(t, a)"),
        ("        Keff = np.maximum", "        census(t, live, fams)\n        Keff = np.maximum"),
        ("R + REGROW * R", "R + regrow(t, REGROW) * R"),
    ]
    for old, new in patches:
        if original.count(old) != 1:
            raise ValueError(f"native source layout changed at {old!r}")
        original = original.replace(old, new)
    scope = dict(__file__=str(SOURCE), dw_up=dw_up, dw_down=dw_down, dw_stay=dw_stay, dw_release=dw_release,
                 born=born, died=died, census=census, regrow=regrow)
    exec(compile(original, str(SOURCE), "exec"), scope)
    return scope


def world(task):
    protocol, digest, arm, size, seed, out_dir = task
    assert arm in ARMS
    cfg = protocol["world"]
    q_bp = protocol["timer_stay_bp"][f"{size[0]}x{size[1]}"]
    c, state = {}, {"land": None, "central": 0.0}
    counts = Counter()
    births, deaths, census_rows, episodes, runs = [], [], [], [], {}
    cover = [0.0, 0]

    def land():
        if state["land"] is None:
            state["land"] = np.zeros((c["N"], c["N"]))
        return state["land"]

    def dw_up(a, fam):
        counts["steps"] += 1; counts["surprised"] += 1
        if arm == "LIGHT":
            a.d += c["UP"] * (1 - a.d)
        elif arm == "LAND":
            g = land(); v = float(g[a.x, a.y]); g[a.x, a.y] = v + c["UP"] * (1 - v)
        elif arm == "FAMILY":
            v = getattr(fam, "dw", 0.0); fam.dw = v + c["UP"] * (1 - v)
        elif arm == "CENTRAL":
            state["central"] += c["UP"] * (1 - state["central"])

    def dw_down(a, fam):
        counts["steps"] += 1
        if arm == "LIGHT":
            a.d -= c["DOWN"] * a.d
        elif arm == "LAND":
            g = land(); v = float(g[a.x, a.y]); g[a.x, a.y] = v - c["DOWN"] * v
        elif arm == "FAMILY":
            v = getattr(fam, "dw", 0.0); fam.dw = v - c["DOWN"] * v
        elif arm == "CENTRAL":
            state["central"] -= c["DOWN"] * state["central"]

    def dw_stay(t, a, fam):                 # called only where the member stands on food
        if arm == "LIGHT":
            s = a.d > c["STAY"]
        elif arm == "LAND":
            s = float(land()[a.x, a.y]) > c["STAY"]
        elif arm == "FAMILY":
            s = getattr(fam, "dw", 0.0) > c["STAY"]
        elif arm == "CENTRAL":
            s = state["central"] > c["STAY"]
        elif arm == "TIMER":
            s = hash_unit(seed, "timer", t, a.id) * 10_000 < q_bp * 2 ** 32
        else:
            s = False
        if s:
            counts["stays"] += 1
        return bool(s)

    def dw_release(a, fam):                 # grace: the conductor releases the longest dweller
        counts["grace"] += 1
        runs[a.id] = a.run                  # the episode it is released from, at full length
        if arm == "LIGHT":
            a.d = 0.3
        elif arm == "LAND":
            land()[a.x, a.y] = 0.3
        elif arm == "FAMILY":
            fam.dw = 0.3
        elif arm == "CENTRAL":
            state["central"] = 0.3

    def close_episode(agent_id):
        length = runs.pop(agent_id, 0)
        if length:
            episodes.append(length)

    def born(parent, child):
        births.append([child.born, child.id, parent.id, child.lineage])

    def died(t, a):
        deaths.append([t, a.id, a.lineage])
        if a.run:
            runs[a.id] = a.run              # it was still dwelling this tick
        close_episode(a.id)

    def census(t, live, fams):
        pop = Counter(a.lineage for a in live)
        for a in live:
            if a.run == 0:
                close_episode(a.id)
            else:
                runs[a.id] = a.run
        homes = {a.fam for a in live}
        for fid in homes:
            cover[0] += float((fams[fid].C > 0.2).sum()); cover[1] += 1
        census_rows.append([t, len(live), [pop[i] for i in range(size[0])]])

    def regrow(t, native):
        return native * cfg["regrowth_multiplier"] if t >= cfg["shock_tick"] else native

    scope = load_world(dw_up, dw_down, dw_stay, dw_release, born, died, census, regrow)
    assert scope["STEPS"] == cfg["ticks"]
    c.update(UP=scope["D_UP"], DOWN=scope["D_DOWN"], STAY=scope["D_STAY"], N=scope["N"])
    scope.update(FAMS=size[0], FOUNDERS=size[1])
    result = scope["run"](cfg["variant"], seed)
    for agent_id in list(runs):
        close_episode(agent_id)

    stays = counts["stays"]
    assert sum(episodes) == stays, (sum(episodes), stays)
    assert round(stays / max(counts["steps"], 1), 4) == result["stuck_frac"], (stays, counts["steps"], result["stuck_frac"])
    receipt = dict(
        protocol=digest, arm=arm, size=size, seed=seed, world=result,
        births=len(births), deaths=len(deaths),
        post_births=[sum(b[3] == i and b[0] >= cfg["shock_tick"] for b in births) for i in range(size[0])],
        member_ticks=counts["steps"], surprised=counts["surprised"], stays=stays, grace_releases=counts["grace"],
        episodes=len(episodes), episode_mean=round(stays / len(episodes), 4) if episodes else 0.0,
        episode_max=max(episodes) if episodes else 0,
        long_episode_share=round(sum(e for e in episodes if e >= 5) / stays, 4) if stays else 0.0,
        known_cells_mean=round(cover[0] / max(cover[1], 1), 2))
    if out_dir is not None:
        trace = dict(receipt=receipt, births=births, deaths=deaths, census=census_rows, episodes=sorted(episodes))
        raw = canon(trace)
        receipt = dict(receipt, trace_sha256=hashlib.sha256(raw).hexdigest())
        (Path(out_dir) / f"{size[0]}x{size[1]}_{arm}_{seed:03}.json.gz").write_bytes(gzip.compress(raw, mtime=0))
    return receipt


if __name__ == "__main__":
    protocol, digest = frozen_protocol()
    r = world((protocol, digest, sys.argv[1], [int(sys.argv[2]), int(sys.argv[3])], int(sys.argv[4]), None))
    print(json.dumps(r, indent=1))
