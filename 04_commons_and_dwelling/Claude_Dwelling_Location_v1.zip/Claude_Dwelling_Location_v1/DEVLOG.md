# Development log — Dwelling Location v1

Everything here happened on seeds that are never scored: 0-2 and 40-41 (regression against earlier receipts) and 900-904 (development).

## Order of work
1. `PREDICTIONS.md` written and hashed before any code could run (see `FREEZE_LOG.txt`).
2. `locate.py` written. It patches the vendored Commons in memory at the four lines where the native code touches the member's field, and nowhere else that changes behaviour.
3. `selftest.py`: LIGHT reproduced the shipped v2 NATIVE world receipt on seeds 0, 1, 2 and this morning's FIXED_HUSTLE receipt on seeds 40, 41, at both sizes. Every arm reruns identically, and its stay count matches the world's own stuck share.
4. One bookkeeping bug found and fixed before any look at results: dwelling episodes ended by grace or by death were recorded one tick short. It affected only the episode statistics, never the world.
5. `calibrate.py` set the TIMER stay probability on development seeds so that its staying share matches LIGHT's (output in `CALIBRATION.txt`).
6. `dev_look.py` on development seeds, all arms, both sizes (output in `dev_look_1.txt`).
7. Protocol and code hashed. Scored seeds run once. Replication seeds run afterwards with nothing changed.

## What the development look showed (5 seeds, not evidence)
- Close to half of all observations count as surprising in every arm (0.46-0.49). The Commons' observation noise is as large as its disagreement threshold, so the field is mostly fed by noise.
- Grace never fired in any arm. No member dwelt 15 ticks in a row. Mean dwelling episode is about 1.5 ticks.
- LAND stays far less than the others (about 0.06-0.08 of member-ticks against about 0.21-0.23).

## Decision
Nothing was changed after the development look. The UNINFORMATIVE flag in the predictions exists for exactly the first point above.
