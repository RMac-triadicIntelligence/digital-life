"""Run every arm at both sizes on a seed set and score the written predictions and decision rule."""
import argparse, json, math, statistics as st
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import locate as L

ALTS = ("LAND", "FAMILY", "CENTRAL")


def sign_test(deltas):
    wins, losses = sum(d > 0 for d in deltas), sum(d < 0 for d in deltas)
    n = wins + losses
    p = 1.0 if n == 0 else min(1.0, 2 * sum(math.comb(n, k) for k in range(min(wins, losses) + 1)) / 2 ** n)
    return dict(mean=round(st.mean(deltas), 5), wins=wins, losses=losses, ties=len(deltas) - n, p=round(p, 6))


pop = lambda r: r["world"]["pop_final"]
err = lambda r: r["world"]["map_error"]


def summarize(protocol, receipts):
    out = {}
    for size in protocol["founders"]:
        rows = {arm: sorted((r for r in receipts if r["size"] == size and r["arm"] == arm), key=lambda r: r["seed"]) for arm in protocol["arms"]}
        mean = lambda arm, f: round(st.mean(f(r) for r in rows[arm]), 5)
        arms = {arm: dict(
            final_population=mean(arm, pop), map_error=mean(arm, err), extinct=sum(pop(r) == 0 for r in rows[arm]),
            stay_share=mean(arm, lambda r: r["world"]["stuck_frac"]), known_cells=mean(arm, lambda r: r["known_cells_mean"]),
            births=mean(arm, lambda r: r["births"]), deaths=mean(arm, lambda r: r["deaths"]),
            post_shock_births_per_lineage=round(mean(arm, lambda r: sum(r["post_births"])) / size[0], 4),
            lineages_alive=mean(arm, lambda r: r["world"]["families_alive"]),
            per_capita_harvest=mean(arm, lambda r: r["world"]["per_capita"]), stock_min=mean(arm, lambda r: r["world"]["stock_min"]),
            episode_mean=mean(arm, lambda r: r["episode_mean"]), long_episode_share=mean(arm, lambda r: r["long_episode_share"]),
            episode_max=max(r["episode_max"] for r in rows[arm]), grace_releases=sum(r["grace_releases"] for r in rows[arm]),
            surprised_share=mean(arm, lambda r: r["surprised"] / r["member_ticks"])) for arm in protocol["arms"]}
        def cmp(other, f):   # LIGHT minus other
            return sign_test([f(a) - f(b) for a, b in zip(rows["LIGHT"], rows[other], strict=True)])
        out[f"{size[0]}x{size[1]}"] = dict(
            arms=arms,
            light_minus_other_population={o: cmp(o, pop) for o in protocol["arms"] if o != "LIGHT"},
            light_minus_other_map_error={o: cmp(o, err) for o in protocol["arms"] if o != "LIGHT"},
            light_minus_other_episode_mean={o: cmp(o, lambda r: r["episode_mean"]) for o in ("TIMER",)})
    return out


def score(s):
    S, C = s["2x3"], s["4x6"]
    A = lambda z, arm, k: z["arms"][arm][k]
    P = lambda z, o: z["light_minus_other_population"][o]
    E = lambda z, o: z["light_minus_other_map_error"][o]
    rows = {}
    rows["L1a staying share matched within 0.02 (LIGHT vs TIMER), both sizes"] = all(abs(A(z, "LIGHT", "stay_share") - A(z, "TIMER", "stay_share")) <= 0.02 for z in (S, C))
    rows["L1b map error lower under LIGHT than TIMER, both sizes (more seeds lower than higher)"] = all(E(z, "TIMER")["losses"] > E(z, "TIMER")["wins"] for z in (S, C))
    rows["L1c population LIGHT vs TIMER not reliably different, both sizes"] = all(P(z, "TIMER")["p"] > 0.05 for z in (S, C))
    rows["L2 LIGHT population above LAND when crowded (wins > losses), and LIGHT map error not higher at either size"] = (
        P(C, "LAND")["wins"] > P(C, "LAND")["losses"] and all(A(z, "LIGHT", "map_error") <= A(z, "LAND", "map_error") for z in (S, C)))
    rows["L3 LIGHT mean map error lower than FAMILY and CENTRAL, both sizes"] = all(A(z, "LIGHT", "map_error") < A(z, o, "map_error") for z in (S, C) for o in ("FAMILY", "CENTRAL"))
    rows["L4 LIGHT mean map error lower than NONE at both sizes, and LIGHT population higher when crowded"] = (
        all(A(z, "LIGHT", "map_error") < A(z, "NONE", "map_error") for z in (S, C)) and A(C, "LIGHT", "final_population") > A(C, "NONE", "final_population"))
    rows["L5 LIGHT mean dwelling episode longer than TIMER, both sizes"] = all(A(z, "LIGHT", "episode_mean") > A(z, "TIMER", "episode_mean") for z in (S, C))
    preds = {k: ("HOLDS" if v else "FAILS") for k, v in rows.items()}
    as_good = lambda z, a, b: A(z, a, "final_population") >= A(z, b, "final_population") and A(z, a, "map_error") <= A(z, b, "map_error")
    alt_beats = [o for o in ALTS if all(as_good(z, o, "LIGHT") for z in (S, C))]
    light_ok = all(as_good(z, "LIGHT", o) for z in (S, C) for o in ALTS)
    def reliably_better(o):   # LIGHT reliably better than o on some measure at some size
        return any((P(z, o)["p"] <= 0.05 and P(z, o)["wins"] > P(z, o)["losses"]) or (E(z, o)["p"] <= 0.05 and E(z, o)["losses"] > E(z, o)["wins"]) for z in (S, C))
    verdict = "FAILS" if alt_beats else ("SUPPORTED" if light_ok and all(reliably_better(o) for o in ALTS) else "MIXED")
    uninformative = all(P(z, "TIMER")["p"] > 0.05 and E(z, "TIMER")["p"] > 0.05 for z in (S, C))
    return dict(predictions=preds, decision=dict(verdict=verdict, placements_at_least_as_good_as_light_everywhere=alt_beats,
                light_at_least_as_good_as_every_placement=light_ok,
                light_reliably_better_than={o: reliably_better(o) for o in ALTS},
                uninformative_flag_light_cannot_be_told_from_timer=uninformative))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("out", type=Path); ap.add_argument("--seeds", choices=["seeds", "replication_seeds"], default="seeds")
    args = ap.parse_args()
    protocol, digest = L.frozen_protocol()
    args.out.mkdir(parents=True, exist_ok=False)
    tasks = [(protocol, digest, arm, size, seed, args.out) for size in protocol["founders"] for arm in protocol["arms"] for seed in protocol[args.seeds]]
    with ProcessPoolExecutor(max_workers=2) as pool:
        receipts = list(pool.map(L.world, tasks, chunksize=4))
    (args.out / "runs.json").write_bytes(L.canon(receipts) + b"\n")
    summary = summarize(protocol, receipts); summary["score"] = score(summary)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"{len(receipts)} runs on {args.seeds}, protocol {digest}")


if __name__ == "__main__":
    main()
