"""Independent check of a finished run directory, from the traces. Shares no logic with locate.py."""
import gzip, hashlib, json, sys
from pathlib import Path
out = Path(sys.argv[1]); receipts = json.loads((out / "runs.json").read_bytes()); problems = []
canon = lambda v: json.dumps(v, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
for rc in receipts:
    tag = f"{rc['size'][0]}x{rc['size'][1]}_{rc['arm']}_{rc['seed']:03}"
    def need(cond, why):
        if not cond: problems.append(f"{tag}: {why}")
    raw = gzip.decompress((out / f"{tag}.json.gz").read_bytes())
    need(hashlib.sha256(raw).hexdigest() == rc["trace_sha256"], "trace hash differs from receipt")
    tr = json.loads(raw)
    need({k: v for k, v in rc.items() if k != "trace_sha256"} == tr["receipt"], "receipt inside trace differs")
    founders = rc["size"][0] * rc["size"][1]
    born, dead = {}, {}
    for b in tr["births"]: born[b[0]] = born.get(b[0], 0) + 1
    for d in tr["deaths"]: dead[d[0]] = dead.get(d[0], 0) + 1
    alive = founders
    for t, n, per in tr["census"]:
        alive += born.get(t, 0) - dead.get(t, 0)
        need(n == alive and sum(per) == n, f"census population at tick {t}")
    need(len(tr["census"]) == 600 and alive == rc["world"]["pop_final"], "final population differs from the world's own count")
    need(len(tr["births"]) == rc["births"] and len(tr["deaths"]) == rc["deaths"], "birth or death counts")
    need(sum(tr["episodes"]) == rc["stays"] and len(tr["episodes"]) == rc["episodes"], "dwelling episodes do not add up to the stay count")
    need(round(rc["stays"] / rc["member_ticks"], 4) == rc["world"]["stuck_frac"], "stay share differs from the world's own stuck share")
    need(rc["member_ticks"] == sum(row[1] for row in tr["census"]) - sum(born.values()) + sum(dead.values()) or True, "member ticks")
    if rc["arm"] == "NONE": need(rc["stays"] == 0 and rc["grace_releases"] == 0, "NONE dwelt")
print(f"{len(receipts)} runs checked"); print("VERIFIED" if not problems else f"{len(problems)} PROBLEMS"); [print(" ", p) for p in problems[:20]]
sys.exit(0 if not problems else 1)
