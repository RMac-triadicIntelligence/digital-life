"""Development look on development seeds only (never scored)."""
import json, statistics as st
from pathlib import Path
import locate as L
protocol = json.loads(Path("protocol.json").read_bytes())
for size in protocol["founders"]:
    print("==", size)
    for arm in L.ARMS:
        rows = [L.world((protocol, "dev", arm, size, s, None)) for s in protocol["dev_seeds"]]
        w = lambda k: st.mean(r["world"][k] for r in rows); m = lambda k: st.mean(r[k] for r in rows)
        print(f"{arm:8s} pop={w('pop_final'):5.1f} map_err={w('map_error'):.4f} stay_share={w('stuck_frac'):.3f} known_cells={m('known_cells_mean'):6.1f} births={m('births'):5.1f} deaths={m('deaths'):5.1f} "
              f"episode_mean={m('episode_mean'):5.2f} long_share={m('long_episode_share'):.3f} grace={m('grace_releases'):5.1f} surprised_share={st.mean(r['surprised']/r['member_ticks'] for r in rows):.3f} extinct={sum(r['world']['pop_final']==0 for r in rows)}")
