# Predictions — written before any code in this build was run

Build: Dwelling Location v1 (Claude). Date: 2026-11-12.
Hash and time are in `FREEZE_LOG.txt`. No arm other than LIGHT had been run on any seed when this was written. LIGHT is the native Commons world, which I ran this morning as FIXED_HUSTLE on seeds 40-79, so those seeds are not scored here.

Scored seeds: 80-99. Replication seeds: 100-119. Sizes: 2 lineages x 3 founders ("sparse") and 4 lineages x 6 founders ("crowded").

## The inference under test

After reading the dwelling record again, I inferred that the dwelling field belongs to the living member (the light), and not to the land, the household, or anything held centrally. The conductor said: test it.

## How it is tested

The Commons world already has a dwelling field and a grace rule, frozen in its own preregistration:
- Each member has a value d. Disagreement between what it sees and what it believes raises d; agreement lowers it. While d is above 0.6, and there is food where it stands, it stays put and keeps sampling.
- From outside, every 10 ticks the conductor releases the one member that has dwelt longest (15 ticks or more in a row).

I change none of that. I change only where d is kept:

| Arm | Where the field lives | Indexed by |
|---|---|---|
| LIGHT | in the member (native, unchanged) | each member |
| LAND | in the ground | each cell of the world |
| FAMILY | in the household | each household |
| CENTRAL | with one holder outside the members | one value for the world |
| NONE | nowhere: nobody dwells | - |
| TIMER | nowhere: members stay on a coin flip at the same rate LIGHT stays | - |

The update rule, the thresholds and the grace rule are the same in every arm. In LAND, FAMILY and CENTRAL the same observations feed the field; only what holds it differs.

Primary measures: mean final population (higher is better) and the world's own map error (lower is better). Paired by seed, exact two-sided sign test.

## Predictions

- L1. LIGHT vs TIMER, with staying share matched within 0.02: map error is lower under LIGHT at both sizes (wins exceed losses). Final population is not reliably different at either size (p > 0.05).
- L2. LIGHT vs LAND: LIGHT ends with the larger population when crowded (wins exceed losses), and LIGHT's mean map error is not higher than LAND's at either size.
- L3. LIGHT vs FAMILY and LIGHT vs CENTRAL: LIGHT's mean map error is lower at both sizes. I make no prediction on population: a shared field may make everyone stay at once, and this morning showed that staying helps a crowded world.
- L4. LIGHT vs NONE: map error is lower under LIGHT at both sizes, and LIGHT's population is higher when crowded.
- L5. Occupancy: LIGHT's mean dwelling episode is longer than TIMER's at both sizes.

My least confident prediction is L3.

## Decision rule, fixed now

"At least as good" means mean final population not lower and mean map error not higher.

- **FAILS in this world:** some other placement (LAND, FAMILY or CENTRAL) is at least as good as LIGHT on both measures at both sizes, on the scored set.
- **SUPPORTED in this world:** LIGHT is at least as good as every other placement on both measures at both sizes, and reliably better (p <= 0.05) than each of them on at least one measure at at least one size.
- **MIXED:** anything else. Reported as mixed.
- **UNINFORMATIVE:** if LIGHT cannot be told from TIMER on either measure at either size, then the Commons' dwelling field is behaving as a timer, and comparing where it lives says little about dwelling. That gets reported ahead of any verdict above.

## Limits stated in advance

- This tests one embodiment of dwelling, the Commons' own. It is not the uncertainty basin from the June design, which this world does not contain.
- The Commons' observation noise is as large as its disagreement threshold, so much of the field's movement may be noise. That is why the TIMER arm is here.
- Classical code. Says nothing about the quantum identities.
