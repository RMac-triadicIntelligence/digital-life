"""Development look on dev seeds only (never scored). Output is kept in DEVLOG."""
import sys, json
import change as C
protocol, digest = C.frozen_protocol()
arms = sys.argv[1].split(",") if len(sys.argv) > 1 else list(C.ARMS)
for size in protocol["founders"]:
    print("==", size)
    for arm in arms:
        rows = [C.world((protocol, digest, arm, size, s, None)) for s in protocol["dev_seeds"]]
        m = lambda k: sum(r[k] for r in rows) / len(rows)
        print(f"{arm:14s} pop_final={sum(r['world']['pop_final'] for r in rows)/len(rows):5.1f} births={m('births'):5.1f} deaths={m('deaths'):5.1f} "
              f"against={m('against'):7.1f} opened={m('opened'):6.1f} released={m('released'):6.1f} confirmed={m('confirmed'):6.1f} "
              f"to_rest={m('to_rest'):6.1f} to_hustle={m('to_hustle'):6.1f} last_third={m('crossings_last_third'):5.1f} "
              f"rest_last100={sum(r['rest_fraction_last100'] or 0 for r in rows)/len(rows):.3f} pauses={m('pauses'):7.1f} extinct={sum(r['world']['pop_final']==0 for r in rows)}")
