"""Replication set on seeds 60-79. Run AFTER the scored results were seen, with the frozen code and
protocol unchanged. It is a check on whether the scored findings repeat, not a second scored run."""
import json, sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import change as C, run as R

if __name__ == "__main__":
    protocol, digest = C.frozen_protocol()
    out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
    seeds = list(range(60, 80))
    tasks = [(protocol, digest, arm, size, seed, out) for size in protocol["founders"] for arm in protocol["arms"] for seed in seeds]
    with ProcessPoolExecutor(max_workers=2) as pool:
        receipts = list(pool.map(C.world, tasks, chunksize=4))
    (out / "runs.json").write_bytes(C.canon(receipts) + b"\n")
    summary = R.summarize(protocol, receipts); summary["predictions"] = R.score(summary)
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"{len(receipts)} replication runs on seeds 60-79, protocol {digest}")
