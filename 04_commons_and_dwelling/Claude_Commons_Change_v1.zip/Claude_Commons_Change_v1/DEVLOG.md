# Development log — Commons Change v1

Everything here happened on seeds that are never scored: 0-2 (regression against shipped v2 receipts) and 900-904 (development).

## Order of work
1. `PREDICTIONS.md` written and hashed before any code could run (see `FREEZE_LOG.txt`).
2. `protocol.json` written, then `change.py`.
3. `selftest.py`: FIXED_HUSTLE reproduced the shipped v2 NATIVE world receipt on seeds 0, 1, 2 at both sizes; holding without the outside authority gave the same world as ASK on three development seeds at both sizes; rerun identical.
4. `dev_look.py` on development seeds 900-904, all arms, both sizes. Output kept in `dev_look_1.txt`.
5. `gate_cases.py`: 13 cases, all as expected. `verify.py` written; six tampered traces all caught.
6. Code and protocol hashed. Scored seeds run once.

## What the development look showed (5 seeds, not evidence)
- The reading rule fires: questions open, some are released, most are confirmed.
- Crossings go almost entirely one way. In ASK, about 16 to rest and 0.2 back per run at 2x3; about 36 and 0.6 at 4x6. A rester almost never gets a reading against its way.
- Rest fraction over the last 100 ticks was higher at 2x3 (0.91) than at 4x6 (0.67). That is the opposite of my prediction M5.
- BIOLOGY_MIXED: rest fraction fell from 0.5 at founding.

## Decision
No rule, constant or arm was changed after the development look. The near one-way crossing is one of the three things `PREDICTIONS.md` said would count against the build. It stays in and gets reported.

## Candidates deliberately not built (for a later round, conductor's call)
- A member in question reading the gate marks others left on the land.
- A second reading rule where the member reads its own need before the land's.
- Grace as its own operator. This build has only the asking path.
