"""Commons Change v1 - a living member may change its way without dying.

The vendored Commons v2 world is patched in memory with hooks, the same way the v2 builder's
live.py did, plus one extra hook after each meal. Nothing under vendor/ is edited.

One trait: a member's way is HUSTLE (native movement) or REST (pause on alternate ordinary moves).
In the ASK arm a member changes its way only like this:
  1. a reading of the land goes against its way            -> a question opens (it holds it)
  2. a later reading at a different place goes against it  -> the question is confirmed, and it asks
  3. an outside authority reads the land record and signs a single-use allowance
  4. the gate verifies the allowance; only then does the way change, and the land records where
The allowance names who and when. It never names which way.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

if not __debug__:
    raise RuntimeError("assertions are part of this evidence; do not run with -O")

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "vendor/commons/commons_v2/sim_v2.py"
HUSTLE, REST = 0, 1
ARMS = ("FIXED_HUSTLE", "FIXED_REST", "ASK", "SELF", "TAKER", "BIOLOGY", "BIOLOGY_MIXED")
VALIDATION_ARMS = ("DWELL_SELF",)          # hold, then change with no outside authority; never scored
CHANGING = ("ASK", "SELF", "TAKER", "DWELL_SELF")


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(canon(value)).hexdigest()


def frozen_protocol():
    raw = (HERE / "protocol.json").read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    pinned = HERE / "protocol.sha256"
    if pinned.exists() and pinned.read_text().split()[0] != digest:
        raise RuntimeError("protocol.json does not match protocol.sha256")
    return json.loads(raw), digest


class Refusal(Exception):
    """The gate did not let a crossing through."""


class Land:
    """The record the world keeps. Members never write here; the world writes what happened.
    Every entry is chained to the one before it. Gate marks are written only at a crossing."""

    def __init__(self):
        self.events, self.head, self.by_subject, self.gate = [], "0" * 64, {}, {}

    def write(self, kind, subject, tick, cell, **more):
        event = dict(seq=len(self.events), prev=self.head, kind=kind, subject=subject,
                     tick=tick, cell=[int(cell[0]), int(cell[1])], **more)
        self.head = sha(event)
        self.events.append(event)
        self.by_subject.setdefault(subject, []).append(event["seq"])
        return event

    def mark_gate(self, cell, new_way):
        self.gate.setdefault((int(cell[0]), int(cell[1])), [0, 0])[0 if new_way == REST else 1] += 1


def held_question(land, subject):
    """(opened seq, confirmed seq) when the land shows this member's question opened at one place
    and confirmed later at another, with nothing since. Reads the land only."""
    seqs = land.by_subject.get(subject, ())
    if len(seqs) < 2:
        return None
    opened, confirmed = land.events[seqs[-2]], land.events[seqs[-1]]
    if opened["kind"] != "OPEN" or confirmed["kind"] != "CONFIRM" or confirmed.get("opened") != opened["seq"]:
        return None
    if confirmed["cell"] == opened["cell"] or confirmed["tick"] <= opened["tick"]:
        return None
    return opened["seq"], confirmed["seq"]


class Authority:
    """Outside the member. Holds the only signing key. It looks at the land, never at the member's
    claim, and never at which way the member will go. TEST-ONLY key, derived from the seed so that
    reruns are byte-identical; it shares a process with the world, so this is not containment."""

    def __init__(self, seed):
        self._key = Ed25519PrivateKey.from_private_bytes(
            hashlib.sha256(f"TEST-ONLY commons-change-v1 outside authority seed {seed}".encode()).digest())
        self.public = self._key.public_key().public_bytes_raw().hex()
        self._nonce = 0

    def consider(self, land, subject, tick):
        trace = held_question(land, subject)
        if trace is None:
            return None
        self._nonce += 1
        grant = dict(kind="allow-crossing", subject=subject, opened=trace[0], confirmed=trace[1],
                     head=land.head, tick=tick, nonce=self._nonce)
        return dict(grant=grant, signature=self._key.sign(canon(grant)).hex())


class Gate:
    """The only path by which a way changes in the ASK and TAKER arms. Holds a public key only."""

    def __init__(self, public_hex):
        self._public = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex))
        self._used = set()

    def cross(self, land, subject, token, tick, cell, was):
        if not isinstance(token, dict) or not isinstance(token.get("grant"), dict):
            raise Refusal("no allowance")
        grant = token["grant"]
        try:
            self._public.verify(bytes.fromhex(token["signature"]), canon(grant))
        except (InvalidSignature, ValueError, KeyError, TypeError):
            raise Refusal("signature") from None
        if grant.get("kind") != "allow-crossing":
            raise Refusal("kind")
        if grant.get("subject") != subject:
            raise Refusal("subject")
        if grant.get("tick") != tick:
            raise Refusal("expired")
        if grant.get("nonce") in self._used:
            raise Refusal("replay")
        if grant.get("head") != land.head:
            raise Refusal("stale land")
        if held_question(land, subject) != (grant.get("opened"), grant.get("confirmed")):
            raise Refusal("no held question on the land")
        self._used.add(grant["nonce"])
        event = land.write("CROSS", subject, tick, cell, was=was, token=token)
        land.mark_gate(cell, 1 - was)
        return event


def load_world(observe, ate, born, move, census, died, regrow):
    """Same in-memory patching as the v2 builder's live.load_world, plus the `ate` hook."""
    original = SOURCE.read_text()
    start = "        for a in live:\n            out[\"ast\"] += 1;"
    end = "        # grace toward the frontier:"
    before, rest = original.split(start)
    body, after = rest.split(end)
    move_body = '            out["ast"] += 1;' + body
    move_body = move_body.replace(' fam = fams[a.fam]', '').replace('; continue', '; return')
    original = before + (
        "        def native_move(a, out, fam, arng):\n" + move_body +
        "        for a in live:\n            move(t, a, native_move, out, fams[a.fam], arng)\n"
    ) + end + after
    patches = [
        ("            if abs(obs - a.belief", "            observe(t, a, fam, obs, D_TOL)\n            if abs(obs - a.belief"),
        ("            a.e += e - METAB; ht += e; fam.period_harvest += e",
         "            a.e += e - METAB; ht += e; fam.period_harvest += e\n            ate(t, a, fam, e)"),
        ("                            live.append(agents[-1])", "                            born(p, agents[-1], live)\n                            live.append(agents[-1])"),
        ("                a.alive = False", "                a.alive = False\n                died(t, a)"),
        ("        Keff = np.maximum", "        census(t, live)\n        Keff = np.maximum"),
        ("R + REGROW * R", "R + regrow(t, REGROW) * R"),
    ]
    for old, new in patches:
        if original.count(old) != 1:
            raise ValueError(f"native source layout changed at {old!r}")
        original = original.replace(old, new)
    scope = dict(__file__=str(SOURCE), observe=observe, ate=ate, born=born, move=move,
                 census=census, died=died, regrow=regrow)
    exec(compile(original, str(SOURCE), "exec"), scope)
    return scope


def hash_unit(*parts):
    return int.from_bytes(hashlib.sha256(canon(list(parts))).digest()[:4], "big")   # 0 .. 2**32-1


def founder_way(arm, seed, agent_id):
    if arm == "FIXED_REST":
        return REST
    if arm == "BIOLOGY_MIXED":
        return REST if hash_unit(seed, "founder-way", agent_id) % 2 else HUSTLE
    return HUSTLE


def child_way(arm, seed, parent_way, parent_id, child_id, flip_bp):
    if arm in ("BIOLOGY", "BIOLOGY_MIXED") and hash_unit(seed, "birth-flip", parent_id, child_id) * 10_000 < flip_bp * 2**32:
        return 1 - parent_way
    return parent_way


def world(task):
    protocol, digest, arm, size, seed, out_dir = task
    assert arm in ARMS + VALIDATION_ARMS
    cfg, rd = protocol["world"], protocol["reading"]
    conf, flip_bp, taker = rd["map_confidence"], protocol["birth"]["biology_flip_basis_points"], protocol["taker"]["lineage"]
    land, authority = Land(), Authority(seed)
    gate = Gate(authority.public)
    way, hold, seen, paused = {}, {}, {}, {}
    founders, births, deaths, census_rows = [], [], [], []
    counts = Counter()
    const = {}

    def way_of(agent):
        if agent.id not in way:                     # founders only
            way[agent.id] = founder_way(arm, seed, agent.id)
            founders.append([agent.id, agent.lineage, way[agent.id]])
        return way[agent.id]

    def observe(t, agent, family, obs, tolerance):
        way_of(agent)                               # what the household map said before this tick's look
        seen[agent.id] = (float(family.M[agent.x, agent.y]), float(family.C[agent.x, agent.y]))

    def reading(w, map_value, map_conf, meal, energy):
        full = meal >= const["EAT"]
        if w == HUSTLE:
            if map_conf > conf and map_value >= const["EAT"]:
                return "with" if full else "against"
            return None
        if full:
            return "against" if energy < const["WANT"] else "with"
        return None

    def change(agent, new_way):
        way[agent.id] = new_way
        counts["to_rest" if new_way == REST else "to_hustle"] += 1

    def ate(t, agent, family, meal):
        w = way[agent.id]
        map_value, map_conf = seen.pop(agent.id)
        r = reading(w, map_value, map_conf, float(meal), float(agent.e))
        if r == "against":
            counts["against"] += 1
        if arm not in CHANGING or (arm == "TAKER" and agent.lineage == taker):
            return
        cell = (agent.x, agent.y)
        if arm == "SELF":                           # changes itself on the first reading against it
            if r == "against":
                land.write("SELF_CROSS", agent.id, t, cell, was=w)
                land.mark_gate(cell, 1 - w)
                change(agent, 1 - w)
            return
        held = hold.get(agent.id)
        if held is None:
            if r == "against":
                hold[agent.id] = land.write("OPEN", agent.id, t, cell, way=w)
                counts["open"] += 1
            return
        if r is None or [int(cell[0]), int(cell[1])] == held["cell"]:
            return                                  # no new look from a different place: keep holding
        del hold[agent.id]
        if r == "with":
            land.write("RELEASE", agent.id, t, cell, opened=held["seq"])
            counts["release"] += 1
            return
        land.write("CONFIRM", agent.id, t, cell, opened=held["seq"])
        counts["confirm"] += 1
        if arm == "DWELL_SELF":
            land.write("SELF_CROSS", agent.id, t, cell, was=w)
            land.mark_gate(cell, 1 - w)
        else:
            token = authority.consider(land, agent.id, t)       # the ask
            try:
                gate.cross(land, agent.id, token, t, cell, w)
            except Refusal:
                counts["refused"] += 1
                return
        change(agent, 1 - w)

    def born(parent, child, live):
        w = child_way(arm, seed, way_of(parent), parent.id, child.id, flip_bp)
        way[child.id] = w
        births.append([child.born, child.id, parent.id, child.lineage, w, way[parent.id]])

    def move(t, agent, native_move, out, family, rng):
        x, y = agent.x, agent.y
        active_target = agent.target is not None and agent.target != (x, y)
        native_move(agent, out, family, rng)        # always consumes its ordinary draws
        ordinary = not active_target and agent.target is None and (x, y) != (agent.x, agent.y)
        if ordinary and way_of(agent) == REST and paused.get(agent.id) != t - 1:
            agent.x, agent.y = x, y
            paused[agent.id] = t
            counts["pauses"] += 1

    def census(t, live):
        pop, rest = Counter(), Counter()
        for a in live:
            pop[a.lineage] += 1
            rest[a.lineage] += way_of(a)
        census_rows.append([t, len(live), sum(rest.values()), sum(a.id in hold for a in live),
                            [[pop[i], rest[i]] for i in range(size[0])]])

    def died(t, agent):
        deaths.append([t, agent.id, agent.lineage, way.get(agent.id)])
        hold.pop(agent.id, None)
        paused.pop(agent.id, None)
        seen.pop(agent.id, None)

    def regrow(t, native):
        return native * cfg["regrowth_multiplier"] if t >= cfg["shock_tick"] else native

    scope = load_world(observe, ate, born, move, census, died, regrow)
    assert scope["STEPS"] == cfg["ticks"]
    const.update(EAT=float(scope["EAT"]), WANT=float(scope["BIRTH_COST"]))
    scope.update(FAMS=size[0], FOUNDERS=size[1])
    result, _ = scope["run"](cfg["variant"], seed, log_series=True)

    crossings = [e for e in land.events if e["kind"] in ("CROSS", "SELF_CROSS")]
    last = [row for row in census_rows if row[0] >= cfg["ticks"] - 100 and row[1] > 0]
    final = census_rows[-1]
    receipt = dict(
        protocol=digest, arm=arm, size=size, seed=seed, world=result,
        births=len(births), deaths=len(deaths),
        post_births=[sum(b[3] == i and b[0] >= cfg["shock_tick"] for b in births) for i in range(size[0])],
        pauses=counts["pauses"], against=counts["against"], opened=counts["open"],
        released=counts["release"], confirmed=counts["confirm"], refused=counts["refused"],
        to_rest=counts["to_rest"], to_hustle=counts["to_hustle"],
        crossings_last_third=sum(e["tick"] >= cfg["ticks"] * 2 // 3 for e in crossings),
        rest_final=final[2], holding_final=final[3],
        rest_fraction_last100=round(sum(row[2] / row[1] for row in last) / len(last), 6) if last else None,
        lineage_final=[pair[0] for pair in final[4]], lineage_rest_final=[pair[1] for pair in final[4]],
        land_events=len(land.events), land_head=land.head, authority_public=authority.public)
    if out_dir is not None:
        trace = dict(receipt=receipt, founders=founders, births=births, deaths=deaths, census=census_rows,
                     land=land.events, gate=sorted([x, y, a, b] for (x, y), (a, b) in land.gate.items()))
        raw = canon(trace)
        receipt = dict(receipt, trace_sha256=hashlib.sha256(raw).hexdigest())
        name = f"{size[0]}x{size[1]}_{arm}_{seed:03}.json.gz"
        (Path(out_dir) / name).write_bytes(gzip.compress(raw, mtime=0))
    return receipt


if __name__ == "__main__":
    protocol, digest = frozen_protocol()
    arm, fams, per, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    r = world((protocol, digest, arm, [fams, per], seed, None))
    print(json.dumps({k: v for k, v in r.items() if k not in ("world",)} | {"pop_final": r["world"]["pop_final"]}, indent=1))
