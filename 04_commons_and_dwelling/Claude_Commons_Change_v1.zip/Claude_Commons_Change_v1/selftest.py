"""Plumbing checks. None of these is evidence about the question; a failure aborts the build."""
import json, sys, time
from pathlib import Path
import change as C

protocol, digest = C.frozen_protocol()
V2 = Path(sys.argv[1]) if len(sys.argv) > 1 else None
ok = True
def check(label, cond):
    global ok
    ok = ok and bool(cond)
    print(("PASS  " if cond else "FAIL  ") + label)

if V2 is not None:
    shipped = json.loads((V2 / "evidence/live/runs.json").read_bytes())
    for size in protocol["founders"]:
        for seed in (0, 1, 2):
            mine = C.world((protocol, digest, "FIXED_HUSTLE", size, seed, None))
            theirs = next(r for r in shipped if r["size"] == size and r["arm"] == "NATIVE" and r["seed"] == seed)
            check(f"FIXED_HUSTLE {size} seed {seed} reproduces the shipped v2 NATIVE world receipt, births and post-shock births",
                  mine["world"] == theirs["world"] and mine["births"] == theirs["births"] and mine["post_births"] == theirs["post_births"]
                  and mine["pauses"] == 0 and mine["land_events"] == 0)

dev = protocol["dev_seeds"]
for size in protocol["founders"]:
    for seed in dev[:3]:
        a = C.world((protocol, digest, "ASK", size, seed, None))
        d = C.world((protocol, digest, "DWELL_SELF", size, seed, None))
        same = all(a[k] == d[k] for k in ("world", "births", "deaths", "post_births", "pauses", "opened", "released",
                                           "confirmed", "to_rest", "to_hustle", "rest_final", "lineage_final"))
        check(f"hold without the outside authority gives the same world as ASK ({size}, dev seed {seed}); refusals in ASK: {a['refused']}",
              same and a["refused"] == 0)
a1 = C.world((protocol, digest, "ASK", [4, 6], dev[0], None)); a2 = C.world((protocol, digest, "ASK", [4, 6], dev[0], None))
check("deterministic rerun identical (ASK 4x6, dev seed)", a1 == a2)
t = C.world((protocol, digest, "TAKER", [4, 6], dev[0], None))
check("TAKER arm runs", t["world"]["pop_peak"] > 0)
for arm in ("FIXED_REST", "SELF", "BIOLOGY", "BIOLOGY_MIXED"):
    r = C.world((protocol, digest, arm, [2, 3], dev[0], None))
    check(f"{arm} runs; way changes only where the arm allows", (r["to_rest"] + r["to_hustle"] == 0) == (arm != "SELF") or arm == "SELF")
print("ALL PASS" if ok else "SELFTEST FAILED")
sys.exit(0 if ok else 1)
