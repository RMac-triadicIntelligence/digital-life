"""Independent check of a finished run directory. Re-derives everything it can from the traces.
Shares no logic with change.py: its own canonical JSON, hash chain, signature check and replay."""
import gzip, hashlib, json, sys
from collections import Counter
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

canon = lambda v: json.dumps(v, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
sha = lambda v: hashlib.sha256(canon(v)).hexdigest()
unit = lambda *parts: int.from_bytes(hashlib.sha256(canon(list(parts))).digest()[:4], "big")
out = Path(sys.argv[1])
protocol = json.loads(Path(sys.argv[2]).read_bytes()) if len(sys.argv) > 2 else json.loads((Path(__file__).parent / "protocol.json").read_bytes())
flip_bp, taker = protocol["birth"]["biology_flip_basis_points"], protocol["taker"]["lineage"]
receipts = json.loads((out / "runs.json").read_bytes())
problems, crossings_checked, events_checked = [], 0, 0

for rc in receipts:
    arm, size, seed = rc["arm"], rc["size"], rc["seed"]
    tag = f"{size[0]}x{size[1]}_{arm}_{seed:03}"
    def need(cond, why):
        if not cond: problems.append(f"{tag}: {why}")
    raw = gzip.decompress((out / f"{tag}.json.gz").read_bytes())
    need(hashlib.sha256(raw).hexdigest() == rc["trace_sha256"], "trace hash differs from receipt")
    tr = json.loads(raw)
    need({k: v for k, v in rc.items() if k != "trace_sha256"} == tr["receipt"], "receipt inside trace differs")
    # 1. the land is one unbroken chain
    head = "0" * 64
    for i, e in enumerate(tr["land"]):
        need(e["seq"] == i and e["prev"] == head, f"land chain broken at {i}")
        head = sha(e)
    need(head == rc["land_head"] and len(tr["land"]) == rc["land_events"], "land head or length differs")
    events_checked += len(tr["land"])
    # 2. who is who
    lineage = {f[0]: f[1] for f in tr["founders"]}
    way = {f[0]: f[2] for f in tr["founders"]}
    for fid, _, w in tr["founders"]:
        expect = 1 if arm == "FIXED_REST" else (unit(seed, "founder-way", fid) % 2 if arm == "BIOLOGY_MIXED" else 0)
        need(w == expect, f"founder {fid} way {w} not what the arm sets")
    need(len(tr["founders"]) == size[0] * size[1], "founder count")
    # 3. replay tick by tick: crossings, then deaths, then births, then the census
    by_tick = {}
    for e in tr["land"]: by_tick.setdefault(e["tick"], []).append(e)
    births_at, deaths_at = {}, {}
    for b in tr["births"]: births_at.setdefault(b[0], []).append(b)
    for d in tr["deaths"]: deaths_at.setdefault(d[0], []).append(d)
    alive, open_q, last_nonce, gate = set(lineage), {}, 0, Counter()
    pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(rc["authority_public"]))
    tally = Counter()
    for row in tr["census"]:
        t = row[0]
        for e in by_tick.get(t, ()):
            s, kind = e["subject"], e["kind"]
            need(s in alive, f"event for a member not alive at tick {t}")
            need(arm in ("ASK", "TAKER", "SELF"), "land written in an arm where nothing may change")
            need(not (arm == "TAKER" and lineage.get(s) == taker), "taker lineage has an event")
            if kind == "OPEN":
                need(arm != "SELF" and s not in open_q and e["way"] == way[s], "bad OPEN"); open_q[s] = e; tally["opened"] += 1
            elif kind in ("RELEASE", "CONFIRM"):
                o = open_q.get(s)
                need(o is not None and e["opened"] == o["seq"] and e["cell"] != o["cell"] and e["tick"] > o["tick"], f"bad {kind}")
                if kind == "RELEASE": open_q.pop(s, None); tally["released"] += 1
                else: open_q[s] = dict(o, confirmed=e); tally["confirmed"] += 1
            elif kind == "CROSS":
                o = open_q.pop(s, None); g = e["token"]["grant"]
                need(arm in ("ASK", "TAKER") and o is not None and "confirmed" in o, "CROSS without a held, confirmed question")
                try: pub.verify(bytes.fromhex(e["token"]["signature"]), canon(g)); sig = True
                except Exception: sig = False
                need(sig, "allowance signature does not verify")
                if o is not None and "confirmed" in o:
                    need(g["subject"] == s and g["tick"] == t and g["opened"] == o["seq"] and g["confirmed"] == o["confirmed"]["seq"]
                         and o["confirmed"]["tick"] == t and g["head"] == e["prev"] and g["kind"] == "allow-crossing", "allowance does not match the land")
                need(g["nonce"] > last_nonce, "allowance nonce reused or out of order"); last_nonce = g["nonce"]
                need("way" not in g and "to" not in g and "destination" not in g, "allowance names a direction")
                need(e["was"] == way[s], "CROSS from the wrong way")
                way[s] = 1 - way[s]; gate[(e["cell"][0], e["cell"][1], way[s])] += 1; crossings_checked += 1
                tally["to_rest" if way[s] else "to_hustle"] += 1
            elif kind == "SELF_CROSS":
                need(arm == "SELF" and e["was"] == way[s], "bad SELF_CROSS")
                way[s] = 1 - way[s]; gate[(e["cell"][0], e["cell"][1], way[s])] += 1
                tally["to_rest" if way[s] else "to_hustle"] += 1
            else:
                need(False, f"unknown event {kind}")
        for d in deaths_at.get(t, ()):
            need(d[1] in alive and d[3] == way[d[1]], "death record"); alive.discard(d[1]); open_q.pop(d[1], None)
        for b in births_at.get(t, ()):
            _, child, parent, lin, w, pw = b
            need(parent in alive and lineage[parent] == lin and pw == way[parent], "birth record")
            flipped = arm in ("BIOLOGY", "BIOLOGY_MIXED") and unit(seed, "birth-flip", parent, child) * 10_000 < flip_bp * 2 ** 32
            need(w == (1 - pw if flipped else pw), "child's way is not what the arm's birth rule gives")
            lineage[child], way[child] = lin, w; alive.add(child)
        need(row[1] == len(alive), f"census population at {t}")
        need(row[2] == sum(way[a] for a in alive), f"census resters at {t}")
        need(row[3] == sum(1 for a in open_q if "confirmed" not in open_q[a]), f"census holding at {t}")
        per = [[sum(1 for a in alive if lineage[a] == i), sum(way[a] for a in alive if lineage[a] == i)] for i in range(size[0])]
        need(row[4] == per, f"census by lineage at {t}")
    need(len(tr["census"]) == protocol["world"]["ticks"], "census length")
    need(rc["world"]["pop_final"] == len(alive), "final population differs from the native world's own count")
    for k in ("opened", "released", "confirmed", "to_rest", "to_hustle"):
        need(rc[k] == tally[k], f"receipt count {k}")
    marks = Counter()
    for x, y, a, b in tr["gate"]:
        if a: marks[(x, y, 1)] = a
        if b: marks[(x, y, 0)] = b
    need(marks == gate, "gate marks differ from the crossings on the land")
    need(rc["refused"] == 0, "an honest run had a refusal")

print(f"{len(receipts)} runs, {events_checked} land entries, {crossings_checked} signed crossings checked")
print("VERIFIED" if not problems else f"{len(problems)} PROBLEMS"); [print(" ", p) for p in problems[:20]]
sys.exit(0 if not problems else 1)
