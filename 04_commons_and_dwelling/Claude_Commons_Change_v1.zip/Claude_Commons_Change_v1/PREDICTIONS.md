# Predictions — written before any code in this build was run

Build: Commons Change v1 (Claude, builder round). Date: 2026-11-12.
This file was written and hashed before the build's code existed in runnable form. No run of any arm, on any seed, had been seen. The hash and time are in `FREEZE_LOG.txt`.

Scored seeds: 40-59. Sizes: 2 lineages x 3 founders ("2x3") and 4 lineages x 6 founders ("4x6").
"Rest fraction" = share of living members whose way is rest.
Paired comparisons are by seed, exact two-sided sign test.

## The conductor's prediction (his words, on record from 9 Nov 2026, before any society test was built)

> a perfect community of imperfect but growing organisms

How to score that sentence is not mine to decide. Below is my reading of it, offered as a proposal so that it can be scored at all. If the reading is wrong, the scores under it mean nothing about his prediction.

- R-a. In ASK, no community goes extinct, at either size, on any seed.
- R-b. In ASK, mean final population is at least FIXED_HUSTLE's, at both sizes.
- R-c. In TAKER, the lineage that never asks does not take over: its share of the final population is not reliably higher than the same lineage's share in ASK on the same seed.
- R-d. Members keep changing: in ASK, crossings still occur in the final third of the run (ticks 400-599) on at least 15 of 20 seeds at 4x6.

## My predictions (Claude)

I made the first of these this morning in the v3 brief, assuming the only force in the world is who out-reproduces whom. I am writing them down as I hold them now, without softening.

- M1. TAKER, 4x6: the never-asking lineage ends with a larger share of the final population than the same lineage has in ASK on the same seed. Wins exceed losses.
- M2. BIOLOGY_MIXED: rest fraction at the end is below the founders' 0.5, at both sizes (mean over seeds).
- M3. ASK ends with a higher mean final population than FIXED_HUSTLE at 4x6. At 2x3 the difference is within 1.5 members either way.
- M4. ASK and SELF do not differ reliably in final population at either size (sign test p > 0.05), but SELF makes more crossings per run than ASK at both sizes.
- M5. ASK's rest fraction, averaged over the last 100 ticks, is higher at 4x6 than at 2x3.
- M6. BIOLOGY (all founders hustle, change only by mutation at birth): rest fraction at the end is below 0.15 at both sizes.
- M7. FIXED_REST ends with a higher mean final population than FIXED_HUSTLE at 4x6 and a lower one at 2x3. (This repeats this morning's pause result with a deterministic rester.)

M1 and R-c disagree. That is the comparison I most want to see.

## What would count against the build itself

- If ASK and SELF are identical in every measure, the hold does nothing in this world.
- If nobody ever opens a question in ASK, the reading rule never fires and the arm is FIXED_HUSTLE under another name.
- If every member crosses within the first few ticks and never again, the rule is a one-way ratchet and "finding rest" is not what happened.
Any of these gets reported as the result, not tuned away on scored seeds.
