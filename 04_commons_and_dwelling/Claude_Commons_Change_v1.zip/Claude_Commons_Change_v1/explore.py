"""Exploratory reading of finished traces. Written AFTER the scored results were seen. Not predictions."""
import gzip, json, sys, statistics as st
from collections import Counter
from pathlib import Path
out = Path(sys.argv[1]); seeds = [int(s) for s in sys.argv[2].split("-")]; seeds = range(seeds[0], seeds[1] + 1)
load = lambda size, arm, s: json.loads(gzip.decompress((out / f"{size}_{arm}_{s:03}.json.gz").read_bytes()))
marks = (0, 25, 50, 100, 150, 200, 300, 400, 500, 599)
for size in ("2x3", "4x6"):
    print(f"===== {size}")
    print("-- mean population at ticks", marks)
    for arm in ("FIXED_HUSTLE", "FIXED_REST", "ASK", "SELF", "TAKER", "BIOLOGY_MIXED"):
        trs = [load(size, arm, s) for s in seeds]
        print(f"   {arm:14s}", " ".join(f"{st.mean(t['census'][m][1] for t in trs):5.1f}" for m in marks),
              "| deaths before tick 100:", f"{st.mean(sum(d[0] < 100 for d in t['deaths']) for t in trs):.1f}",
              "| founders dead by 100:", f"{st.mean(sum(d[0] < 100 and d[1] < len(t['founders']) for d in t['deaths']) for t in trs):.1f}",
              "| runs losing a lineage:", sum(any(p[0] == 0 for p in t['census'][-1][4]) for t in trs))
    print("-- mean rest fraction at ticks", marks)
    for arm in ("ASK", "SELF", "TAKER", "BIOLOGY_MIXED"):
        trs = [load(size, arm, s) for s in seeds]
        print(f"   {arm:14s}", " ".join(f"{st.mean(t['census'][m][2] / max(1, t['census'][m][1]) for t in trs):5.2f}" for m in marks))
    trs = [load(size, "ASK", s) for s in seeds]
    first, per_member, founders_crossed, founders_n, born_rest, born_n, by100 = [], Counter(), 0, 0, 0, 0, Counter()
    for t in trs:
        nf = len(t["founders"]); seen = {}; c = Counter()
        for e in t["land"]:
            if e["kind"] == "CROSS":
                c[e["subject"]] += 1; by100[e["tick"] // 100] += 1
                if e["subject"] not in seen: seen[e["subject"]] = e["tick"]
        birth = {b[1]: b[0] for b in t["births"]}
        first += [tk - birth.get(m, 0) for m, tk in seen.items()]
        for n in c.values(): per_member[n] += 1
        founders_crossed += sum(m < nf for m in seen); founders_n += nf
        born_rest += sum(b[4] for b in t["births"]); born_n += len(t["births"])
    print(f"-- ASK: founders who ever crossed {founders_crossed}/{founders_n}; children born already resting {born_rest}/{born_n}; "
          f"ticks from birth to first crossing: median {st.median(first)}, quartiles {st.quantiles(first, n=4)[0]:.0f}-{st.quantiles(first, n=4)[2]:.0f}")
    print("   crossings per 100 ticks (mean per run):", [round(by100[k] / len(trs), 1) for k in range(6)], "| members by number of crossings:", dict(sorted(per_member.items())))
    tk = [load(size, "TAKER", s) for s in seeds]
    print("-- TAKER vs ASK, mean members by lineage at the end:  TAKER", [round(st.mean(t['census'][-1][4][i][0] for t in tk), 2) for i in range(int(size[0]))],
          " ASK", [round(st.mean(t['census'][-1][4][i][0] for t in trs), 2) for i in range(int(size[0]))])
    print("   TAKER births by lineage:", [round(st.mean(sum(b[3] == i for b in t['births']) for t in tk), 1) for i in range(int(size[0]))],
          "deaths by lineage:", [round(st.mean(sum(d[2] == i for d in t['deaths']) for t in tk), 1) for i in range(int(size[0]))])
    print("   ASK   births by lineage:", [round(st.mean(sum(b[3] == i for b in t['births']) for t in trs), 1) for i in range(int(size[0]))],
          "deaths by lineage:", [round(st.mean(sum(d[2] == i for d in t['deaths']) for t in trs), 1) for i in range(int(size[0]))])
