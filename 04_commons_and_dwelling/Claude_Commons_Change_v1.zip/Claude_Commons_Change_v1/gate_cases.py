"""Attempts to get a crossing through the gate without a proper allowance. Each must be refused."""
import copy, hashlib, sys
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
import change as C

def fresh(confirm_cell=(5, 6)):
    land, auth = C.Land(), C.Authority(seed=123)
    gate = C.Gate(auth.public)
    o = land.write("OPEN", 7, 10, (5, 5), way=0)
    land.write("CONFIRM", 7, 14, confirm_cell, opened=o["seq"])
    return land, auth, gate

results = []
def attempt(label, fn, expect):
    try:
        fn(); got = "ACCEPTED"
    except C.Refusal as e:
        got = f"refused ({e})"
    ok = (got == "ACCEPTED") == (expect == "ACCEPTED")
    results.append(ok); print(("PASS  " if ok else "FAIL  ") + f"{label}: {got}")

land, auth, gate = fresh(); tok = auth.consider(land, 7, 14)
attempt("honest allowance, right member, same tick", lambda: gate.cross(land, 7, tok, 14, (5, 6), 0), "ACCEPTED")
attempt("the same allowance presented again", lambda: gate.cross(land, 7, tok, 14, (5, 6), 0), "REFUSED")

land, auth, gate = fresh(); tok = auth.consider(land, 7, 14)
bad = copy.deepcopy(tok); bad["signature"] = ("0" if bad["signature"][0] != "0" else "1") + bad["signature"][1:]
attempt("signature altered", lambda: gate.cross(land, 7, bad, 14, (5, 6), 0), "REFUSED")
mine = Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b"member 7 signs for itself").digest())
selfsigned = dict(grant=tok["grant"], signature=mine.sign(C.canon(tok["grant"])).hex())
attempt("member signs its own allowance", lambda: gate.cross(land, 7, selfsigned, 14, (5, 6), 0), "REFUSED")
edited = copy.deepcopy(tok); edited["grant"]["subject"] = 8
attempt("allowance edited to name another member", lambda: gate.cross(land, 8, edited, 14, (5, 6), 0), "REFUSED")
attempt("another member presents member 7's allowance", lambda: gate.cross(land, 8, tok, 14, (5, 6), 0), "REFUSED")
attempt("allowance presented a tick late", lambda: gate.cross(land, 7, tok, 15, (5, 6), 0), "REFUSED")
attempt("no allowance at all", lambda: gate.cross(land, 7, None, 14, (5, 6), 0), "REFUSED")
land.write("OPEN", 9, 14, (1, 1), way=0)
attempt("land changed after the allowance was issued", lambda: gate.cross(land, 7, tok, 14, (5, 6), 0), "REFUSED")

land2, auth2, _ = fresh(confirm_cell=(5, 5))
ok = auth2.consider(land2, 7, 14) is None; results.append(ok)
print(("PASS  " if ok else "FAIL  ") + "authority declines when the confirmation is at the same place as the opening")
land3, auth3 = C.Land(), C.Authority(seed=123); land3.write("OPEN", 7, 10, (5, 5), way=0)
ok = auth3.consider(land3, 7, 11) is None; results.append(ok)
print(("PASS  " if ok else "FAIL  ") + "authority declines when a question was opened but never confirmed")
ok = auth3.consider(land3, 42, 11) is None; results.append(ok)
print(("PASS  " if ok else "FAIL  ") + "authority declines a member with nothing on the land")
land4, auth4, gate4 = fresh(); tok4 = auth4.consider(land4, 7, 14); gate4.cross(land4, 7, tok4, 14, (5, 6), 0)
ok = auth4.consider(land4, 7, 14) is None; results.append(ok)
print(("PASS  " if ok else "FAIL  ") + "authority declines a second allowance for a question already crossed on")
print("ALL PASS" if all(results) else "GATE CASES FAILED"); sys.exit(0 if all(results) else 1)
