"""Run every arm at every size on the scored seeds, once, and score the written predictions."""
import argparse, json, math, statistics as st, sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import change as C


def sign_test(deltas):
    wins, losses = sum(d > 0 for d in deltas), sum(d < 0 for d in deltas)
    n = wins + losses
    p = 1.0 if n == 0 else min(1.0, 2 * sum(math.comb(n, k) for k in range(min(wins, losses) + 1)) / 2 ** n)
    return dict(mean=round(st.mean(deltas), 4), wins=wins, losses=losses, ties=len(deltas) - n, p=round(p, 6))


def pop(r): return r["world"]["pop_final"]
def post(r): return sum(r["post_births"])
def rest_end(r): return r["rest_final"] / pop(r) if pop(r) else None
def share0(r): return r["lineage_final"][0] / pop(r) if pop(r) else None
def others(r): return pop(r) - r["lineage_final"][0]


def summarize(protocol, receipts):
    out = {}
    for size in protocol["founders"]:
        rows = {arm: sorted((r for r in receipts if r["size"] == size and r["arm"] == arm), key=lambda r: r["seed"])
                for arm in protocol["arms"]}
        mean = lambda arm, f: round(st.mean(f(r) for r in rows[arm]), 4)
        def mean_some(arm, f):
            v = [f(r) for r in rows[arm] if f(r) is not None]
            return round(st.mean(v), 4) if v else None
        arms = {arm: dict(
            final_population=mean(arm, pop), extinct=sum(pop(r) == 0 for r in rows[arm]),
            births=mean(arm, lambda r: r["births"]), deaths=mean(arm, lambda r: r["deaths"]),
            post_shock_births_per_lineage=round(mean(arm, post) / size[0], 4),
            lineages_alive=mean(arm, lambda r: r["world"]["families_alive"]),
            per_capita_harvest=mean(arm, lambda r: r["world"]["per_capita"]),
            stock_min=mean(arm, lambda r: r["world"]["stock_min"]),
            rest_fraction_end=mean_some(arm, rest_end),
            rest_fraction_last100=mean_some(arm, lambda r: r["rest_fraction_last100"]),
            readings_against=mean(arm, lambda r: r["against"]), opened=mean(arm, lambda r: r["opened"]),
            released=mean(arm, lambda r: r["released"]), confirmed=mean(arm, lambda r: r["confirmed"]),
            refused=sum(r["refused"] for r in rows[arm]),
            to_rest=mean(arm, lambda r: r["to_rest"]), to_hustle=mean(arm, lambda r: r["to_hustle"]),
            crossings_last_third=mean(arm, lambda r: r["crossings_last_third"]),
            seeds_with_late_crossings=sum(r["crossings_last_third"] > 0 for r in rows[arm]),
            pauses=mean(arm, lambda r: r["pauses"])) for arm in protocol["arms"]}
        def cmp(a, b, f):
            return sign_test([f(x) - f(y) for x, y in zip(rows[a], rows[b], strict=True)])
        pairs = [("ASK", "FIXED_HUSTLE"), ("ASK", "FIXED_REST"), ("ASK", "SELF"), ("ASK", "BIOLOGY"),
                 ("ASK", "BIOLOGY_MIXED"), ("TAKER", "ASK"), ("FIXED_REST", "FIXED_HUSTLE"), ("SELF", "FIXED_HUSTLE")]
        both = [(x, y) for x, y in zip(rows["TAKER"], rows["ASK"], strict=True) if pop(x) and pop(y)]
        out[f"{size[0]}x{size[1]}"] = dict(
            arms=arms,
            paired_final_population={f"{a} - {b}": cmp(a, b, pop) for a, b in pairs},
            paired_post_shock_births={f"{a} - {b}": cmp(a, b, post) for a, b in pairs},
            taker=dict(
                lineage0_share_TAKER=mean_some("TAKER", share0), lineage0_share_ASK=mean_some("ASK", share0),
                paired_share=sign_test([share0(x) - share0(y) for x, y in both]),
                paired_lineage0_members=sign_test([x["lineage_final"][0] - y["lineage_final"][0] for x, y in zip(rows["TAKER"], rows["ASK"])]),
                paired_other_lineages_members=sign_test([others(x) - others(y) for x, y in zip(rows["TAKER"], rows["ASK"])])))
    return out


def score(s):
    small, large = s["2x3"], s["4x6"]
    A = lambda z, arm, k: z["arms"][arm][k]
    P = lambda z, key: z["paired_final_population"][key]
    t = large["taker"]["paired_share"]
    rows = {}
    rows["M1 taker lineage share higher in TAKER than ASK at 4x6 (wins > losses)"] = t["wins"] > t["losses"]
    rows["M2 BIOLOGY_MIXED rest fraction ends below 0.5 at both sizes"] = all(A(z, "BIOLOGY_MIXED", "rest_fraction_end") < 0.5 for z in (small, large))
    rows["M3 ASK above FIXED_HUSTLE at 4x6, within 1.5 at 2x3"] = (A(large, "ASK", "final_population") > A(large, "FIXED_HUSTLE", "final_population")
        and abs(A(small, "ASK", "final_population") - A(small, "FIXED_HUSTLE", "final_population")) <= 1.5)
    rows["M4 ASK vs SELF population not reliably different, SELF crosses more, both sizes"] = all(
        P(z, "ASK - SELF")["p"] > 0.05 and A(z, "SELF", "to_rest") + A(z, "SELF", "to_hustle") > A(z, "ASK", "to_rest") + A(z, "ASK", "to_hustle") for z in (small, large))
    rows["M5 ASK rest fraction (last 100 ticks) higher at 4x6 than 2x3"] = A(large, "ASK", "rest_fraction_last100") > A(small, "ASK", "rest_fraction_last100")
    rows["M6 BIOLOGY rest fraction ends below 0.15 at both sizes"] = all(A(z, "BIOLOGY", "rest_fraction_end") < 0.15 for z in (small, large))
    rows["M7 FIXED_REST above FIXED_HUSTLE at 4x6 and below at 2x3"] = (A(large, "FIXED_REST", "final_population") > A(large, "FIXED_HUSTLE", "final_population")
        and A(small, "FIXED_REST", "final_population") < A(small, "FIXED_HUSTLE", "final_population"))
    rows["R-a no extinction in ASK at either size"] = A(small, "ASK", "extinct") == 0 and A(large, "ASK", "extinct") == 0
    rows["R-b ASK mean population at least FIXED_HUSTLE at both sizes"] = all(A(z, "ASK", "final_population") >= A(z, "FIXED_HUSTLE", "final_population") for z in (small, large))
    rows["R-c taker lineage share not reliably higher than in ASK (either size)"] = not any(
        z["taker"]["paired_share"]["wins"] > z["taker"]["paired_share"]["losses"] and z["taker"]["paired_share"]["p"] <= 0.05 for z in (small, large))
    rows["R-d ASK 4x6 still crossing in the final third on at least 15 of 20 seeds"] = A(large, "ASK", "seeds_with_late_crossings") >= 15
    return {k: ("HOLDS" if v else "FAILS") for k, v in rows.items()}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("out", type=Path); ap.add_argument("--workers", type=int, default=2)
    args = ap.parse_args()
    protocol, digest = C.frozen_protocol()
    args.out.mkdir(parents=True, exist_ok=False)
    tasks = [(protocol, digest, arm, size, seed, args.out) for size in protocol["founders"]
             for arm in protocol["arms"] for seed in protocol["seeds"]]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        receipts = list(pool.map(C.world, tasks, chunksize=4))
    (args.out / "runs.json").write_bytes(C.canon(receipts) + b"\n")
    summary = summarize(protocol, receipts)
    summary["predictions"] = score(summary)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"{len(receipts)} scored runs, protocol {digest}")


if __name__ == "__main__":
    main()
